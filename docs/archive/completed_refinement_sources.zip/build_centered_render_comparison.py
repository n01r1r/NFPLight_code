"""Reproduce recorded FP32 terminal maps and render centered comparisons; preserve canonical records."""
from pathlib import Path
import json
import numpy as np
import torch
import run_spherical_refinement as r
from capture_processing.difference_visualization import render_delta_e00, display_range, field_image

def main():
    root=Path('artifacts/spherical_refinement_20261007')
    device=torch.device('cuda')
    torch.backends.cuda.matmul.allow_tf32=False
    torch.backends.cudnn.allow_tf32=False
    model=r.AuthorRealCaptureAdapter(r.CHECKPOINT,device='cuda')
    render=r._make_renderer(device)
    for sample in r.SAMPLES:
        folder=root/sample
        target=folder/'theta_joint'
        old=json.loads((target/'condition.json').read_text(encoding='utf-8'))
        record=json.loads((folder/'metrics.json').read_text(encoding='utf-8'))
        q=record['lamp_intensity']['q']
        near,far,provenance=r.reconstruct_selected_pair(sample=sample,refresh=r.REFRESH_ROOT/sample/'refresh_20261006')
        with torch.no_grad(): pred,_=model.infer(torch.cat((near,far),dim=1).to(device))
        cache=target/'render_materials.npz'
        if cache.exists():
            data=np.load(cache)
            original=torch.from_numpy(data['original']).to(device)
            updated=torch.from_numpy(data['updated']).to(device)
            assert torch.equal(original,pred)
            np.testing.assert_array_equal(data['recorded_train_mse'],[x['train_mse'] for x in old['trajectory']])
            assert int(data['terminal_step'])==old['termination']['step']
        else:
            states=[]
            def snapshot(step,state,final):
                if final: states.append(state.clone())
                if step%100==0: print(sample,step,flush=True)
            result=r.analyze_condition(pred,render,torch.tensor(old['train_xyz'],dtype=torch.float32,device=device),torch.tensor(old['evaluation_xyz'],dtype=torch.float32,device=device),q,mode='fixed',regime='theta_joint',steps=3000,lr=.01,seed=0,stability=True,snapshot_callback=snapshot,light_chunk_size=8)
            assert result['termination']==old['termination'],(result['termination'],old['termination'])
            np.testing.assert_allclose([x['train_mse'] for x in result['trajectory']],[x['train_mse'] for x in old['trajectory']],rtol=1e-5,atol=1e-12)
            assert len(states)==1
            original,updated=pred,states[0]
            np.savez_compressed(cache,original=original.cpu().numpy(),updated=updated.cpu().numpy(),recorded_train_mse=np.array([x['train_mse'] for x in old['trajectory']]),terminal_step=old['termination']['step'])
        with torch.no_grad():
            a=render(original,r.ring(0,device=device),q)[:,0]
            b=render(updated,r.ring(0,device=device),q)[:,0]
        assert torch.isfinite(a).all() and torch.isfinite(b).all()
        delta=b-a
        scale=float(delta.abs().max())
        assert scale>0
        r.tile(a[0].clamp(0,1).pow(1/2.2)).save(target/'render_original.webp',lossless=True)
        r.tile(b[0].clamp(0,1).pow(1/2.2)).save(target/'render_updated.webp',lossless=True)
        perceptual = render_delta_e00(a[0].cpu().numpy().transpose(1,2,0), b[0].cpu().numpy().transpose(1,2,0))
        field_image(perceptual,display_range([perceptual]),'CIEDE2000 Delta E00').save(target/'render_difference.webp',lossless=True)
        observed=near.to(device)
        near_differences={'original':a-observed,'updated':b-observed}
        near_scale=max(float(value.abs().max()) for value in near_differences.values())
        assert all(torch.isfinite(value).all() for value in near_differences.values())
        near_perceptual = {name:render_delta_e00(observed[0].cpu().numpy().transpose(1,2,0), (a if name == 'original' else b)[0].cpu().numpy().transpose(1,2,0)) for name in near_differences}
        near_perceptual_scale = display_range(list(near_perceptual.values()))
        for name,value in near_differences.items():
            display=torch.full_like(value[0],.5) if near_scale==0 else .5+value[0]/(2*near_scale)
            field_image(near_perceptual[name],near_perceptual_scale,'CIEDE2000 Delta E00').save(target/f'render_{name}_minus_near.webp',lossless=True)
        np.savez_compressed(target/'centered_render_values.npz',original=a.cpu().numpy(),updated=b.cpu().numpy(),near=near.numpy(),far=far.numpy())
        for side,tensor in [('near',near),('far',far)]:
            r.tile(tensor[0].pow(1/2.2)).save(target/f'measured_{side}.webp',lossless=True)
        r._json(target/'render_comparison.json',{'schema':'nfplight.centered-render-comparison.v1','light_xyz':[0,0,4],'q':q,'precision':'FP32','material_cache':'render_materials.npz','replay_termination_and_train_trajectory_match':True,'difference_scale':scale,'near_difference_scale':near_scale,'near_difference_definition':'render minus selected I_N, render unclipped; I_N is the clipped linear model input','difference_statistics':{name:{'min':float(value.min()),'max':float(value.max()),'mean':float(value.double().mean())} for name,value in {**{name+'_minus_near':value for name,value in near_differences.items()},'updated_minus_original':delta}.items()},'statistics_definition':'Signed linear RGB difference; all pixels and RGB channels; mean accumulated in float64','near_difference_mse':{name:float(value.square().mean()) for name,value in near_differences.items()},'difference_definition':'updated minus original, unclipped linear RGB','display':'render and measurement clip[0,1], gamma2.2; difference CIEDE2000 Delta E00 with embedded legend; signed statistics are archived raw RGB metrics', 'perceptual_difference_ranges':{'updated_original':display_range([perceptual]),'versus_near':near_perceptual_scale},'original_range':[float(a.min()),float(a.max())],'updated_range':[float(b.min()),float(b.max())],'measured_provenance':provenance,'far_role':'different measurement distance, reference only'})
        print('RENDER_COMPARISON_READY',sample,flush=True)
if __name__=='__main__': main()
