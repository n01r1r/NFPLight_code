"""Validate measured experiment artifacts and add initial/baseline/end comparison."""
from pathlib import Path
import json
import numpy as np
from html.parser import HTMLParser
import run_measured_spherical_refinement as runner


def finalize(root=None, previous_root=None, rebuild=True):
    root=Path(root) if root is not None else runner.OUTPUT
    prior=Path(previous_root) if previous_root is not None else runner.SOURCE
    summary=json.loads((root/'summary.json').read_text(encoding='utf-8'))
    if 'objective_switch_at_step' not in summary['plan']:
        summary['plan']['optimization']='centered measured MSE plus 0.1 mean41 preservation; chunks of 8; one Adam update'
        summary['plan']['fallback']='not used: agreed joint 41-light objective'
    comparisons=[];records=[]
    for sample in summary['plan']['active_samples']:
        target=root/sample/'theta_joint'
        c=json.loads((target/'condition.json').read_text(encoding='utf-8'))
        record=json.loads((root/sample/'metrics.json').read_text(encoding='utf-8'));record['conditions']=[c];records.append(record)
        meta=json.loads((target/'render_comparison.json').read_text(encoding='utf-8'))
        with np.load(target/'centered_render_values.npz') as arrays:
            original_mse=float(np.mean((arrays['original']-arrays['near'])**2))
            terminal_mse=float(np.mean((arrays['updated']-arrays['near'])**2))
        with np.load(prior/sample/'theta_joint/centered_render_values.npz') as arrays:
            previous_terminal_mse=float(np.mean((arrays['updated']-arrays['near'])**2))
        tr=c['trajectory']
        assert all(np.isfinite([entry['measured_mse'],entry['preservation_mse'],entry['total_loss']]).all() for entry in tr)
        np.testing.assert_allclose([entry['total_loss'] for entry in tr],[entry['measured_mse']+.1*entry['preservation_mse'] for entry in tr],rtol=3e-6,atol=1e-10)
        np.testing.assert_allclose(terminal_mse,tr[-1]['measured_mse'],rtol=1e-5)
        with np.load(target/'render_materials.npz') as arrays:
            assert arrays['original'].dtype==np.float32 and arrays['updated'].dtype==np.float32
            np.testing.assert_array_equal(arrays['updated'][:,7:],np.full_like(arrays['updated'][:,7:],-.92))
        compare={'sample':sample,'original_pred_near_mse':original_mse,'fixed_initial_near_mse':tr[0]['measured_mse'],'previous_preservation_only_terminal_near_mse':previous_terminal_mse,'previous_terminal_near_mse':previous_terminal_mse,'measured_refinement_terminal_near_mse':terminal_mse,'step':c['termination']['step'],'status':c['termination']['status'],'terminal_preservation_mse':tr[-1]['preservation_mse'],'total':tr[-1]['total_loss'],'test_preservation_mse':tr[-1]['common_heldout_mse']}
        comparisons.append(compare)
        meta['near_mse_comparison']=compare
        (target/'render_comparison.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (root/'plan.json').write_text(json.dumps(summary['plan'],ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (root/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    (root/'measurement_comparison.json').write_text(json.dumps(comparisons,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    if rebuild:
        runner.OUTPUT=root
        runner.build_reports(records,summary['plan'])
    columns=[('Original pred','original_pred_near_mse'),('F0 fixed initial','fixed_initial_near_mse'),('Previous terminal','previous_preservation_only_terminal_near_mse'),('Measured terminal','measured_refinement_terminal_near_mse')]
    table='<h2>I_N difference · linear RGB MSE</h2><table><tr><th>Sample</th>'+''.join(f'<th>{title}</th>' for title,key in columns)+'</tr>'+''.join('<tr><td>'+row['sample']+'</td>'+''.join(f'<td>{row[key]:.5g}</td>' for title,key in columns)+'</tr>' for row in comparisons)+'</table>'
    p=root/'summary.html';html=p.read_text(encoding='utf-8');html=html.replace('</table>','</table>'+table,1)
    html=html.replace('<p><a href="../spherical_refinement_20261007/summary.html">','<p><a href="ANALYSIS.md">실험 해석</a> · <a href="../spherical_refinement_20261007/summary.html">')
    p.write_text(html,encoding='utf-8')
    class Links(HTMLParser):
        def __init__(self,base): super().__init__();self.base=base;self.count=0
        def handle_starttag(self,tag,attrs):
            d=dict(attrs)
            if tag=='img': assert (self.base/d['src']).exists();self.count+=1
    checked=0
    for p in [root/'summary.html']+[root/sample/'report.html' for sample in summary['plan']['active_samples']]:
        check=Links(p.parent);check.feed(p.read_text(encoding='utf-8'));checked+=check.count
        assert all(sample not in p.read_text(encoding='utf-8') for sample in runner.r.EXCLUDED_SAMPLES)
    analysis='# Measured refinement · λ=0.1\n\nL = measured I_N MSE + 0.1 × 41-light preservation MSE. 원래 pred에서 시작해 F0=0.04를 고정하고 n/d/r만 업데이트했다. q·camera·surface·조명·FP32·Adam·종료 기준은 이전 실험과 같다. Test 40방향은 최적화와 종료에 사용하지 않았다.\n\n|Sample|Original pred MSE|F0 고정 직후|이전 종료|이번 종료|Step|판정|\n|---|---:|---:|---:|---:|---:|---|\n'
    for row in comparisons:
        analysis+='|'+row['sample']+'|'+ '|'.join(f'{row[key]:.6g}' for title,key in columns[:2])+f"|{row['previous_preservation_only_terminal_near_mse']:.6g}|{row['measured_refinement_terminal_near_mse']:.6g}|{row['step']}|{row['status']}|\n"
    analysis+='\nMSE는 clip 전 centered rendering과 실제 clipped linear I_N 입력의 RGB·전체 픽셀 평균이다. 초기 F0 고정 직후와 원래 pred는 다른 상태다. 종료 맵을 표시하며 best total-loss 맵은 별도 보존한다.\n\nI_N 차이 감소는 이번 loss가 직접 최적화한 결과이며 독립적인 재질 정확도 검증이 아니다. 보존 MSE·미사용 방향 MSE는 원래 pred의 반사 응답과의 차이다. λ=0.1은 사용자 승인한 초기 설정이며 최적값으로 검증하지 않았다. Far는 거리 조건이 다른 측정 참고 영상으로만 표시하고 loss에 사용하지 않았다.\n'
    (root/'ANALYSIS.md').write_text(analysis,encoding='utf-8')
    check=json.loads((root/'checks.json').read_text(encoding='utf-8'));check.update(objective_identity_verified_all_steps=True,numeric_materials_saved=True,html_image_paths_verified=checked,baseline_initial_terminal_separated=True)
    (root/'checks.json').write_text(json.dumps(check,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(comparisons,ensure_ascii=False,indent=2))


if __name__=='__main__': finalize()
