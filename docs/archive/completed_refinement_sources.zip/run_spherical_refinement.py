"""Fixed-F0 refinement on a joint constant-radius angular grid, FP32 only."""
import argparse
import json
import math
import platform
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from capture_processing.rendering_loss_analysis import analyze_condition, physical_maps
from capture_processing.prediction_refinement import estimate_lamp_intensity
from model.author_real_capture_adapter import AuthorRealCaptureAdapter
from run_prediction_refinement import reconstruct_selected_pair
from run_rendering_loss_analysis import CHECKPOINT, REFRESH_ROOT, SAMPLES as CAPTURE_SAMPLES, _make_renderer, _file_stat, _json

# User decision: these materials have different properties and are outside refinement scope.
EXCLUDED_SAMPLES = ('260923_141241_844', '260923_161825_503')
SAMPLES = tuple(s for s in CAPTURE_SAMPLES if s not in EXCLUDED_SAMPLES)

THETAS = (0, 5, 10, 20, 30, 45)
SNAPSHOTS = set(range(0, 101, 10)) | set(range(200, 2901, 100))


def ring(theta, offset=0, device='cpu'):
    if theta not in THETAS or offset not in (0, 22.5):
        raise ValueError('unsupported angular grid')
    t = math.radians(theta)
    phis = [0] if theta == 0 else range(0, 360, 45)
    return torch.tensor([[4*math.sin(t)*math.cos(math.radians(p+offset)),
                          4*math.sin(t)*math.sin(math.radians(p+offset)),
                          4*math.cos(t)] for p in phis], dtype=torch.float32, device=device)


def tile(array):
    a = array.detach().cpu().numpy()
    if a.shape[0] == 1:
        a = np.repeat(a, 3, axis=0)
    return Image.fromarray(np.rint(np.clip(a.transpose(1, 2, 0), 0, 1)*255).astype('uint8'))


def display_scales(original, states):
    before = physical_maps(original)
    scales = {k: 1e-6 for k in ('normal', 'diffuse', 'roughness', 'specular')}
    for state in states:
        after = physical_maps(state)
        n0, n1 = before['normal'], after['normal']
        angles = torch.rad2deg(torch.atan2(torch.linalg.vector_norm(torch.cross(n0,n1,dim=1),dim=1),(n0*n1).sum(1)))
        scales['normal'] = max(scales['normal'], float(angles.max()))
        for key in ('diffuse','roughness','specular'):
            scales[key] = max(scales[key], float((after[key]-before[key]).abs().max()))
    return scales


def initial_gradient_check(pred, render, q):
    """Compare joint gradient and projected first Adam update against individual rings."""
    from capture_processing.rendering_loss_analysis import initial_material
    gradients, updates = {}, {}
    initial = initial_material(pred, 'fixed')
    for theta in THETAS:
        state = initial.clone().requires_grad_()
        lights = ring(theta, device=pred.device)
        with torch.no_grad(): teacher = render(pred, lights, q)
        loss = (render(state, lights, q)-teacher).square().mean()
        g, = torch.autograd.grad(loss, state)
        g[:,7:] = 0
        gradients[str(theta)] = g.detach()
    joint = sum(gradients[str(t)]*(1 if t==0 else 8)/41 for t in THETAS)
    gradients['joint'] = joint
    for name, g in gradients.items():
        state = initial.clone().requires_grad_()
        optimizer = torch.optim.Adam([state], lr=.01)
        state.grad = g.clone();optimizer.step()
        with torch.no_grad(): state[:,3:6].clamp_(-1,1);state[:,6:7].clamp_(-.9,1);state[:,7:] = initial[:,7:]
        updates[name] = (state.detach()-initial).abs()
    groups={'n':slice(0,3),'d':slice(3,6),'r':slice(6,7)}
    result = {}
    for group, sl in groups.items():
        rms={k:float(g[:,sl].square().mean().sqrt()) for k,g in gradients.items()}
        update={k:float(u[:,sl].mean()) for k,u in updates.items()}
        result[group]={'gradient_rms_raw':rms,'first_projected_adam_update_mean_abs_raw':update,
                       'joint_gradient_to_max_ring':rms['joint']/max(max(rms[str(t)] for t in THETAS),1e-30),
                       'joint_update_to_max_ring':update['joint']/max(max(update[str(t)] for t in THETAS),1e-30)}
    result['fallback_required'] = any(v['joint_gradient_to_max_ring']>1.0001 or v['joint_update_to_max_ring']>1.05 for k,v in result.items())
    return result


def save_frame(path, original, current, scales, lossless=True):
    """Display WebP; endpoints lossless, intermediate frames quality92, fixed time scale."""
    a, b = physical_maps(original), physical_maps(current)
    panels = []
    for key in ('normal', 'diffuse', 'roughness', 'specular'):
        x = b[key][0]
        panels.append(tile((x+1)/2 if key == 'normal' else x.pow(1/2.2) if key in ('diffuse', 'specular') else x))
    n0, n1 = a['normal'], b['normal']
    angle = torch.rad2deg(torch.atan2(torch.linalg.vector_norm(torch.cross(n0, n1, dim=1), dim=1), (n0*n1).sum(1)))[0]
    from matplotlib import colormaps
    panels.append(Image.fromarray(np.rint(colormaps['viridis']((angle.cpu().numpy()/scales['normal']).clip(0,1))[..., :3]*255).astype('uint8')))
    for key in ('diffuse', 'roughness', 'specular'):
        panels.append(tile(.5+(b[key][0]-a[key][0])/(2*scales[key])))
    canvas = Image.new('RGB', (1024, 512))
    for i, panel in enumerate(panels):
        canvas.paste(panel, ((i%4)*256, (i//4)*256))
    canvas.save(path, format='WEBP', lossless=lossless, quality=92, method=6)


def summary_map_comparison(output, records):
    """Show original, terminal and signed difference rows from saved display frames."""
    blocks = []
    for record in records:
        sample = record['sample']
        folder = output / sample
        for condition in record['conditions']:
            if 'frames' not in condition:
                condition = json.loads((folder / condition['condition_path']).read_text(encoding='utf-8'))
            terminal = condition['frames'][-1]
            target = folder / f"theta_{condition['theta_deg']}"
            if (target/'centered_render_values.npz').is_file() and (target/'render_materials.npz').is_file():
                from capture_processing.difference_visualization import saved_comparison, comparison_html
                numeric_display = saved_comparison(target)
                blocks.append(f'<section class="map-comparison"><h2>{sample}</h2>' +
                              comparison_html(target, f"{sample}/theta_{condition['theta_deg']}", numeric_display) + '</section>')
                continue
            rows = []
            for label, source, box, name in (
                ('Original pred', folder / 'original.webp', (0, 0, 1024, 256), 'summary_original.webp'),
                (f"Updated pred · step {terminal['step']} · F0=0.04", folder / terminal['path'], (0, 0, 1024, 256), 'summary_updated.webp'),
                ('Difference · updated − original', folder / terminal['path'], (0, 256, 1024, 512), 'summary_difference.webp'),
            ):
                with Image.open(source) as frame:
                    frame.crop(box).save(target / name, format='WEBP', lossless=True)
                src = f"{sample}/theta_{condition['theta_deg']}/{name}"
                rows.append(f'<h3>{label}</h3><img src="{src}" alt="{sample}: {label}, n d r s" width="1024" height="256" loading="lazy" style="display:block;width:100%;height:auto">')
            scales = json.loads((target / 'display_scales.json').read_text(encoding='utf-8'))
            legend = (f"Normal: angular variation 0–{scales['normal']:.4g}° (보라→노랑). "
                      f"Δd RGB: ±{scales['diffuse']:.4g}; Δr gray: ±{scales['roughness']:.4g}; "
                      f"Δs RGB: ±{scales['specular']:.4g}. 차이 맵의 회색은 0, 밝음은 증가, 어두움은 감소다.")
            rendering = target / 'render_comparison.json'
            if rendering.exists():
                comparison = json.loads(rendering.read_text(encoding='utf-8'))
                prefix = f"{sample}/theta_{condition['theta_deg']}"
                five_rows = []
                for row, name in zip(rows, ('original', 'updated', 'difference')):
                    head, image = row.split('<img', 1)
                    five_rows.append(head + '<div style="display:grid;grid-template-columns:4fr 1fr;gap:6px;align-items:start"><img' + image + f'<img src="{prefix}/render_{name}.webp" alt="Centered rendering {name}" width="256" height="256" loading="lazy" style="width:100%;height:auto"></div>')
                headings = '<p style="display:grid;grid-template-columns:repeat(5,1fr);text-align:center"><span>Normal n</span><span>Diffuse d</span><span>Roughness r</span><span>Specular s / F0</span><span>Re-rendering</span></p>'
                measured = f'<aside class="measured-reference"><h3>Measured</h3><h4>Near · I_N</h4><img src="{prefix}/measured_near.webp" alt="Measured near" width="256" height="256" style="width:100%;height:auto"><h4>Far · I_F · 거리 참고</h4><img src="{prefix}/measured_far.webp" alt="Measured far" width="256" height="256" style="width:100%;height:auto"></aside>'
                map_legends = [
                    f"Angular variation<br>0–{scales['normal']:.4g}°<br>보라=0 · 노랑=max",
                    f"Δd · signed RGB<br>±{scales['diffuse']:.4g}",
                    f"Δr · signed gray<br>±{scales['roughness']:.4g}",
                    f"Δs · signed RGB<br>±{scales['specular']:.4g}",
                ]
                stats = comparison['difference_statistics']['updated_minus_original']
                render_legend = f"Δrender · linear RGB<br>±{comparison['difference_scale']:.5g}<br>min {stats['min']:.5g}<br>max {stats['max']:.5g}<br>mean {stats['mean']:.5g}"
                legends = '<div class="column-legends">'+''.join(f'<div>{text}</div>' for text in map_legends+[render_legend])+'</div>'
                legends += '<p class="caption">Signed difference: 회색=0 · 밝은 채널=증가 · 어두운 채널=감소 · min/max/mean: 전체 픽셀·RGB 채널</p>'
                conditions = f"<p class='caption rendering-conditions'>Re-rendering · θ=0° · light (0,0,4) · q={comparison['q']:.6g} · FP32 · display: clip [0,1], γ=2.2</p>"
                content = conditions+'<div class="comparison-layout"><div>'+headings+''.join(five_rows)+legends+'</div>'+measured+'</div>'
                if 'near_difference_scale' in comparison:
                    near_panels = []
                    for name in ('original', 'updated'):
                        stats = comparison['difference_statistics'][name+'_minus_near']
                        caption = f"min {stats['min']:.5g} · max {stats['max']:.5g} · mean {stats['mean']:.5g}"
                        near_panels.append(f'<figure style="margin:0"><figcaption>{name.title()} re-rendering − I_N</figcaption><img src="{prefix}/render_{name}_minus_near.webp" alt="{name} rendering minus near, signed RGB" width="256" height="256" loading="lazy" style="display:block;width:100%;height:auto"><figcaption class="difference-stats">{caption}</figcaption></figure>')
                    content += '<div class="near-comparison"><h3>Re-rendering − I_N</h3>'
                    content += f"<p class='caption'>Signed linear RGB · 공통 범위 ±{comparison['near_difference_scale']:.5g} · 회색=0<br>clip 전 rendering − linear I_N · min/max/mean: 전체 픽셀·RGB 채널</p>"
                    content += '<div class="near-differences">'+''.join(near_panels)+'</div></div>'
                legend = ''
                details = ''

            else:
                content = '<p style="display:grid;grid-template-columns:repeat(4,1fr);text-align:center"><span>Normal n</span><span>Diffuse d</span><span>Roughness r</span><span>Specular s / F0</span></p>'+''.join(rows)
                details = ''
            blocks.append(f'<section class="map-comparison" style="margin:40px 0"><h2><a href="{sample}/report.html">{sample}</a></h2>'+content+(f'<p class="caption">{legend}</p>' if legend else '')+'</section>')
    return '<style>body{font-family:Georgia,"Times New Roman","Batang","바탕",serif}.caption,figcaption{font-size:14px;line-height:1.5}.column-legends{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:6px;font-size:14px;line-height:1.55;margin-top:10px}.column-legends>div{border-top:1px solid #ddd;padding-top:8px}.rendering-conditions{margin:8px 0 18px}.near-comparison{border-top:1px solid #ddd;margin-top:28px;padding-top:12px}.difference-stats{margin-top:8px;font-variant-numeric:tabular-nums}.near-differences{display:grid;grid-template-columns:repeat(2,minmax(0,320px));gap:24px;margin-top:12px}.comparison-layout{display:grid;grid-template-columns:minmax(0,5fr) minmax(160px,1fr);gap:24px}.measured-reference{border-left:1px solid #ddd;padding-left:18px}.measured-reference p{font-size:13px}.measured-reference h4{margin:12px 0 6px}@media(max-width:900px){.comparison-layout{grid-template-columns:1fr}.measured-reference{border-left:0;border-top:1px solid #ddd;padding:16px 0;display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.measured-reference img{max-width:256px}}</style><h2>Original · updated · difference</h2>'+''.join(blocks)


def report(folder, record):
    blocks = []
    for c in record['conditions']:
        if 'trajectory' not in c:
            c = json.loads((folder/f'theta_{c["theta_deg"]}'/'condition.json').read_text(encoding='utf-8'))
        theta = c['theta_deg']; frames = c['frames']; last = frames[-1]
        title = '모든 θ·φ 공동 최적화' if theta == 'joint' else f'θ={theta}°'
        scales = c.get('display_scales',record['display_scales'])
        scale_text = ', '.join(f'{k}={v:.4g}' for k,v in scales.items())
        gradient_rows = ''.join(f'<tr><td>{key}</td><td>{v["joint_gradient_to_max_ring"]:.3f}</td><td>{v["joint_update_to_max_ring"]:.3f}</td></tr>' for key,v in record['initial_gradient_check'].items() if key != 'fallback_required')
        ring_rows = ''
        if theta == 'joint':
            offset = 0
            for t in THETAS:
                count = 1 if t == 0 else 8
                first = sum(c['trajectory'][0]['train_mse_per_light'][offset:offset+count])/count
                last_loss = sum(c['trajectory'][-1]['train_mse_per_light'][offset:offset+count])/count
                ring_rows += f'<tr><td>{t}°</td><td>{count}</td><td>{first:.4g}</td><td>{last_loss:.4g}</td></tr>'
                offset += count
        blocks.append(f'''<section data-frames='{json.dumps(frames)}'><h2>{title} · {c['train_light_count']}개 학습 광원</h2>
        <p>{'안정화 기준 충족' if c['termination']['status']=='stability_criteria_met' else '수렴 미확인 · 최대 횟수 도달'} · 종료 step {c['termination']['step']}</p>
        <p>위: n / d / r / s. 아래: normal 각도 / Δd / Δr / Δs. 원래 pred 대비 변화.</p>
        <p>이 조건의 전 step 공통 표시 범위: {scale_text}. normal은 0…표시값(도), 나머지는 ±표시값.</p>
        <div class="labels"><span>Normal</span><span>Diffuse</span><span>Roughness</span><span>F0=.04</span></div>
        <img class="frame" loading="lazy" alt="현재 step의 n d r s 및 원래 pred 대비 변화" src="{last['path']}" width="1024" height="512"><div><button type="button">재생</button> <input aria-label="step" type="range" min="0" max="{len(frames)-1}" value="{len(frames)-1}"> <output>step {last['step']}</output></div>
        <div style="width:240px;margin:12px 0"><div style="height:14px;background:linear-gradient(to right,#440154,#3b528b,#21918c,#5ec962,#fde725)"></div><div style="display:flex;justify-content:space-between"><span>Normal 0°</span><span>{scales['normal']:.3g}°</span></div></div>
        <p>Δd/Δs는 해당 RGB 채널의 증가를 밝게, 감소를 어둡게 표시한다. Δr은 검정=감소, 회색=0, 흰색=증가다. Δs는 F0 고정에 따른 변화이며 최적화 중 변하지 않는다.</p>
        <p>학습 차이 {c['metrics']['initial_train_mse']:.4g} → {c['metrics']['last_train_mse']:.4g}. {'독립 평가 방향 없음' if theta==0 else '미사용 방향 차이 '+format(c['metrics']['last_common_heldout_mse'],'.4g')}</p>
        <img src="theta_{theta}/curve.svg" width="1000">
        <h3>θ별 반사 응답 차이</h3><table><tr><th>θ</th><th>광원 수</th><th>고정 직후</th><th>종료</th></tr>{ring_rows or f'<tr><td>{theta}°</td><td>{c["train_light_count"]}</td><td>{c["metrics"]["initial_train_mse"]:.4g}</td><td>{c["metrics"]["last_train_mse"]:.4g}</td></tr>'}</table>
        <h3>Gradient와 실제 업데이트</h3><p>초기 공동 값 / 개별 θ ring 최댓값. 초기 스케일 비교이며 이후 θ별 독립 실행 결과를 뜻하지 않는다.</p><table><tr><th>맵</th><th>Gradient RMS 비율</th><th>첫 Adam 평균 업데이트 비율</th></tr>{gradient_rows}</table>
        <img src="theta_{theta}/optimizer.svg" width="1000">
        <details><summary>종료 판정 수치</summary><pre>{json.dumps(c['trajectory'][-1].get('stability_window',{}),ensure_ascii=False,indent=2)}</pre></details></section>''')
    page = '''<!doctype html><html lang="ko"><meta charset="utf-8"><title>구면 조명 · F0 고정 refinement</title>
    <style>body{font:17px/1.65 system-ui;background:#fafafa;color:#202020;margin:32px auto;max-width:1100px;padding:0 20px}section{margin:48px 0}img{max-width:100%;height:auto}input{width:65%}button{padding:8px}pre{white-space:pre-wrap}.labels{display:grid;grid-template-columns:repeat(4,1fr);text-align:center}table{border-collapse:collapse;width:100%;margin:16px 0}th,td{border-bottom:1px solid #ccc;padding:8px;text-align:left}</style>
    <h1>구면 조명 · F0=.04 refinement</h1>'''+f"<p>{record['sample']} · q={record['lamp_intensity']['q']:.6g}</p>"+'''
    <p>R=4, θ는 +Z축 기준, φ는 +X축에서 +Y축 방향. 41개 θ·φ 위치의 unclipped RGB MSE를 매 step 평균해 하나의 n/d/r을 추정한다. 8개씩 나눠 렌더링하되 41개 전체 평균 gradient로 한 번 갱신한다. 목표는 원래 pred 렌더링이다. I_N은 q fitting에만 사용한다.</p>
    <h2>원래 pred · n / d / r / s</h2><img alt="원래 pred의 n d r s" src="original.webp" width="1024" height="512">
    <p>맵 d/s는 gamma 2.2 표시. 변화 RGB는 gamma 없이 0.5+Δ/(2M): 회색=0, 채널별 범위 −M…+M. Normal 변화는 viridis 0…A°(어두운 보라=0, 노랑=A°). 아래 원래 pred 변화 행은 모두 0이다. 표시 범위는 각 조건에서 저장된 모든 step의 실제 최대값을 사용하며 해당 조건의 모든 step에서 동일하다. 조건·샘플 간 색 강도를 직접 비교하지 않는다.</p>
    <p>원래 pred·고정 직후·종료 영상은 lossless WebP, 중간 재생 영상은 WebP quality92다. 수치 측정은 압축 전 FP32 맵에서 수행하며 영상을 역산하지 않는다. 최대40시점만 저장하고 슬라이더를 선택할 때 해당 영상을 불러온다.</p>
    <p>표면은 z=0의 [-1,1]² 영역, 카메라는 (0,0,4)다. θ·φ는 표면 중심 기준 광원 위치를 나타내며 픽셀마다 입사·시선·half-vector 방향은 다르다.</p><p>Adam lr=.01, seed=0, FP32, AMP·TF32 off. 최소300/최대3000회. 100회 구간 loss 변동폭/평균≤0.001, 구간 시작·끝 평균 normal 각도≤0.001°, d/r 절대 차이≤1e−5를 모두 만족하면 종료. 매100회 판정한다. 최저 학습 loss 상태는 보조 기록이며 표시 맵은 종료 상태다. 평가 φ는22.5° offset이며 최적화·종료 기준에 사용하지 않는다. 재질 GT 정확도나 유일해를 의미하지 않는다.</p>
    '''+f'<p>표시 범위: {json.dumps(record["display_scales"], ensure_ascii=False)}</p>'+''.join(blocks)+'''<script>
    document.querySelectorAll('section').forEach(s=>{const f=JSON.parse(s.dataset.frames),r=s.querySelector('input'),img=s.querySelector('.frame'),o=s.querySelector('output'),b=s.querySelector('button');let timer=null;const show=()=>{const x=f[+r.value];img.src=x.path;o.textContent='step '+x.step;};r.oninput=show;b.onclick=()=>{if(timer){clearInterval(timer);timer=null;b.textContent='재생';return;}b.textContent='정지';if(+r.value===f.length-1)r.value=0;show();timer=setInterval(()=>{if(+r.value>=f.length-1){clearInterval(timer);timer=null;b.textContent='재생';return;}r.value=+r.value+1;show();},500);};});
    </script></html>'''
    (folder/'report.html').write_text(page, encoding='utf-8')
    if record.get('mode') == 'rings':
        page = page.replace('41개 θ·φ 위치의 unclipped RGB MSE를 매 step 평균해 하나의 n/d/r을 추정한다. 8개씩 나눠 렌더링하되 41개 전체 평균 gradient로 한 번 갱신한다.',
                            '초기 공동 업데이트의 스케일 변화로 θ별 독립 최적화로 전환했다. θ>0에서 8개 φ 평균 loss, θ=0에서 중앙 한 광원 loss를 사용한다. 각 조건은 같은 원래 pred에서 시작한다.')
        (folder/'report.html').write_text(page,encoding='utf-8')


def plot_curve(folder, trajectory, theta):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 2, figsize=(11, 3.5), constrained_layout=True)
    steps=[x['step'] for x in trajectory]
    axes[0].semilogy(steps,[max(x['train_mse'],1e-30) for x in trajectory],label='Train')
    if theta:
        axes[0].semilogy(steps,[max(x['common_heldout_mse'],1e-30) for x in trajectory],label='Unused azimuth')
    axes[0].set_ylabel('Mean squared RGB difference');axes[0].legend()
    axes[1].plot(steps,[x['map_mae_physical']['normal_angular_mean_deg'] for x in trajectory]);axes[1].set_ylabel('Mean normal change (degrees)')
    for ax in axes: ax.set_xlabel('Update');ax.grid(alpha=.2)
    fig.savefig(folder/'curve.svg');plt.close(fig)
    fig, axes = plt.subplots(2,3,figsize=(11,6),constrained_layout=True)
    for j,key in enumerate(('n','d','r')):
        for i,field in enumerate(('gradient_rms_raw','update_mean_abs_raw')):
            entries=trajectory if i==0 else trajectory[1:]
            axes[i,j].semilogy([x['step'] for x in entries],[x[field][key] if x[field][key]>0 else float('nan') for x in entries])
            axes[i,j].set_title(key);axes[i,j].set_xlabel('Update');axes[i,j].grid(alpha=.2)
        axes[0,j].set_ylabel('Raw gradient RMS');axes[1,j].set_ylabel('Mean absolute raw update')
    fig.savefig(folder/'optimizer.svg');plt.close(fig)


def recover_display_scales(output, sample, thetas):
    """Replay unchanged recorded conditions only to recover display metadata."""
    if sample not in SAMPLES:
        raise ValueError('sample is excluded from current refinement scope')
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device('cuda')
    model=AuthorRealCaptureAdapter(CHECKPOINT,device='cuda')
    near,far,_=reconstruct_selected_pair(sample=sample,refresh=REFRESH_ROOT/sample/'refresh_20261006')
    with torch.no_grad(): pred,_=model.infer(torch.cat((near,far),dim=1).to(device))
    render=_make_renderer(device)
    for theta in thetas:
        folder=output/sample/f'theta_{theta}'
        old=json.loads((folder/'condition.json').read_text(encoding='utf-8'))
        states=[]
        def snapshot(step,state,final):
            if step in SNAPSHOTS or final:
                states.append(state.cpu().clone())
        q=json.loads((output/sample/'metrics.json').read_text(encoding='utf-8'))['lamp_intensity']['q']
        result=analyze_condition(pred,render,ring(theta,device=device),ring(theta,22.5,device),q,mode='fixed',regime=f'theta_{theta}',steps=3000,stability=True,snapshot_callback=snapshot,light_chunk_size=8)
        assert result['termination']==old['termination']
        np.testing.assert_allclose([x['train_mse'] for x in result['trajectory']],[x['train_mse'] for x in old['trajectory']],rtol=1e-5,atol=1e-12)
        scales=display_scales(pred.cpu(),states)
        _json(folder/'display_scales.json',scales)
        _json(folder/'display_replay_check.json',{'trajectory_matches':True,'termination_matches':True,'numeric_maps_saved':False,'purpose':'recover unchanged display scale metadata'})
        print('DISPLAY_METADATA_RECOVERED',sample,theta,flush=True)


def finalize_reports(output, samples=SAMPLES, write_records=True):
    """Build current reports from canonical condition records and integrate links."""
    import os
    import shutil
    from capture_processing.rendering_loss_analysis import insert_analysis_section, validate_analysis_links
    records=[];rows=[];links=[]
    if any(sample not in SAMPLES for sample in samples):
        raise ValueError('sample is excluded from the current refinement scope')
    backup=output/'report_backups';backup.mkdir(exist_ok=True)
    for sample in samples:
        folder=output/sample
        record=json.loads((folder/'metrics.json').read_text(encoding='utf-8'))
        for index,c in enumerate(record['conditions']):
            target=folder/f'theta_{c["theta_deg"]}'
            c=json.loads((target/'condition.json').read_text(encoding='utf-8'))
            c['display_scales']=json.loads((target/'display_scales.json').read_text(encoding='utf-8'))
            record['conditions'][index]=c
            for f in c['frames'][1:-1]:
                path=folder/f['path']
                if path.read_bytes()[12:16]==b'VP8L':
                    with Image.open(path) as im: image=im.copy()
                    image.save(path,format='WEBP',quality=92,method=6)
            if write_records:
                (target/'condition.json').write_text(json.dumps(c,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8')
            plot_curve(target,c['trajectory'],c['theta_deg'])
            m=c['metrics'];change=m['last_map_mae_physical']
            status='기준 충족' if c['termination']['status']=='stability_criteria_met' else '수렴 미확인'
            title='공동41광원' if c['theta_deg']=='joint' else f'θ={c["theta_deg"]}°'
            rows.append(f'<tr><td><a href="{sample}/report.html">{sample}</a></td><td>{title}</td><td>{c["termination"]["step"]}</td><td>{status}</td><td>{m["last_train_mse"]:.4g}</td><td>{"—" if c["theta_deg"]==0 else format(m["last_common_heldout_mse"],".4g")}</td><td>{change["normal_angular_mean_deg"]:.3f}°</td><td>{change["diffuse"]:.4g}</td><td>{change["roughness"]:.4g}</td></tr>')
        metadata={**record,'conditions':[{k:v for k,v in c.items() if k!='trajectory'}|{'condition_path':f'theta_{c["theta_deg"]}/condition.json'} for c in record['conditions']]}
        if write_records:
            _json(folder/'metrics.json',metadata)
        report(folder,record);records.append(record)
        refresh=REFRESH_ROOT/sample/'refresh_20261006'
        base=os.path.relpath(folder,refresh).replace('\\','/')
        section=f'<section id="rendering-loss-analysis"><h2>현재 실험 · 구면 조명 F0=.04 refinement</h2><p>이전 refinement·XY 반경 실험은 보류했다. 원래 pred에서 FP32로 새 계산했다.</p><p>적용 방식: {"41광원 공동" if record["mode"]=="joint" else "초기 업데이트 스케일 변화로 θ별 독립 구성"}.</p><p><a href="{base}/report.html">원래 맵·종료 맵·변화 영상·step 슬라이더·gradient·종료 판정 보기</a></p></section>'
        for page,label in ((refresh/'report.html','refresh'),(refresh.parent/'report.html','root')):
            saved=backup/f'{sample}_{label}.html'
            if not saved.exists():shutil.copyfile(page,saved)
            text=page.read_text(encoding='utf-8')
            a,b='<!-- prediction-refinement:start -->','<!-- prediction-refinement:end -->'
            if a in text and '보류한 이전 prediction refinement' not in text:
                start=text.index(a)+len(a);end=text.index(b)
                text=text[:start]+'<details><summary>보류한 이전 prediction refinement</summary>'+text[start:end]+'</details>'+text[end:]
            text=insert_analysis_section(text,section);page.write_text(text,encoding='utf-8')
            links.extend(validate_analysis_links(section,refresh))
    modes='; '.join(f'{r["sample"]}: {"공동" if r["mode"]=="joint" else "θ별 전환"}' for r in records)
    summary='''<!doctype html><html lang="ko"><meta charset="utf-8"><title>구면 조명 refinement</title><style>body{font:16px/1.6 Georgia,"Times New Roman","Batang","바탕",serif;max-width:1300px;margin:32px auto;padding:20px}table{border-collapse:collapse;width:100%}th,td{padding:8px;border-bottom:1px solid #ccc;text-align:left}</style><h1>구면 조명 · F0=.04 refinement</h1>
    <p>3 samples · 41 lights · R=4 · θ=0/5/10/20/30/45° · φ 간격 45° · evaluation φ offset 22.5°</p>
    <p>Rendering target: original pred · fixed F0=0.04 · optimized n/d/r · terminal state</p>
    <div style="overflow:auto"><table><tr><th>Sample</th><th>방식</th><th>종료 step</th><th>판정</th><th>학습 RGB MSE</th><th>미사용 φ MSE</th><th>평균 normal 변화</th><th>평균 |Δd|</th><th>평균 |Δr|</th></tr>'''+''.join(rows)+'</table></div><p>'+modes+'</p></html>'
    from build_spherical_sampling_diagram import sampling_diagram
    summary = summary.replace('</html>', sampling_diagram(output, [record['sample'] for record in records]) + summary_map_comparison(output, records) + '</html>')
    (output/'summary.html').write_text(summary,encoding='utf-8')
    index=REFRESH_ROOT/'index.html'
    if not (backup/'index.html').exists():shutil.copyfile(index,backup/'index.html')
    base=os.path.relpath(output,REFRESH_ROOT).replace('\\','/')
    section=f'<section id="rendering-loss-analysis"><h2>현재 실험 · 구면 조명 F0 고정</h2><p>사용자가 지정한 refinement 대상만 포함한다.</p><a href="{base}/summary.html">{len(records)}개 sample 결과·종료 판정·interactive 맵 비교</a></section>'
    index.write_text(insert_analysis_section(index.read_text(encoding='utf-8'),section),encoding='utf-8')
    assert not links,links
    plan=json.loads((output/'plan.json').read_text(encoding='utf-8'))
    plan['active_samples']=list(samples)
    plan['excluded_samples']=list(EXCLUDED_SAMPLES)
    plan['exclusion_reason']='사용자 판정: 다른 성질이므로 refinement 대상에서 제외'
    _json(output/'plan.json',plan)
    _json(output/'summary.json',{'plan':plan,'samples':[{k:v for k,v in r.items() if k!='conditions'}|{'condition_paths':[f'{r["sample"]}/theta_{c["theta_deg"]}/condition.json' for c in r['conditions']]} for r in records],'storage_bytes':sum(p.stat().st_size for p in output.rglob('*') if p.is_file())})
    return records


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,default=Path('artifacts/spherical_refinement_20261007'));parser.add_argument('--sample',choices=SAMPLES);parser.add_argument('--mode',choices=('joint','rings'),default='joint');args=parser.parse_args()
    output=args.output;output.mkdir(parents=True,exist_ok=False)
    plan={'schema':'nfplight.spherical-refinement.v1','optimization':'joint mean of 41 lights, chunks of 8, one Adam update','fallback':'initial joint projected Adam update mean >1.05 times max ring; gradient RMS >1.0001 times max ring; scale heuristic, not divergence evidence','light_chunk_size':8,'theta_deg':THETAS,'radius':4,'phi_deg':list(range(0,360,45)), 'evaluation_phi_offset_deg':22.5,'F0':.04,'lr':.01,'seed':0,'max_steps':3000,'min_steps':300,'window_steps':100,'stability':'relative loss span <= .001; net window mean normal angle <= .001deg, mean abs d/r <=1e-5','snapshot_schedule':sorted(SNAPSHOTS),'max_frames_per_condition':40,'precision':'FP32','numeric_maps_saved':False,'previous_results':'preserved, excluded','sha256_executed':False,'environment':{'python':sys.version,'torch':torch.__version__,'platform':platform.platform()}}
    plan['active_samples']=[args.sample] if args.sample else list(SAMPLES)
    plan['excluded_samples']=list(EXCLUDED_SAMPLES)
    plan['exclusion_reason']='사용자 판정: 다른 성질이므로 refinement 대상에서 제외'
    _json(output/'plan.json',plan)
    device=torch.device('cuda');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    before=_file_stat(CHECKPOINT);model=AuthorRealCaptureAdapter(CHECKPOINT,device='cuda');records=[]
    for sample in ([args.sample] if args.sample else SAMPLES):
        folder=output/sample;folder.mkdir();near,far,provenance=reconstruct_selected_pair(sample=sample,refresh=REFRESH_ROOT/sample/'refresh_20261006')
        with torch.no_grad(): pred,_=model.infer(torch.cat((near,far),dim=1).to(device));render=_make_renderer(device);unit=render(pred,ring(0,device=device),1.)[:,0]
        observed=near.to(device);lamp=estimate_lamp_intensity(unit,observed,observed.amax(1)<=.95);q=float(lamp['q'])
        check=initial_gradient_check(pred,render,q)
        record={'sample':sample,'provenance':provenance,'lamp_intensity':lamp,'initial_gradient_check':check,'conditions':[]}
        mode='rings' if check['fallback_required'] else args.mode
        record['mode']=mode
        _json(folder/'initial_gradient_check.json',check)
        for theta in (['joint'] if mode=='joint' else THETAS):
            target=folder/f'theta_{theta}';target.mkdir();frames=[];states=[]
            train = torch.cat([ring(t,device=device) for t in THETAS]) if theta=='joint' else ring(theta,device=device)
            evaluation = torch.cat([ring(t,22.5,device) for t in THETAS if t]) if theta=='joint' else ring(theta,22.5,device)
            def snapshot(step,state,final):
                if (step in SNAPSHOTS or final) and not any(f['step']==step for f in frames):
                    name=f'step_{step:04d}.webp';states.append(state.cpu().clone());frames.append({'step':step,'path':f'theta_{theta}/{name}'})
                if step%100==0: print(f'{sample} theta={theta} step={step}',flush=True)
            result=analyze_condition(pred,render,train,evaluation,q,mode='fixed',regime=f'theta_{theta}',steps=3000,lr=.01,seed=0,stability=True,snapshot_callback=snapshot,light_chunk_size=8)
            c={k:result[k] for k in ('train_light_count','best_step','termination','metrics','trajectory')};c.update(theta_deg=theta,train_xyz=train.cpu().tolist(),evaluation_xyz=evaluation.cpu().tolist() if theta else [],frames=frames)
            assert len(frames)<=40 and frames[-1]['step']==result['termination']['step']
            scales=display_scales(pred.cpu(),states);record['display_scales']=scales;c['display_scales']=scales
            _json(target/'display_scales.json',scales)
            save_frame(folder/'original.webp',pred.cpu(),pred.cpu(),scales)
            for f,state in zip(frames,states):
                save_frame(folder/f['path'],pred.cpu(),state,scales,lossless=f['step'] in (0,frames[-1]['step']))
            _json(target/'condition.json',c);plot_curve(target,c['trajectory'],theta);record['conditions'].append(c)
            _json(folder/'metrics.json',record);report(folder,record)
            print(f"DONE {sample} theta={theta} {result['termination']}",flush=True)
        record['preservation']={'checkpoint_unchanged':_file_stat(CHECKPOINT)==before,'source_frames_unchanged':all(_file_stat(Path(f['path']))==f['file_stat'] for side in ('near','far') for f in provenance['source_frames'][side])}
        assert all(record['preservation'].values());_json(folder/'metrics.json',record);records.append(record)
        (output/'summary.html').write_text('<!doctype html><meta charset="utf-8"><h1>구면 조명 · F0=.04</h1>'+''.join(f'<p><a href="{r["sample"]}/report.html">{r["sample"]}</a></p>' for r in records),encoding='utf-8')
    _json(output/'summary.json',{'plan':plan,'samples':records,'storage_bytes':sum(p.stat().st_size for p in output.rglob('*') if p.is_file())})
    finalize_reports(output, [args.sample] if args.sample else SAMPLES)
    print('COMPLETE',output,flush=True)


if __name__=='__main__': main()
