"""Cue-constrained refinement initialized from original pretrained predictions."""
import argparse
import json
import math
import platform
import shutil
import sys
from pathlib import Path
import numpy as np
import torch
import run_measured_spherical_refinement as base
import run_spherical_refinement as r

PREVIOUS = Path('artifacts/cue_constrained_refinement_20261007')
OUTPUT = Path('artifacts/cue_constrained_refinement_20261007_diffuse_only')
SOURCE = Path('artifacts/measured_spherical_refinement_20261007_lambda01')
SAMPLES = {'260818_175005_078': ('n',), '260818_174845_478': ('d',)}
VARIANT_CONSTANTS = {
    '260818_175005_078': {('n',), ('n', 'r')},
    '260818_174845_478': {('d',), ('d', 'r')},
}
MAX_STEPS = 10000
LEARNING_RATE = 0.01
PRESERVATION_WEIGHTS = (0.1, 0.5)


def parse_constants(value):
    names = tuple(part.strip() for part in value.split(','))
    if not names or any(not name for name in names):
        raise argparse.ArgumentTypeError('constants must be comma-separated n/d/r names')
    if len(set(names)) != len(names) or any(name not in {'n', 'd', 'r'} for name in names):
        raise argparse.ArgumentTypeError('constants must contain unique n/d/r names')
    return tuple(name for name in ('n', 'd', 'r') if name in names)


def validate_variant(sample, constants, preservation_weight):
    constants = tuple(constants)
    if sample not in VARIANT_CONSTANTS:
        raise ValueError(f'unsupported sample: {sample}')
    if constants not in VARIANT_CONSTANTS[sample]:
        raise ValueError(f'unsupported constants for {sample}: {constants}')
    if not any(math.isclose(float(preservation_weight), weight, rel_tol=0, abs_tol=1e-12)
               for weight in PRESERVATION_WEIGHTS):
        raise ValueError(f'preservation weight must be one of {PRESERVATION_WEIGHTS}')
    return float(preservation_weight)


def variant_id(constants, preservation_weight):
    names = '_'.join(constants)
    weight = f'{preservation_weight:g}'.replace('.', 'p')
    return f'{names}_lambda_{weight}'


def _check_final_losses(recomputed, terminal):
    stored = {key: float(terminal[key]) for key in recomputed}
    for key, value in recomputed.items():
        if not np.isclose(value, stored[key], rtol=2e-5, atol=1e-8):
            raise AssertionError(f'final {key} differs from trajectory: {value} vs {stored[key]}')
    return stored


def audit_variant(output):
    """Re-render saved maps and compare measured/preservation losses to the terminal row."""
    output = Path(output)
    plan = json.loads((output / 'plan.json').read_text(encoding='utf-8'))
    condition = json.loads((output / 'theta_joint' / 'condition.json').read_text(encoding='utf-8'))
    if not torch.cuda.is_available():
        raise RuntimeError('final renderer audit requires CUDA')
    device = torch.device('cuda')
    with np.load(output / 'theta_joint' / 'render_materials.npz') as values:
        original = torch.from_numpy(values['original'].copy()).to(device=device, dtype=torch.float32)
        updated = torch.from_numpy(values['updated'].copy()).to(device=device, dtype=torch.float32)
    source_path = Path(plan['original_prediction_source']['path'])
    with np.load(source_path) as source:
        np.testing.assert_array_equal(original.cpu().numpy(), source['original'])
    train = torch.tensor(condition['train_xyz'], dtype=torch.float32, device=device)
    if train.shape != (40, 3):
        raise ValueError(f'final audit requires 40 preservation lights, got {tuple(train.shape)}')
    sample = plan['sample']
    near, _, _ = r.reconstruct_selected_pair(
        sample=sample,
        refresh=r.REFRESH_ROOT / sample / 'refresh_20261006',
    )
    q = float(plan['q'])
    render = r._make_renderer(device)
    with torch.no_grad():
        measured_render = render(updated, r.ring(0, device=device), q)[:, 0]
        original_train = render(original, train, q)
        updated_train = render(updated, train, q)
        recomputed = {
            'measured_mse': float(torch.nn.functional.mse_loss(measured_render, near.to(device))),
            'preservation_mse': float(torch.nn.functional.mse_loss(updated_train, original_train)),
        }
        recomputed['weighted_preservation_mse'] = plan['preservation_weight'] * recomputed['preservation_mse']
        recomputed['total_loss'] = recomputed['measured_mse'] + recomputed['weighted_preservation_mse']
    terminal = condition['trajectory'][-1]
    if terminal['step'] != condition['termination']['step']:
        raise ValueError('terminal trajectory row does not match the stopping step')
    stored = _check_final_losses(recomputed, terminal)
    audit = {
        'schema': 'nfplight.cue-constraints-final-loss-audit.v1',
        'recomputed': recomputed,
        'trajectory_terminal': stored,
        'tolerance': {'rtol': 2e-5, 'atol': 1e-8},
        'matches_trajectory': True,
        'original_prediction_matches_source_cache': True,
    }
    r._json(output / 'theta_joint' / 'final_loss_audit.json', audit)
    return audit


def _legacy_main():
    OUTPUT.mkdir(exist_ok=False)
    baseline = {str(p): r._file_stat(p) for p in SOURCE.rglob('*') if p.is_file()}
    plan = json.loads((SOURCE/'plan.json').read_text(encoding='utf-8'))
    plan.update(active_samples=list(SAMPLES), spatial_constants=SAMPLES, constant_initialization="spatial mean; normal uses normalized mean of unit normals", preservation_train_count=40, measured_train_count=1,
                objective='centered I_N MSE + 0.1 mean40 off-center preservation MSE',
                initialization='cached original pretrained prediction, projected to spatial constraints; F0 fixed to 0.04; fresh Adam',
                optimization='centered measured MSE plus 0.1 mean40 off-center preservation',
                fallback='not used', snapshot_schedule='every 300 steps and terminal',
                original_prediction_source=str(SOURCE),
                max_steps=10000, learning_rate=.01, seed=0, normal_or_map_loss=False,
                precision='FP32', light_chunk_size=8,
                revision='478: diffuse spatially constant and optimized; normal/roughness pixelwise free; 078 reused unchanged',
                previous_results_source=str(PREVIOUS))
    r._json(OUTPUT/'plan.json', plan)
    device = torch.device('cuda')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    render = r._make_renderer(device)
    records = []
    for SAMPLE, constants in SAMPLES.items():
        folder = OUTPUT/SAMPLE
        if SAMPLE.endswith('_078'):
            shutil.copytree(PREVIOUS/SAMPLE, folder)
            record = json.loads((folder/'metrics.json').read_text(encoding='utf-8'))
            record['conditions'] = [json.loads((folder/'theta_joint/condition.json').read_text(encoding='utf-8'))]
            records.append(record)
            continue
        target = folder/'theta_joint'
        target.mkdir(parents=True)
        metadata = json.loads((SOURCE/SAMPLE/'metrics.json').read_text(encoding='utf-8'))
        old = json.loads((SOURCE/SAMPLE/'theta_joint/condition.json').read_text(encoding='utf-8'))
        with np.load(SOURCE/SAMPLE/'theta_joint/render_materials.npz') as values:
            pred = torch.from_numpy(values['original'].copy()).to(device)
        near, far, provenance = r.reconstruct_selected_pair(sample=SAMPLE, refresh=r.REFRESH_ROOT/SAMPLE/'refresh_20261006')
        q = metadata['lamp_intensity']['q']
        train = torch.tensor(old['train_xyz'][1:], dtype=torch.float32, device=device)
        test = torch.tensor(old['evaluation_xyz'], dtype=torch.float32, device=device)
        assert train.shape == (40, 3) and (train[:, :2].norm(dim=1) > 0).all()
        frames, states = [], []
        def snapshot(step, state, final):
            if (step % 300 == 0 or final) and not any(f['step'] == step for f in frames):
                states.append(state.cpu().clone())
                frames.append({'step': step, 'path': f'theta_joint/step_{step:05d}.webp'})
            if step % 500 == 0:
                print(SAMPLE, step, flush=True)
        result = r.analyze_condition(pred, render, train, test, q, mode='fixed', regime='measured40',
            steps=10000, lr=.01, seed=0, stability=True, snapshot_callback=snapshot,
            light_chunk_size=8, measured_target=near.to(device), measured_light=r.ring(0, device=device),
            preservation_weight=.1, spatial_constants=constants)
        for name, sl in [('n', slice(0,3)), ('d', slice(3,6)), ('r', slice(6,7))]:
            if name in constants:
                value = result['last'][:, sl]
                assert torch.equal(value, value[:, :, :1, :1].expand_as(value))
        c = {k: result[k] for k in ('train_light_count', 'best_step', 'termination', 'metrics', 'trajectory', 'objective')}
        c.update(theta_deg='joint', train_xyz=train.cpu().tolist(), evaluation_xyz=test.cpu().tolist(),
                 frames=frames, display_scales=r.display_scales(pred.cpu(), states))
        assert len(frames) <= 40
        r._json(target/'condition.json', c)
        r._json(target/'display_scales.json', c['display_scales'])
        r.save_frame(folder/'original.webp', pred.cpu(), pred.cpu(), c['display_scales'])
        for f, state in zip(frames, states):
            r.save_frame(folder/f['path'], pred.cpu(), state, c['display_scales'], lossless=f['step'] in (0, frames[-1]['step']))
        np.savez_compressed(target/'render_materials.npz', original=pred.cpu().numpy(), initial=result['initial'].cpu().numpy(), updated=result['last'].cpu().numpy(), best=result['best'].cpu().numpy())
        torch.save(result['checkpoint'], target/'terminal_optimizer.pth')
        base.save_render_comparison(target, pred, result['last'], near, far, render, q, provenance)
        base.make_plots(target, c['trajectory'])
        record = {'sample': SAMPLE, 'mode': 'joint', 'provenance': provenance,
                  'lamp_intensity': metadata['lamp_intensity'], 'display_scales': c['display_scales'], 'conditions': [c]}
        r._json(folder/'metrics.json', {**record, 'conditions': [{k: v for k, v in c.items() if k != 'trajectory'} | {'condition_path': 'theta_joint/condition.json'}]})
        records.append(record)
    base.OUTPUT = OUTPUT
    base.build_reports(records, plan)
    for page in OUTPUT.rglob("*.html"):
        text = page.read_text(encoding="utf-8")
        text = text.replace("mean41", "mean40").replace("min 300 / max 3000", "min 300 / max 10000")
        text = text.replace('../spherical_refinement_20261007/summary.html', '../measured_refinement_20261007_unified/summary.html')
        text = text.replace('../../output/pdf/measured_spherical_refinement_20261007_lambda01.pdf', '../../output/pdf/measured_refinement_20261007_unified.pdf')
        text = text.replace("optimized n/d/r", "078: spatially constant normal; 478: spatially constant diffuse; pixelwise free normal/roughness; shared values optimized")
        page.write_text(text, encoding="utf-8")
    r._json(OUTPUT/"summary.json", {"plan": plan, "samples": records})
    assert all(r._file_stat(Path(p)) == stat for p, stat in baseline.items())
    r._json(OUTPUT/'checks.json', {'prior_files_unchanged': len(baseline), 'train_count': 40, 'test_count': 40,
        'fresh_optimizer': True, 'FP32': True, 'normal_or_map_loss': False, 'sha256_executed': False})
    from finalize_cue_constrained_refinement import main as finalize
    finalize()
    print('COMPLETE', OUTPUT, flush=True)


def run_variant(sample, constants, preservation_weight, output):
    """Write one fresh constrained variant without building or finalizing reports."""
    weight = validate_variant(sample, constants, preservation_weight)
    constants = tuple(constants)
    source_folder = SOURCE / sample
    cached_prediction = source_folder / 'theta_joint' / 'render_materials.npz'
    source_metrics = source_folder / 'metrics.json'
    source_condition = source_folder / 'theta_joint' / 'condition.json'
    if not all(path.is_file() for path in (cached_prediction, source_metrics, source_condition)):
        raise FileNotFoundError(f'cached original refinement inputs are incomplete for {sample}')

    metadata = json.loads(source_metrics.read_text(encoding='utf-8'))
    old = json.loads(source_condition.read_text(encoding='utf-8'))
    with np.load(cached_prediction) as values:
        if 'original' not in values.files:
            raise ValueError(f'original prediction is missing from {cached_prediction}')
        original_array = values['original'].copy()
    if original_array.dtype != np.float32 or original_array.ndim != 4 or original_array.shape[:2] != (1, 10):
        raise ValueError(f'cached original prediction must have FP32 shape 1x10xHxW, got {original_array.dtype} {original_array.shape}')
    if not np.isfinite(original_array).all():
        raise ValueError('cached original prediction contains non-finite values')
    q = float(metadata['lamp_intensity']['q'])
    if not math.isfinite(q) or q <= 0:
        raise ValueError(f'invalid cached lamp intensity q: {q}')

    train_values = old['train_xyz']
    if len(train_values) != 41 or not np.allclose(train_values[0], [0, 0, 4], atol=1e-6, rtol=0):
        raise ValueError('cached condition must start with the measured center light and contain 40 preservation lights')
    device = torch.device('cuda')
    if not torch.cuda.is_available():
        raise RuntimeError('variant execution requires CUDA; the runner does not silently change the experiment device')
    train = torch.tensor(train_values[1:], dtype=torch.float32, device=device)
    test = torch.tensor(old['evaluation_xyz'], dtype=torch.float32, device=device)
    for name, lights in (('preservation', train), ('evaluation', test)):
        if lights.shape != (40, 3) or not torch.isfinite(lights).all():
            raise ValueError(f'cached {name} lights must have shape 40x3 and finite coordinates')
        if not torch.allclose(lights.norm(dim=1), torch.full((40,), 4.0, device=device), atol=1e-5, rtol=0):
            raise ValueError(f'cached {name} lights must remain on the radius-4 sphere')
        if (lights[:, :2].norm(dim=1) <= 0).any():
            raise ValueError(f'cached {name} lights must be off-center')

    output = Path(output)
    output.mkdir(parents=True, exist_ok=False)
    target = output / 'theta_joint'
    target.mkdir()
    preserved_roots = (
        SOURCE,
        PREVIOUS,
        r.REFRESH_ROOT / sample / 'refresh_20261006',
    )
    prior_stats = {
        str(path): r._file_stat(path)
        for root in preserved_roots if root.exists()
        for path in root.rglob('*') if path.is_file()
    }
    name = variant_id(constants, weight)
    source_identity = {'path': str(cached_prediction), 'file_stat': r._file_stat(cached_prediction), 'array': 'original'}
    plan = {
        'schema': 'nfplight.cue-constraints-variant.v1',
        'sample': sample,
        'variant_id': name,
        'active_samples': [sample],
        'spatial_constants': {sample: list(constants)},
        'constant_initialization': 'spatial mean; normal uses normalized mean of unit normals',
        'objective': f'centered measured MSE + {weight:g} mean40 off-center preservation MSE',
        'preservation_weight': weight,
        'measured_train_count': 1,
        'preservation_train_count': 40,
        'evaluation_count': 40,
        'F0': 0.04,
        'q_policy': 'reuse source fitted q, frozen',
        'q': q,
        'initialization': 'cached original pretrained prediction; project spatial constants; fix F0=0.04; fresh Adam',
        'original_prediction_source': source_identity,
        'source_metrics': {'path': str(source_metrics), 'file_stat': r._file_stat(source_metrics)},
        'source_condition': {'path': str(source_condition), 'file_stat': r._file_stat(source_condition)},
        'max_steps': MAX_STEPS,
        'min_steps': 300,
        'window_steps': 100,
        'stability': 'relative total-loss span <= 0.001; mean normal change <= 0.001 degrees; mean absolute diffuse/roughness change <= 1e-5',
        'learning_rate': LEARNING_RATE,
        'seed': 0,
        'fresh_optimizer': True,
        'precision': 'FP32',
        'light_chunk_size': 8,
        'snapshot_schedule': 'every 300 steps and terminal; lossless step 0 and terminal',
        'environment': {'python': sys.version, 'torch': torch.__version__, 'platform': platform.platform()},
    }
    r._json(output / 'plan.json', plan)

    prediction = torch.from_numpy(original_array.copy()).to(device=device, dtype=torch.float32)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    render = r._make_renderer(device)
    near, far, provenance = r.reconstruct_selected_pair(
        sample=sample,
        refresh=r.REFRESH_ROOT / sample / 'refresh_20261006',
    )
    frames, states = [], []

    def snapshot(step, state, final):
        if (step % 300 == 0 or final) and not any(frame['step'] == step for frame in frames):
            states.append(state.cpu().clone())
            frames.append({'step': step, 'path': f'theta_joint/step_{step:05d}.webp'})
        if step % 500 == 0:
            print(sample, variant_id(constants, weight), step, flush=True)

    result = r.analyze_condition(
        prediction,
        render,
        train,
        test,
        q,
        mode='fixed',
        regime=f'cue_constraints_{variant_id(constants, weight)}',
        steps=MAX_STEPS,
        lr=LEARNING_RATE,
        seed=0,
        stability=True,
        snapshot_callback=snapshot,
        light_chunk_size=8,
        measured_target=near.to(device),
        measured_light=r.ring(0, device=device),
        preservation_weight=weight,
        spatial_constants=constants,
    )
    for state_name in ('initial', 'last'):
        state = result[state_name]
        for name, sl in (('n', slice(0, 3)), ('d', slice(3, 6)), ('r', slice(6, 7))):
            if name in constants:
                value = state[:, sl]
                if not torch.equal(value, value[:, :, :1, :1].expand_as(value)):
                    raise RuntimeError(f'{state_name} {name} is not spatially constant')
    if len(frames) > 40:
        raise RuntimeError(f'snapshot limit exceeded: {len(frames)}')

    condition = {
        key: result[key]
        for key in ('train_light_count', 'best_step', 'termination', 'metrics', 'trajectory', 'objective')
    }
    condition.update(
        theta_deg='joint',
        train_xyz=train.cpu().tolist(),
        evaluation_xyz=test.cpu().tolist(),
        frames=frames,
        display_scales=r.display_scales(prediction.cpu(), states),
    )
    r._json(target / 'condition.json', condition)
    r._json(target / 'display_scales.json', condition['display_scales'])
    r.save_frame(output / 'original.webp', prediction.cpu(), prediction.cpu(), condition['display_scales'])
    for frame, state in zip(frames, states):
        r.save_frame(
            output / frame['path'],
            prediction.cpu(),
            state,
            condition['display_scales'],
            lossless=frame['step'] in (0, frames[-1]['step']),
        )
    np.savez_compressed(
        target / 'render_materials.npz',
        original=prediction.cpu().numpy(),
        initial=result['initial'].cpu().numpy(),
        updated=result['last'].cpu().numpy(),
        best=result['best'].cpu().numpy(),
    )
    torch.save(result['checkpoint'], target / 'terminal_optimizer.pth')
    base.save_render_comparison(target, prediction, result['last'], near, far, render, q, provenance)
    for stage in ('original', 'updated'):
        shutil.copyfile(target / f'render_{stage}.webp', target / f'center_{stage}.webp')
    base.make_plots(target, condition['trajectory'])

    record = {
        'sample': sample,
        'mode': 'joint',
        'variant_id': name,
        'spatial_constants': list(constants),
        'preservation_weight': weight,
        'prediction_source': source_identity,
        'provenance': provenance,
        'lamp_intensity': metadata['lamp_intensity'],
        'display_scales': condition['display_scales'],
        'conditions': [condition],
    }
    compact_condition = {
        key: value for key, value in condition.items() if key != 'trajectory'
    } | {'condition_path': 'theta_joint/condition.json'}
    compact_record = {**record, 'conditions': [compact_condition]}
    r._json(output / 'metrics.json', compact_record)

    audit = audit_variant(output)
    record['final_loss_audit'] = audit
    compact_record['final_loss_audit'] = audit
    r._json(output / 'metrics.json', compact_record)
    r._json(output / 'summary.json', {'plan': plan, 'samples': [compact_record]})

    changed = [path for path, stat in prior_stats.items() if r._file_stat(Path(path)) != stat]
    if changed:
        raise RuntimeError(f'prior inputs changed during the run: {changed[:5]}')
    r._json(output / 'checks.json', {
        'prior_files_unchanged': len(prior_stats),
        'cached_prediction_key': 'original',
        'cached_prediction_dtype': str(prediction.dtype),
        'FP32': prediction.dtype == torch.float32,
        'fresh_optimizer': True,
        'initial_and_terminal_spatial_constants_verified': list(constants),
        'train_count': int(train.shape[0]),
        'evaluation_count': int(test.shape[0]),
        'sha256_executed': False,
    })
    print('COMPLETE', output, result['termination'], flush=True)


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        return _legacy_main()
    parser = argparse.ArgumentParser(description='Run one fresh FP32 cue-constrained refinement variant.')
    parser.add_argument('--sample', required=True, choices=tuple(VARIANT_CONSTANTS))
    parser.add_argument('--constants', required=True, type=parse_constants, help='spatially constant maps, e.g. d or d,r')
    parser.add_argument('--lambda', dest='preservation_weight', required=True, type=float, choices=PRESERVATION_WEIGHTS)
    parser.add_argument('--out', required=True, type=Path, help='fresh variant directory')
    args = parser.parse_args(argv)
    run_variant(args.sample, args.constants, args.preservation_weight, args.out)


if __name__ == '__main__':
    main()
