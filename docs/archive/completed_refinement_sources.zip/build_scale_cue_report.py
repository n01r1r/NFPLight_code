"""Evaluate saved pilot maps consistently and generate image comparisons."""
import json
from pathlib import Path

import fitz
import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from reportlab.lib.pagesizes import A3, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

from capture_processing.color_cue import build_color_cue_context, evaluate_color_cue
from capture_processing.rendering_loss_analysis import physical_maps, validate_analysis_links
from run_scale_cue_experiment import SAMPLES, SOURCE, VARIANTS as EXPERIMENT_VARIANTS
from run_spherical_refinement import tile, _json

ROOT = Path('artifacts/scale_cue_20261007')
VARIANTS = {key: EXPERIMENT_VARIANTS[key] for key in ('baseline','fullres','lowpass','detail')}
PDF = Path('output/pdf/scale_cue_20261007.pdf')
LABELS = {'original':'Original pred', 'baseline':'No cue', 'fullres':'Full-res cue',
          'lowpass':'Lowpass cue', 'detail':'Lowpass + detail'}


def lowpass9(x):
    return F.avg_pool2d(F.pad(x, (4,4,4,4), mode='reflect'), 9, stride=1)


def main():
    torch.set_num_threads(1)
    records = []
    html = ['<!doctype html><html lang="ko"><meta charset="utf-8"><style>'
            'body{font:16px/1.65 Georgia,Batang,serif;margin:36px auto;max-width:1250px;padding:20px}'
            'table{border-collapse:collapse;width:100%;margin:20px 0}th,td{padding:8px;border-bottom:1px solid #ddd}'
            'img{max-width:100%}.maps td{width:18%}.maps img{width:100%}</style>'
            '<h1>색 cue와 실밥 수준 normal: 1,000-step 탐색 비교</h1>'
            '<p>모든 조건은 원본 pretrained pred에서 fresh Adam으로 시작한다. FP32, F0=.04 및 q 고정. '
            '078 주 사례 / 478 stress 사례. 최적화 대상은 픽셀별 n/d/r이다.</p>'
            '<p>손실 = 실측 I_N MSE + 0.1×40방향 보존 MSE + 0.1R0×cue + 선택적으로 R0×detail. '
            'cue는 국소 색도 공분산이며 lowpass는9px, 주변 영역은31px이다. '
            'R0는 초기 고정-F0 measured MSE. 가중치는 검증된 최적값이 아닌 탐색 설정이다.</p>'
            '<p>같은 evaluator의 cue ratio가 작을수록 색도와 맵의 동반 변화가 작다. '
            '이 값은 직접 최적화한 지표이며 독립 검증이 아니다. '
            'HF RMS ratio와 cosine은 원본 미세 normal과의 크기·방향 유사도이며 정답 정확도가 아니다.</p>'
            '<p><a href="../../output/pdf/scale_cue_20261007.pdf">비교 PDF</a> · '
            '<a href="metrics.json">전체 수치</a> · <a href="../../docs/cue_multiscale_design.md">설계와 반례</a></p>']
    for sample in SAMPLES:
        figures = ROOT/'figures'/sample
        figures.mkdir(parents=True, exist_ok=True)
        with np.load(ROOT/'baseline'/sample/'materials.npz') as data:
            original = torch.from_numpy(data['original'].copy())
            near = torch.from_numpy(data['near'].copy())
            original_render = torch.from_numpy(data['render_original'].copy())
        initial = physical_maps(original)
        contexts = {k:build_color_cue_context(initial['normal'], initial['roughness'], near,
                    lowpass_kernel=k, local_kernel=31) for k in (1,9)}
        hp0 = initial['normal']-lowpass9(initial['normal'])
        energy0 = float(hp0.square().mean())
        sample_rows = []
        for name in ('original', *VARIANTS):
            result = None
            if name == 'original':
                material, rendered = original, original_render
            else:
                with np.load(ROOT/name/sample/'materials.npz') as data:
                    np.testing.assert_array_equal(data['original'], original.numpy())
                    np.testing.assert_array_equal(data['near'], near.numpy())
                    material = torch.from_numpy(data['updated'].copy())
                    rendered = torch.from_numpy(data['render_final'].copy())
                result = json.loads((ROOT/name/sample/'result.json').read_text(encoding='utf-8'))
            maps = physical_maps(material)
            hp = maps['normal']-lowpass9(maps['normal'])
            energy = float(hp.square().mean())
            metrics = dict(measured_mse=float((rendered-near).square().mean()),
                           hp_rms_ratio=(energy/energy0)**.5 if energy0>1e-8 else None,
                           hp_relative_error=float((hp-hp0).square().mean()/energy0)**.5 if energy0>1e-8 else None,
                           hp_cosine=float((hp*hp0).mean())/(energy*energy0)**.5 if min(energy,energy0)>1e-8 else None,
                           roughness_std=float(maps['roughness'].std(unbiased=False)),
                           roughness_hp_rms=float((maps['roughness']-lowpass9(maps['roughness'])).square().mean().sqrt()),
                           normal_component_std_rms=float(maps['normal'].var(dim=(-2,-1),unbiased=False).mean().sqrt()))
            for k, context in contexts.items():
                terms = evaluate_color_cue(maps['normal'],maps['roughness'],context)
                metrics[f'cue_k{k}'] = float(terms['cue_loss'])
                for field in ('normal','roughness'):
                    metrics[f'{field}_cue_k{k}_raw'] = float(terms[f'{field}_cue_raw'])
                    metrics[f'{field}_cue_k{k}_initial'] = float(getattr(context,f'{field}_scale'))
                    metrics[f'{field}_cue_k{k}_ratio'] = (float(terms[f'{field}_cue_raw']/getattr(context,f'{field}_scale'))
                                                         if getattr(context,f'{field}_active') else None)
            if result:
                last = result['trajectory'][-1]
                np.testing.assert_allclose(metrics['measured_mse'],last['measured_mse'],rtol=2e-5,atol=1e-8)
                if 'cue_contract' in result['objective']:
                    contract = result['objective']['cue_contract']
                    terms = evaluate_color_cue(maps['normal'], maps['roughness'],
                                              contexts[contract['config']['lowpass_kernel']])
                    np.testing.assert_allclose(float(terms['cue_loss']), last['cue_loss'],rtol=.002,atol=1e-6)
                    np.testing.assert_allclose(float(terms['normal_detail_loss']),last['normal_detail_loss'],rtol=.002,atol=1e-6)
                    expected_total=(last['measured_mse']+.1*last['preservation_mse']+
                                    last['weighted_cue_loss']+last['weighted_normal_detail_loss'])
                    np.testing.assert_allclose(expected_total,last['total_loss'],rtol=2e-5,atol=1e-8)
                metrics.update(preservation_mse=last['preservation_mse'], heldout_mse=last['common_heldout_mse'])
            else:
                metrics.update(preservation_mse=0., heldout_mse=0.)
            record = dict(sample=sample, variant=name, metrics=metrics)
            records.append(record);sample_rows.append(record)
            for key in ('normal','diffuse','roughness'):
                value = maps[key][0]
                if key=='normal': value=(value+1)/2
                elif key=='diffuse': value=value.clamp(0,1).pow(1/2.2)
                tile(value).save(figures/f'{name}_{key}.png')
            tile(rendered[0].clamp(0,1).pow(1/2.2)).save(figures/f'{name}_render.png')
            tile(((maps['normal'][0]+1)/2)[:,96:160,96:160]).resize((256,256),Image.Resampling.NEAREST).save(figures/f'{name}_crop.png')
        tile(near[0].clamp(0,1).pow(1/2.2)).save(figures/'measured.png')
        html.append(f'<h2>{sample}</h2><table><tr><th>조건</th><th>실측 MSE</th><th>보존 MSE</th><th>cue k9</th><th>HF RMS</th><th>HF cosine</th><th>HF error</th></tr>')
        for row in sample_rows:
            m=row['metrics']
            html.append('<tr><td>'+LABELS[row['variant']]+'</td>'+''.join(f'<td>{m[k]:.5g}</td>' if m[k] is not None else '<td>inactive</td>' for k in ('measured_mse','preservation_mse','cue_k9','hp_rms_ratio','hp_cosine','hp_relative_error'))+'</tr>')
        html.append('</table><p>Normal 확대: 모든 조건에서 동일한 중앙 64×64 영역. Diffuse·render는 gamma1/2.2 표시.</p><table class="maps"><tr><th>조건</th><th>Normal</th><th>Diffuse</th><th>Roughness</th><th>Render</th><th>Normal crop</th></tr>')
        for name in ('original',*VARIANTS):
            html.append(f'<tr><th>{LABELS[name]}</th>'+''.join(f'<td><img src="figures/{sample}/{name}_{key}.png" alt="{name} {key}"></td>' for key in ('normal','diffuse','roughness','render','crop'))+'</tr>')
        html.append('</table>')
    _json(ROOT/'metrics.json', dict(records=records, definitions={
        'cue':'local covariance-based map energy normalized to original; k1/k9 are evaluation lowpass pixels; initial inactive gives null component ratio',
        'hp':'unit-normal residual N-box9(N); original RMS, phase-sensitive residual error and cosine; original is not truth',
        'image_mse':'mean over all FP32 linear RGB pixels; original rendering may have original F0 while all optimized use .04',
        'heldout':'40 unoptimized virtual directions compared to original model responses, not measured validation'}))
    html.append('<h2>실제 샘플의 한계: normal 보존과 roughness 우회</h2><p>'
                'Lowpass + detail은 미세 normal의 원본 잔차를 잘 유지했다. 그러나478에서 '
                '원래 해상도 roughness cue ratio는 No cue8.748에서47.747로 증가했다. '
                '동시에 저주파 cue는 감소했으므로, 낮은 주파수의 조건을 만족하면서 '
                '더 미세한 roughness 변화를 허용하는 우회 가능성이 있다. '
                '현재 설정을 기본 refinement로 채택할 근거는 부족하다.</p>')
    html.append('<h2>정답이 있는 합성 검증과 반례</h2><p>렌더링·측정 loss 없이 cue 자체만100회 최적화한 CPU 실험이다. '
                '미세 sinusoid normal과 broad 색 누출을 합친 사례의 평균 정답 각도 오차는 '
                '초기5.418° → fullres3.492° / lowpass3.370° / detail2.757°였다. '
                '반대로 실제 요철이 색과 함께 변하는 사례는 정답에서 시작했음에도 '
                'fullres7.044° / lowpass6.914° / detail3.845°의 오차가 생겼다. '
                '따라서 잔차 보존과 cue 감소만으로 물리적 정답을 판별할 수 없다. '
                '<a href="sol_synthetic_evidence.json">합성 수치·설정</a></p>')
    html.append('<p>1,000 step 고정 예산의 탐색 결과 / 정답 없는 실제 자료에서는 물리적 geometry 복원 성공으로 해석하지 않는다. '
                '회색 무늬에는 색도 cue가 작동하지 않으며 색과 실제 요철이 같이 변하면 잘못 억제할 수 있다.</p></html>')
    (ROOT/'summary.html').write_text(''.join(html),encoding='utf-8')
    build_pdf(records)
    assert not validate_analysis_links(''.join(html),ROOT)


def build_pdf(records):
    pdfmetrics.registerFont(TTFont('KR','C:/Windows/Fonts/batang.ttc',subfontIndex=0))
    pdfmetrics.registerFont(TTFont('EN','C:/Windows/Fonts/georgia.ttf'))
    W,H=landscape(A3)
    pdf=canvas.Canvas(str(PDF),pagesize=(W,H),pageCompression=1)
    pdf.setTitle('Color cue / fine normal pilot - 078 and 478')
    def text(x,y,value,size=12,font='KR'):
        pdf.setFont(font,size);pdf.drawString(x,y,value)
    text(40,H-50,'색 cue와 미세 normal 보존: 통제된 탐색 실험',26)
    lines=['두 샘플 x 네 조건. 원본 pretrained pred에서 1,000 step, FP32, F0=.04 및 q 고정.',
           'No cue / Full-res cue(k1) / Lowpass cue(k9) / Lowpass + detail(k9). 국소 covariance 영역31px.',
           '공간 상수는 쓰지 않는다. n/d/r이 픽셀별로 변하며 색과 동반되는 맵 성분에 soft penalty를 준다.',
           'HF는9px 평균을 뺀 normal 잔차. 원본 잔차와 유사하다는 뜻이며 실밥의 정답 normal이라는 뜻은 아니다.',
           '학습 cue 감소는 직접 최적화한 지표의 감소다. 가상 조명도 추가 실측 자료가 아니다.',
           '회색 패턴에 취약하며 실제 geometry가 색과 함께 바뀌면 cue가 이를 잘못 억제할 수 있다.']
    for i,line in enumerate(lines): text(40,H-88-i*24,line,13)
    y=H-270
    for sample in SAMPLES:
        text(40,y,sample,18);y-=35
        headings=['Condition','Measured MSE','Preservation','Cue k9','HF RMS ratio','HF cosine','HF error']
        xs=[40,235,435,615,750,905,1045]
        for x,h in zip(xs,headings):text(x,y,h,12,'EN')
        for row in (r for r in records if r['sample']==sample):
            y-=30;text(40,y,LABELS[row['variant']],13,'EN')
            for x,key in zip(xs[1:],('measured_mse','preservation_mse','cue_k9','hp_rms_ratio','hp_cosine','hp_relative_error')):
                value=row['metrics'][key];text(x,y,f'{value:.5g}' if value is not None else 'inactive',12,'EN')
        y-=60
    text(40,85,'478의 미세 roughness 경고: full-resolution roughness cue ratio 8.748 -> 47.747 (No cue -> Lowpass + detail).',13)
    text(40,61,'저주파 cue 감소와 미세 normal 보존만으로 채택할 수 없다. roughness의 대역 우회 가능성을 추가 검증해야 한다.',13)
    text(40,30,'Fixed 1000-step pilot; convergence and physical correctness not established.',11,'EN');pdf.showPage()
    for page,sample in enumerate(SAMPLES,2):
        text(35,H-40,f'{sample[-3:]} | 재질 맵과 렌더링 비교',23)
        text(35,H-63,'동일한 원본에서 시작 / normal 확대는 중앙 64x64 / diffuse 및 render gamma1/2.2',11)
        xs=[220+i*186 for i in range(5)];size=132
        for x,label in zip(xs,['Normal','Diffuse','Roughness','Render','Normal crop']):text(x,H-90,label,13,'EN')
        for i,name in enumerate(('original',*VARIANTS)):
            y=H-232-i*143;text(35,y+size/2,LABELS[name],14,'EN')
            for x,key in zip(xs,['normal','diffuse','roughness','render','crop']):
                pdf.drawImage(ImageReader(str(ROOT/'figures'/sample/f'{name}_{key}.png')),x,y,width=size,height=size)
        text(35,22,f'{page}/3 | pixel-scale comparison; no ground-truth maps',10,'EN');pdf.showPage()
    pdf.save()
    previews=Path('tmp/pdfs/scale_cue');previews.mkdir(parents=True,exist_ok=True)
    with fitz.open(PDF) as doc:
        assert len(doc)==3
        for index,page in enumerate(doc):
            assert page.get_text().strip()
            page.get_pixmap(matrix=fitz.Matrix(1,1)).save(previews/f'page_{index+1}.png')


if __name__=='__main__':
    main()
