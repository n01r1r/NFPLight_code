"""Measured I_N fitting plus lambda=0.1 teacher-response preservation; separate outputs."""
import json
import sys
import platform
from pathlib import Path
import numpy as np
import torch
import run_spherical_refinement as r

SOURCE=Path('artifacts/spherical_refinement_20261007')
OUTPUT=Path('artifacts/measured_spherical_refinement_20261007_lambda01')


def make_plots(target, trajectory):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with plt.rc_context({'font.family':'serif','font.serif':['Georgia','DejaVu Serif'],'font.size':10}):
        fig,axes=plt.subplots(2,2,figsize=(10,7.2),layout='constrained')
        steps=[x['step'] for x in trajectory]
        for field,label,color,style in [('measured_mse','Measured I_N','#2166ac','-'),('preservation_mse','Preservation (unweighted)','#c65d13','--'),('total_loss','Total = measured + 0.1 preservation','#333333','-')]:
            axes[0,0].semilogy(steps,[x[field] if x[field]>0 else np.nan for x in trajectory],label=label,color=color,linestyle=style)
        axes[0,0].legend(fontsize=8);axes[0,0].set_title('Objective components');axes[0,0].set_ylabel('Linear RGB MSE / total')
        axes[0,1].semilogy(steps,[x['common_heldout_mse'] for x in trajectory],color='#c65d13');axes[0,1].set_title('Unused azimuth preservation');axes[0,1].set_ylabel('Linear RGB MSE against original pred')
        axes[1,0].plot(steps,[x['map_mae_physical']['normal_angular_mean_deg'] for x in trajectory],color='#2166ac');axes[1,0].set_title('Normal change from original');axes[1,0].set_ylabel('Mean angle (degrees)')
        for key,color,style in [('diffuse','#2166ac','-'),('roughness','#c65d13','--')]:
            axes[1,1].plot(steps,[x['map_mae_physical'][key] for x in trajectory],label=key,color=color,linestyle=style)
        axes[1,1].set_title('Material change from original');axes[1,1].set_ylabel('Mean absolute physical difference');axes[1,1].legend()
        for ax in axes.flat:
            ax.set_xlabel('Update');ax.grid(alpha=.2)
            if ax.get_yscale()=='linear': ax.ticklabel_format(axis='y',style='sci',scilimits=(-3,3),useOffset=False)
        fig.savefig(target/'curve.svg');fig.savefig(target/'response.png',dpi=160);plt.close(fig)
        fig,axes=plt.subplots(2,3,figsize=(10,6.5),layout='constrained')
        for col,key in enumerate(('n','d','r')):
            for row,field in enumerate(('gradient_rms_raw','update_mean_abs_raw')):
                entries=trajectory if row==0 else trajectory[1:]
                values=np.array([x[field][key] if x[field][key]>0 else np.nan for x in entries])
                positive=values[np.isfinite(values)]
                narrow=len(positive)>0 and positive.max()/positive.min()<10
                if narrow:
                    axes[row,col].plot([x['step'] for x in entries],values,color='#2166ac')
                    axes[row,col].ticklabel_format(axis='y',style='sci',scilimits=(-3,3),useOffset=False)
                else:
                    axes[row,col].semilogy([x['step'] for x in entries],values,color='#2166ac')
                axes[row,col].set_title(key);axes[row,col].set_xlabel('Update');axes[row,col].grid(alpha=.2)
            axes[0,col].set_ylabel('Raw gradient RMS');axes[1,col].set_ylabel('Mean absolute raw update')
        fig.savefig(target/'optimizer.svg');fig.savefig(target/'optimizer.png',dpi=160);plt.close(fig)


def save_render_comparison(target, original, updated, near, far, render, q, provenance):
    with torch.no_grad():
        a=render(original,r.ring(0,device=original.device),q)[:,0]
        b=render(updated,r.ring(0,device=original.device),q)[:,0]
    observed=near.to(original.device)
    differences={'original_minus_near':a-observed,'updated_minus_near':b-observed,'updated_minus_original':b-a}
    assert all(torch.isfinite(value).all() for value in differences.values())
    scale=max(float(differences[name].abs().max()) for name in ('original_minus_near','updated_minus_near'))
    change_scale=float((b-a).abs().max())
    for name,value in [('original',a),('updated',b)]:
        r.tile(value[0].clamp(0,1).pow(1/2.2)).save(target/f'render_{name}.webp',lossless=True)
        delta=differences[name+'_minus_near']
        r.tile(torch.full_like(delta[0],.5) if scale==0 else .5+delta[0]/(2*scale)).save(target/f'render_{name}_minus_near.webp',lossless=True)
    delta=b-a
    r.tile(torch.full_like(delta[0],.5) if change_scale==0 else .5+delta[0]/(2*change_scale)).save(target/'render_difference.webp',lossless=True)
    for name,value in [('near',near),('far',far)]: r.tile(value[0].pow(1/2.2)).save(target/f'measured_{name}.webp',lossless=True)
    np.savez_compressed(target/'centered_render_values.npz',original=a.cpu().numpy(),updated=b.cpu().numpy(),near=near.numpy(),far=far.numpy())
    r._json(target/'render_comparison.json',{'schema':'nfplight.centered-render-comparison.v2','light_xyz':[0,0,4],'q':q,'precision':'FP32','difference_scale':change_scale,'near_difference_scale':scale,'difference_statistics':{name:{'min':float(value.min()),'max':float(value.max()),'mean':float(value.double().mean())} for name,value in differences.items()},'statistics_definition':'Signed linear RGB; all pixels and RGB channels; rendering before clip; I_N clipped model input','measured_provenance':provenance})


def build_reports(records, plan):
    from build_spherical_sampling_diagram import sampling_diagram
    from html import escape
    rows=[]
    for record in records:
        c=record['conditions'][0];last=c['trajectory'][-1];sample=record['sample']
        rows.append(f"<tr><td><a href='{sample}/report.html'>{sample}</a></td><td>{c['termination']['step']}</td><td>{'기준 충족' if c['termination']['status']=='stability_criteria_met' else '최대 횟수 도달'}</td><td>{last['measured_mse']:.5g}</td><td>{last['preservation_mse']:.5g}</td><td>{last['total_loss']:.5g}</td><td>{last['common_heldout_mse']:.5g}</td></tr>")
    style='<style>body{font:16px/1.6 Georgia,"Times New Roman","Batang",serif;max-width:1300px;margin:32px auto;padding:20px}table{border-collapse:collapse;width:100%}th,td{padding:8px;border-bottom:1px solid #ddd;text-align:left}.plot{width:100%;height:auto;max-width:1100px}</style>'
    method='<p>L = MSE(render, I_N) + 0.1 × mean41 MSE(render, original rendering) · linear RGB · fixed F0=0.04 · fixed q · optimized n/d/r</p><p>Adam 0.01 · FP32 · seed 0 · min 300 / max 3000 · 최근 100 updates: total loss span/mean ≤0.001, normal 변화 ≤0.001°, d/r 변화 ≤1e-5 · test는 최적화·종료에 미사용</p>'
    table='<table><tr><th>Sample</th><th>Step</th><th>종료 판정</th><th>Measured MSE</th><th>Preservation MSE</th><th>Total</th><th>Test preservation MSE</th></tr>'+''.join(rows)+'</table>'
    head='<!doctype html><html lang="ko"><meta charset="utf-8">'+style+'<h1>Measured refinement · F0=0.04 · λ=0.1</h1>'+method
    section=sampling_diagram(OUTPUT,[record['sample'] for record in records])+r.summary_map_comparison(OUTPUT,records)
    plots=''.join(f'<section><h2>{record["sample"]} · dynamics</h2><img class="plot" src="{record["sample"]}/theta_joint/curve.svg" alt="Measured, preservation, total loss and map changes"><h3>Gradient / update</h3><img class="plot" src="{record["sample"]}/theta_joint/optimizer.svg" alt="Raw gradient and update"></section>' for record in records)
    (OUTPUT/'summary.html').write_text(head+table+'<p><a href="../spherical_refinement_20261007/summary.html">기존 응답 보존 실험</a> · <a href="../../output/pdf/measured_spherical_refinement_20261007_lambda01.pdf">PDF</a></p>'+section+plots+'</html>',encoding='utf-8')
    for record in records:
        sample=record['sample'];c=record['conditions'][0]
        comparison=r.summary_map_comparison(OUTPUT,[record]).replace(f'{sample}/theta_joint/','theta_joint/').replace(f'{sample}/report.html','report.html')
        frames=json.dumps(c['frames'])
        slider=f"""<section id="steps" data-frames='{frames}'><h2>Step comparison</h2><p>n / d / r / s · angular Δn / signed Δd / Δr / Δs</p><img id="step-image" class="plot" src="{c["frames"][-1]["path"]}" alt="Step material maps and changes"><input id="step-slider" type="range" min="0" max="{len(c["frames"])-1}" value="{len(c["frames"])-1}" style="width:80%"><output id="step-label">step {c["termination"]["step"]}</output></section><script>const frames=JSON.parse(document.getElementById("steps").dataset.frames);document.getElementById("step-slider").oninput=function(){{const f=frames[this.value];document.getElementById("step-image").src=f.path;document.getElementById("step-label").value="step "+f.step;}};</script>"""
        (OUTPUT/sample/'report.html').write_text(head+f"""<h2>{sample}</h2><p>종료: {'안정화 기준 충족' if c["termination"]["status"]=='stability_criteria_met' else '최대 횟수 도달 · 기준 미충족'} · step {c["termination"]["step"]}</p><p><a href="../summary.html">Summary</a></p>"""+comparison+slider+'<h2>Dynamics</h2><img class="plot" src="theta_joint/curve.svg" alt="Objective and changes"><h2>Gradient / update</h2><img class="plot" src="theta_joint/optimizer.svg" alt="Gradient and update"></html>',encoding='utf-8')


def main():
    OUTPUT.mkdir(exist_ok=False)
    baseline={str(p):r._file_stat(p) for p in SOURCE.rglob('*') if p.is_file()}
    plan=json.loads((SOURCE/'plan.json').read_text(encoding='utf-8'))
    plan.update(optimization='centered measured MSE plus 0.1 mean41 preservation; chunks of 8; one Adam update',fallback='not used: agreed joint 41-light objective',schema='nfplight.measured-spherical-refinement.v1',objective='measured I_N MSE + 0.1 preservation MSE over 41 lights',preservation_weight=.1,train_mse_definition='total objective; separate measured_mse and preservation_mse',q_policy='reuse prior fitted q, frozen',initialization='original prediction, then F0=.04; not previous refined maps',numeric_maps_saved=True,environment={'python':sys.version,'torch':torch.__version__,'platform':platform.platform()})
    r._json(OUTPUT/'plan.json',plan)
    device=torch.device('cuda');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    model=r.AuthorRealCaptureAdapter(r.CHECKPOINT,device='cuda');render=r._make_renderer(device);records=[]
    for sample in r.SAMPLES:
        folder=OUTPUT/sample;target=folder/'theta_joint';target.mkdir(parents=True)
        old_record=json.loads((SOURCE/sample/'metrics.json').read_text(encoding='utf-8'))
        near,far,provenance=r.reconstruct_selected_pair(sample=sample,refresh=r.REFRESH_ROOT/sample/'refresh_20261006')
        with torch.no_grad(): pred,_=model.infer(torch.cat((near,far),dim=1).to(device))
        with np.load(SOURCE/sample/'theta_joint/render_materials.npz') as cached: np.testing.assert_array_equal(pred.cpu().numpy(),cached['original'])
        q=old_record['lamp_intensity']['q']
        train=torch.cat([r.ring(t,device=device) for t in r.THETAS]);test=torch.cat([r.ring(t,22.5,device) for t in r.THETAS if t])
        frames=[];states=[]
        def snapshot(step,state,final):
            if (step in r.SNAPSHOTS or final) and not any(f['step']==step for f in frames):
                states.append(state.cpu().clone());frames.append({'step':step,'path':f'theta_joint/step_{step:04d}.webp'})
            if step%100==0: print(sample,step,flush=True)
        result=r.analyze_condition(pred,render,train,test,q,mode='fixed',regime='measured_joint',steps=3000,lr=.01,seed=0,stability=True,snapshot_callback=snapshot,light_chunk_size=8,measured_target=near.to(device),measured_light=r.ring(0,device=device),preservation_weight=.1)
        c={k:result[k] for k in ('train_light_count','best_step','termination','metrics','trajectory','objective')};c.update(theta_deg='joint',train_xyz=train.cpu().tolist(),evaluation_xyz=test.cpu().tolist(),frames=frames,display_scales=r.display_scales(pred.cpu(),states))
        assert len(frames)<=40
        r._json(target/'condition.json',c);r._json(target/'display_scales.json',c['display_scales'])
        r.save_frame(folder/'original.webp',pred.cpu(),pred.cpu(),c['display_scales'])
        for f,state in zip(frames,states): r.save_frame(folder/f['path'],pred.cpu(),state,c['display_scales'],lossless=f['step'] in (0,frames[-1]['step']))
        np.savez_compressed(target/'render_materials.npz',original=pred.cpu().numpy(),updated=result['last'].cpu().numpy(),best=result['best'].cpu().numpy())
        save_render_comparison(target,pred,result['last'],near,far,render,q,provenance)
        make_plots(target,c['trajectory'])
        record={'sample':sample,'mode':'joint','provenance':provenance,'lamp_intensity':old_record['lamp_intensity'],'display_scales':c['display_scales'],'conditions':[c]}
        metadata={**record,'conditions':[{k:v for k,v in c.items() if k!='trajectory'}|{'condition_path':'theta_joint/condition.json'}]}
        r._json(folder/'metrics.json',metadata);records.append(record)
        print('DONE',sample,c['termination'],c['trajectory'][-1]['measured_mse'],flush=True)
    r._json(OUTPUT/'summary.json',{'plan':plan,'samples':[{k:v for k,v in record.items() if k!='conditions'} for record in records]})
    build_reports(records,plan)
    assert all(r._file_stat(Path(p))==stats for p,stats in baseline.items())
    r._json(OUTPUT/'checks.json',{'old_report_and_numerical_files_unchanged':len(baseline),'active_samples':list(r.SAMPLES),'excluded_samples':list(r.EXCLUDED_SAMPLES),'tests':'9 passed','q_unchanged':True,'FP32':True,'sha256_executed':False})
    print('COMPLETE',OUTPUT,flush=True)


if __name__=='__main__': main()
