"""Run prediction-only fixed-F0 refinement for one reviewed capture sample."""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image, ImageDraw

from capture_processing.burst import _warp_stages
from capture_processing.memory_refresh import _linear
from capture_processing.prediction_refinement import (
    estimate_lamp_intensity,
    refine_prediction,
)
from capture_processing.refinement_report import (
    build_index_refinement_summary,
    build_refinement_section,
    insert_refinement_section,
    validate_refinement_links,
)
from model.author_real_capture_adapter import AuthorRealCaptureAdapter
from run_fabric_capture import CAPTURE_GROUPS
from utils.render_util import svBRDF


SAMPLE = "260930_152732_008"
SAMPLES = tuple(CAPTURE_GROUPS)
ARCHIVE_ROOT = Path("artifacts/fabric_capture_20261002_paper_equations")
REFRESH_ROOT = Path("artifacts/fabric_capture_20261002_aligned_paper_equations")
ARCHIVE = ARCHIVE_ROOT / SAMPLE
REFRESH = REFRESH_ROOT / SAMPLE / "refresh_20261006"
CHECKPOINT = Path("checkpoints/net_g_real.pth")
DEFAULT_OUT = Path("artifacts") / f"prediction_refinement_20261006_{SAMPLE}"
DEFAULT_ALL_OUT = Path("artifacts/prediction_refinement_20261006_all_samples")


def _json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def _load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def _file_stat(path: Path) -> dict[str, int]:
    stat = path.stat()
    return {"size_bytes": int(stat.st_size), "mtime_ns": int(stat.st_mtime_ns)}


def select_frame_indices(refresh_manifest: dict, sample: str) -> tuple[dict[str, list[int]], bool]:
    if sample not in SAMPLES:
        raise ValueError(f"unsupported sample: {sample}")
    selected = refresh_manifest.get("selected_frames")
    if not isinstance(selected, dict):
        raise ValueError("refresh manifest has no selected_frames")
    indices = selected.get("selected_indices")
    if not isinstance(indices, dict) or any(side not in indices for side in ("near", "far")):
        raise ValueError("refresh manifest has no near/far selected_indices")
    parsed = {side: [int(index) for index in indices[side]] for side in ("near", "far")}
    if any(not values or any(index < 0 or index > 4 for index in values) for values in parsed.values()):
        raise ValueError("refresh manifest selected_indices are invalid")
    averaged = bool(selected.get("averaged"))
    return parsed, averaged


def average_selected_counts(counts: list[np.ndarray]) -> np.ndarray:
    """Average aligned camera counts before applying the nonlinear color transform."""
    if not counts:
        raise ValueError("selected counts are empty")
    if len(counts) == 1:
        result = counts[0]
    else:
        result = np.mean(np.stack(counts, axis=0), axis=0, dtype=np.float32)
    if result.dtype != np.float32 or not np.isfinite(result).all():
        raise ValueError("selected counts must be finite FP32")
    return result


def reconstruct_selected_pair(archive: Path | None = None, refresh: Path | None = None, *, sample: str = SAMPLE) -> tuple[torch.Tensor, torch.Tensor, dict]:
    """Reconstruct the reviewed selected frames from preserved camera RGB in memory."""
    if sample not in SAMPLES:
        raise ValueError(f"unsupported sample: {sample}")
    refresh = refresh or (REFRESH_ROOT / sample / "refresh_20261006")
    # Root review is authoritative for the preserved source archive.
    if archive is None:
        review_path = refresh / "root_review.json"
        review_source = _load_json(review_path).get("source") if review_path.is_file() else None
        archive = Path(review_source) if review_source else ARCHIVE_ROOT / sample
    if not archive.is_dir() or not refresh.is_dir():
        raise FileNotFoundError(f"missing archive or refresh registration: {archive}, {refresh}")
    review = _load_json(refresh / "root_review.json")
    registration = _load_json(refresh / "registration.json")
    if review.get("status") != "reviewed" or not isinstance(review.get("texture_registration_passed"), bool):
        raise ValueError("current root review is not a completed review")
    preparation = _load_json(archive / "preparation.json")
    manifest = _load_json(archive / "manifest.json")
    refresh_manifest = _load_json(refresh / "manifest.json")
    selected, averaged = select_frame_indices(refresh_manifest, sample)
    outputs: dict[str, torch.Tensor] = {}
    provenance: dict = {
        "archive": str(archive.resolve()),
        "refresh_registration": str((refresh / "registration.json").resolve()),
        "root_review": str((refresh / "root_review.json").resolve()),
        "selected_frames": selected,
        "averaged": averaged,
        "registration_reference": registration.get("reference"),
        "review_status": review.get("status"),
        "texture_registration_passed": review.get("texture_registration_passed"),
        "source_frames": {},
        "linear_unclipped_range": {},
        "model_input_range": {},
        "counts_mean": {},
    }
    for side in ("near", "far"):
        counts = []
        for index in selected[side]:
            source = archive / "source_frames" / f"{side}_{index:02d}.npz"
            if not source.is_file():
                raise FileNotFoundError(source)
            with np.load(source, allow_pickle=False) as saved:
                stored = saved["demosaic_rgb_selected_dtype"]
                if stored.dtype != np.float32:
                    raise TypeError(f"preserved camera RGB must be FP32: {source}")
                rgb = np.asarray(stored)
            if not np.isfinite(rgb).all():
                raise ValueError(f"invalid preserved camera RGB: {source}")
            records = registration.get("frames", {}).get(side, [])
            if index >= len(records):
                raise ValueError(f"registration has no {side}_{index:02d}")
            homography = np.asarray(records[index]["alignment"]["homography_final"], dtype=np.float32)
            stages = _warp_stages(rgb, homography)
            counts.append(stages["output256"])
            provenance["source_frames"].setdefault(side, []).append({
                "path": str(source.resolve()),
                "array": "demosaic_rgb_selected_dtype",
                "file_stat": _file_stat(source),
                "homography": homography.tolist(),
            })
        mean_counts = average_selected_counts(counts)
        metadata = preparation["sides"][side]["metadata"][selected[side][0]]
        _, _, linear, clipped = _linear(mean_counts, metadata, manifest["color_transforms"][side])
        if clipped.dtype != np.float32 or not np.isfinite(clipped).all():
            raise ValueError(f"invalid reconstructed model input: {side}")
        outputs[side] = torch.from_numpy(clipped.transpose(2, 0, 1)[None].copy())
        provenance["linear_unclipped_range"][side] = [float(np.min(linear)), float(np.max(linear))]
        provenance["model_input_range"][side] = [float(np.min(clipped)), float(np.max(clipped))]
        provenance["counts_mean"] = {
            "method": "mean aligned output256 counts before _linear" if len(counts) > 1 else "selected output256 counts",
            "near_count": len(selected["near"]), "far_count": len(selected["far"]),
        }
    return outputs["near"], outputs["far"], provenance


def _lights(device: torch.device) -> tuple[torch.Tensor, torch.Tensor, list[str], list[str]]:
    # Coordinates are dimensionless model surface coordinates, in (x,y,z).
    train = torch.tensor([
        [0.0, 0.0, 4.0], [0.0, 0.0, 12.0],
        [1.5, 0.0, 4.0], [-1.5, 0.0, 4.0],
        [0.0, 1.5, 4.0], [0.0, -1.5, 4.0],
    ], dtype=torch.float32, device=device)
    heldout = torch.tensor([[0.8, -0.8, 8.0], [-0.8, 0.8, 8.0]], dtype=torch.float32, device=device)
    return train, heldout, ["near_center", "far_center", "near_right", "near_left", "near_up", "near_down"], ["mid_diag_a", "mid_diag_b"]


def _make_renderer(device: torch.device):
    renderer = svBRDF()
    surface = renderer.surface(256, range=1, dtype=torch.float32, device=device)

    def render(material: torch.Tensor, lights: torch.Tensor, lamp_intensity: float) -> torch.Tensor:
        if material.device != device:
            material = material.to(device=device)
        result = []
        for position in lights:
            one = position.reshape(1, 3)
            light, view, distance, _ = renderer.torch_generate(one, one, surface=surface)
            renderer.lampIntensity = float(lamp_intensity)
            result.append(renderer._render(material, light, view, distance)[:, 0])
        return torch.stack(result, dim=1)

    return render


def _to_uint8(image: np.ndarray) -> np.ndarray:
    return np.rint(np.clip(image, 0.0, 1.0) * 255.0).astype(np.uint8)


def _save_map_sheet(path: Path, prediction: torch.Tensor, title: str) -> None:
    array = ((prediction.detach().cpu().float().numpy()[0] + 1.0) * 0.5)
    labels = ["normal", "diffuse", "roughness", "specular"]
    slices = [(0, 3), (3, 6), (6, 7), (7, 10)]
    sheet = Image.new("RGB", (512 * 4, 560), "#202020")
    draw = ImageDraw.Draw(sheet)
    for column, (label, (start, end)) in enumerate(zip(labels, slices)):
        image = array[start:end]
        if image.shape[0] == 1:
            image = np.repeat(image, 3, axis=0)
        tile = Image.fromarray(_to_uint8(np.transpose(image[:3], (1, 2, 0))), mode="RGB").resize((512, 512))
        sheet.paste(tile, (column * 512, 32))
        draw.text((column * 512 + 8, 8), f"{title} {label}", fill="white")
    sheet.save(path)


def _save_render_sheet(path: Path, reference: torch.Tensor, initial: torch.Tensor, final: torch.Tensor, observed: torch.Tensor) -> None:
    values = [reference[:, 0], initial[:, 0], final[:, 0], observed]
    labels = ["teacher original", "fixed s initial", "refined", "I_N calibration"]
    sheet = Image.new("RGB", (1024, 1024), "#202020")
    draw = ImageDraw.Draw(sheet)
    for index, (value, label) in enumerate(zip(values, labels)):
        x, y = (index % 2) * 512, (index // 2) * 512
        array = value.detach().cpu().float().numpy()[0]
        image = Image.fromarray(_to_uint8(np.transpose(array[:3], (1, 2, 0))), mode="RGB").resize((512, 512))
        sheet.paste(image, (x, y))
        draw.text((x + 8, y + 8), label, fill="white")
    sheet.save(path)


def _tensor_stats(value: torch.Tensor) -> dict[str, float | list[int] | str]:
    return {
        "shape": list(value.shape),
        "dtype": str(value.dtype).replace("torch.", ""),
        "min": float(value.amin()), "max": float(value.amax()), "mean": float(value.mean()),
    }


def _save_component(path: Path, value: torch.Tensor, channels: slice, *, gamma: bool = False) -> None:
    array = value.detach().cpu().float().numpy()[0, channels]
    if array.shape[0] == 1:
        array = np.repeat(array, 3, axis=0)
    array = np.clip(array, 0.0, 1.0)
    if gamma:
        array = np.power(array, 1.0 / 2.2)
    Image.fromarray(_to_uint8(np.transpose(array[:3], (1, 2, 0))), mode="RGB").save(path)


def _save_render(path: Path, value: torch.Tensor, *, gamma: bool = False) -> None:
    array = value.detach().cpu().float().numpy()[0, :3]
    array = np.clip(array, 0.0, 1.0)
    if gamma:
        array = np.power(array, 1.0 / 2.2)
    Image.fromarray(_to_uint8(np.transpose(array, (1, 2, 0))), mode="RGB").save(path)


def run_sample(args: argparse.Namespace, sample: str, output: Path, model: AuthorRealCaptureAdapter) -> dict:
    checkpoint = Path(args.checkpoint)
    if checkpoint.resolve() != CHECKPOINT.resolve():
        raise ValueError("only checkpoints/net_g_real.pth is allowed")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    sample_output = output / sample
    sample_output.mkdir(parents=True, exist_ok=False)
    refresh = REFRESH_ROOT / sample / "refresh_20261006"
    near, far, provenance = reconstruct_selected_pair(sample=sample, refresh=refresh)
    source_stats_before = {side: [item["file_stat"] for item in provenance["source_frames"][side]] for side in ("near", "far")}
    checkpoint_stat_before = _file_stat(checkpoint)
    pair = torch.cat((near, far), dim=1).to(device=device, dtype=torch.float32)
    with torch.no_grad():
        prediction, _ = model.infer(pair)
    render = _make_renderer(device)
    train_lights, heldout_lights, train_names, heldout_names = _lights(device)
    with torch.no_grad():
        unit_near = render(prediction, train_lights[:1], 1.0)[:, 0]
    observed_near = near.to(device=device, dtype=torch.float32)
    lamp = estimate_lamp_intensity(unit_near, observed_near, (observed_near.amax(dim=1) <= 0.95))
    result = refine_prediction(
        prediction, render, train_lights,
        lamp_intensity=float(lamp["q"]), steps=args.steps, lr=args.lr,
        prior_weight=args.prior_weight, seed=args.seed, heldout_lights=heldout_lights,
    )
    refined = result["refined_prediction"]
    initial = result["initial_fixed_prediction"]
    support = observed_near.amax(dim=1) <= 0.95
    with torch.no_grad():
        refined_unit_near = render(refined, train_lights[:1], 1.0)[:, 0]
    post_refined_lamp = estimate_lamp_intensity(refined_unit_near, observed_near, support)
    components = (("normal", slice(0, 3)), ("diffuse", slice(3, 6)), ("roughness", slice(6, 7)), ("specular", slice(7, 10)))
    for stem, channels in components:
        for stage, value in (("original", prediction), ("fixed_f0", initial), ("refined", refined)):
            _save_component(sample_output / f"{stem}_{stage}.png", value, channels)
            if stem in {"diffuse", "specular"}:
                _save_component(sample_output / f"{stem}_{stage}_gamma22.png", value, channels, gamma=True)
    near_teacher, near_initial, near_refined = result["teacher_renders"][:, 0], result["initial_render"][:, 0], result["final_render"][:, 0]
    with torch.no_grad():
        near_refined_recommended = render(refined, train_lights[:1], float(post_refined_lamp["q"]))[:, 0]
    for stem, value in (("near_render_teacher_frozen_q", near_teacher), ("near_render_fixed_f0_frozen_q", near_initial), ("near_render_refined_frozen_q", near_refined), ("near_render_refined_recommended_q", near_refined_recommended), ("near_input", observed_near)):
        _save_render(sample_output / f"{stem}.png", value)
        if stem != "near_input":
            _save_render(sample_output / f"{stem}_gamma22.png", value, gamma=True)
        else:
            _save_render(sample_output / "near_input_gamma22.png", value, gamma=True)
    map_changes = {}
    for name, sl in (("normal", slice(0, 3)), ("diffuse", slice(3, 6)), ("roughness", slice(6, 7)), ("specular", slice(7, 10))):
        delta = (refined[:, sl] - prediction[:, sl]).abs()
        map_changes[name] = {"mean_abs_raw_change": float(delta.mean()), "max_abs_raw_change": float(delta.max())}
    original_near_q = render(prediction, train_lights[:1], float(lamp["q"]))[:, 0]
    refined_near_q = render(refined, train_lights[:1], float(lamp["q"]))[:, 0]
    observed_scalar = observed_near.mean(dim=1)
    scalar_rmse = lambda value: float(torch.sqrt(torch.mean((value.mean(dim=1)[support] - observed_scalar[support]) ** 2)))
    metrics = dict(result["metrics"])
    metrics.update({
        "near_i_n_scalar_rmse_original_at_fitted_q": scalar_rmse(original_near_q),
        "near_i_n_scalar_rmse_refined_at_fitted_q": scalar_rmse(refined_near_q),
        "lamp_intensity": lamp,
        "lamp_intensity_post_refined": post_refined_lamp,
        "train_lights": train_names,
        "heldout_lights": heldout_names,
        "train_lights_xyz": train_lights.detach().cpu().tolist(),
        "heldout_lights_xyz": heldout_lights.detach().cpu().tolist(),
        "fixed_specular_max_abs_error": float((refined[:, 7:] + 0.92).abs().max()),
    })
    provenance["preservation_check"] = {
        "source_frames_unchanged": all(
            [_file_stat(Path(item["path"])) for item in provenance["source_frames"][side]] == source_stats_before[side]
            for side in ("near", "far")
        ),
        "checkpoint_unchanged": _file_stat(checkpoint) == checkpoint_stat_before,
        "sha256_executed": False,
    }
    report = {
        "format": "nfplight.prediction-refinement.v1",
        "sample": sample,
        "selection": {"selected_frames": provenance["selected_frames"], "averaged": provenance["averaged"]},
        "objective": {
            "teacher": "fresh original net_g_real.pth prediction rendered in FP32",
            "student": "fit n/d/r to detached teacher multi-light renders",
            "fixed_specular": {"physical_rgb_f0": 0.04, "raw_rgb": -0.92, "optimizer_excluded": True},
            "real_images_in_loss": False,
            "lamp_intensity": "q fitted once from original prediction unit near render and I_N scalar mean RGB on near unsaturated support; q frozen for teacher/student",
            "loss_formula": "mean((R(student,n,d,r,s=.04)-detach(R(original,n,d,r,s_original)))^2) + prior_weight*mean((student_n/d/r-initial_fixed_n/d/r)^2)",
            "optimization_parameterization": "normal=safe_unit(latent normal); diffuse_raw=2*sigmoid(latent diffuse)-1; effective roughness=.05+.95*sigmoid(latent roughness), encoded to raw",
            "renderer": {"surface_range": [-1, 1], "near_distance": 4.0, "far_distance": 12.0, "camera_is_colocated_with_light": True, "render_clipping": False, "coordinates": "dimensionless (x,y,z)"},
        },
        "config": {"steps": args.steps, "lr": args.lr, "prior_weight": args.prior_weight, "seed": args.seed, "device": str(device), "precision": "FP32", "amp": False, "tf32": False},
        "provenance": provenance,
        "checkpoint": {"path": str(checkpoint.resolve()), "role": "author original estimator only", "file_stat": _file_stat(checkpoint)},
        "metrics": metrics,
        "map_changes": map_changes,
        "tensor_stats": {"near_input": _tensor_stats(near), "far_input": _tensor_stats(far), "original_prediction": _tensor_stats(prediction), "refined_prediction": _tensor_stats(refined)},
        "limitations": ["q is an empirical dimensionless brightness scale, not measured flux", "near/far registration review and selected-frame policy are inherited from current refresh review", "teacher reconstruction is a prediction-consistency experiment, not a material-accuracy validation"],
        "environment": {"python": sys.version, "platform": platform.platform(), "torch": torch.__version__},
        "storage": {"numeric_arrays_saved": False, "files": ["PNG previews and JSON/HTML report only"], "sha256_executed": False},
    }
    _json(sample_output / "metrics.json", report)
    html = f"""<!doctype html><meta charset='utf-8'><title>Prediction refinement {sample}</title>
<h1>Prediction refinement {sample}</h1>
<p>Fixed RGB F0=0.04 (raw -0.92); teacher is the fresh original FP32 prediction. Real images are used only for q intensity calibration.</p>
<p>Training q={lamp['q']:.8g}; default-16 RMSE={lamp['default_rmse']:.8g}; fitted-q RMSE={lamp['fitted_rmse']:.8g}; support={lamp['support_pixels']} pixels.</p>
<p>Post-refined display-only q={post_refined_lamp['q']:.8g}; fitted-q RMSE={post_refined_lamp['fitted_rmse']:.8g}. This q was not used in optimization.</p>
<p>Teacher MSE: initial fixed-s={metrics['initial_teacher_mse']:.8g}; refined={metrics['final_teacher_mse']:.8g}; heldout initial={metrics.get('heldout_initial_teacher_mse', float('nan')):.8g}; heldout refined={metrics.get('heldout_final_teacher_mse', float('nan')):.8g}.</p>
<p>Frozen fitted q near I_N scalar RMSE: original={metrics['near_i_n_scalar_rmse_original_at_fitted_q']:.8g}; refined={metrics['near_i_n_scalar_rmse_refined_at_fitted_q']:.8g}.</p>
<p><a href='normal_original.png'>normal_original</a> · <a href='diffuse_original.png'>diffuse_original</a> · <a href='roughness_original.png'>roughness_original</a> · <a href='specular_original.png'>specular_original</a></p>
<p><a href='metrics.json'>metrics.json</a></p>"""
    (sample_output / "report.html").write_text(html, encoding="utf-8")
    report["sample"] = sample
    report["artifact"] = str(sample_output)
    return report


def _integrate_reports(output: Path, records: list[dict]) -> dict:
    backups = output / "backups"
    backups.mkdir(exist_ok=True)
    checks = []
    for record in records:
        sample = record["sample"]
        group_root = REFRESH_ROOT / sample
        refresh_dir = group_root / "refresh_20261006"
        root_report = group_root / "report.html"
        refresh_report = refresh_dir / "report.html"
        for label, path in (("root", root_report), ("refresh", refresh_report)):
            backup = backups / f"{sample}_{label}_report.html"
            shutil.copyfile(path, backup)
        asset_base = os.path.relpath(Path(record["artifact"]), refresh_dir).replace("\\", "/")
        section = build_refinement_section(sample, record, asset_base)
        for path in (root_report, refresh_report):
            current = path.read_text(encoding="utf-8")
            updated = insert_refinement_section(current, section)
            path.write_text(updated, encoding="utf-8")
            checks.extend(validate_refinement_links(section, refresh_dir))
    index = REFRESH_ROOT / "index.html"
    shutil.copyfile(index, backups / "index.html")
    artifact_rel = os.path.relpath(output, REFRESH_ROOT).replace("\\", "/")
    index_section = build_index_refinement_summary(records, artifact_rel)
    index.write_text(insert_refinement_section(index.read_text(encoding="utf-8"), index_section), encoding="utf-8")
    summary = {"format": "nfplight.prediction-refinement-all.v1", "samples": records, "integration": {"missing_links": checks, "backups": str(backups.resolve()), "sha256_executed": False}}
    _json(output / "summary.json", summary)
    rows = "".join(f"<tr><th>{r['sample']}</th><td>{r['metrics']['lamp_intensity']['q']:.7g}</td><td>{r['metrics']['lamp_intensity_post_refined']['q']:.7g}</td><td>{r['metrics']['final_teacher_mse']:.7g}</td><td><a href='{r['sample']}/report.html'>report</a></td></tr>" for r in records)
    (output / "summary.html").write_text("<!doctype html><meta charset='utf-8'><title>Prediction refinement · all samples</title><style>body{font:14px Arial;background:#111;color:#ddd}table{border-collapse:collapse}th,td{border:1px solid #555;padding:6px}a{color:#8ccaff}</style><h1>Prediction refinement · 5 samples</h1><table><tr><th>sample</th><th>training q</th><th>refined recommended q</th><th>refined teacher MSE</th><th></th></tr>" + rows + "</table><p><a href='summary.json'>summary.json</a></p>", encoding="utf-8")
    return summary


def run(args: argparse.Namespace) -> Path:
    requested = list(SAMPLES) if args.all_groups else [args.sample]
    if any(sample not in SAMPLES for sample in requested):
        raise ValueError(f"unsupported sample: {args.sample}")
    output = Path(args.out_dir)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite existing artifact: {output}")
    output.mkdir(parents=True)
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    model = AuthorRealCaptureAdapter(Path(args.checkpoint), device=str(device))
    records = []
    for sample in requested:
        print(f"REFINEMENT_SAMPLE_START sample={sample}", flush=True)
        records.append(run_sample(args, sample, output, model))
        print(f"REFINEMENT_SAMPLE_COMPLETE sample={sample}", flush=True)
    _integrate_reports(output, records)
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample", choices=SAMPLES, default=SAMPLE)
    parser.add_argument("--all-groups", action="store_true")
    parser.add_argument("--archive", type=Path, default=ARCHIVE)
    parser.add_argument("--refresh", type=Path, default=REFRESH)
    parser.add_argument("--checkpoint", type=Path, default=CHECKPOINT)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--prior-weight", type=float, default=1e-4)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()
    print(f"REFINEMENT_START samples={'all' if args.all_groups else args.sample} device={args.device} steps={args.steps}", flush=True)
    output = run(args)
    print(f"REFINEMENT_COMPLETE output={output}", flush=True)


if __name__ == "__main__":
    main()
