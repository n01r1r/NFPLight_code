"""Finalize the two continued samples without touching either previous report."""
from pathlib import Path
import json
from finalize_measured_refinement import finalize

ROOT=Path('artifacts/measured_spherical_refinement_20261007_continue10k_40lights')
SOURCE=Path('artifacts/measured_spherical_refinement_20261007_lambda01')


def main():
    finalize(ROOT,SOURCE,rebuild=False)
    plan_path=ROOT/'plan.json';plan=json.loads(plan_path.read_text(encoding='utf-8'));plan['first_post_switch_stop_check']=3100;plan_path.write_text(json.dumps(plan,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    summary_path=ROOT/'summary.json';summary=json.loads(summary_path.read_text(encoding='utf-8'));summary['plan']=plan;summary_path.write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    p=ROOT/'summary.html';text=p.read_text(encoding='utf-8')
    text=text.replace('F0 fixed initial','Resume step 3000').replace('../spherical_refinement_20261007/summary.html','../measured_spherical_refinement_20261007_lambda01/summary.html').replace('기존 응답 보존 실험','이전 3000-step 실험')
    text=text.replace('Step</th>','누적 Step</th>')
    text=text.replace('<h1>Measured refinement · F0=0.04 · λ=0.1</h1>','<h1>Continued measured refinement · F0=0.04 · λ=0.1</h1><p>078·008 · step 3000부터 Adam 상태 복원 · 누적 10000 step 상한</p>')
    p.write_text(text,encoding='utf-8')
    results=json.loads((ROOT/'measurement_comparison.json').read_text(encoding='utf-8'))
    for comparison in results:
        comparison['previous_run_objective']='I_N MSE + 0.1 mean41 preservation'
        comparison['initial_state']='resumed step 3000'
    (ROOT/'measurement_comparison.json').write_text(json.dumps(results,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    stopping_rows=[]
    analysis='# Continued measured refinement · 40방향 보존\n\nL = centered I_N MSE + 0.1 × off-center 40방향 응답 보존 MSE. Center는 관측 I_N과만 비교하고 원래 pred의 center 응답 보존 항에서 제외했다. Normal/map loss는 추가하지 않았다. q, F0=.04, FP32, Adam lr=.01, seed=0은 유지했다.\n\n078·008의 이전 3000-step 맵과 전체 total-loss trajectory를 정확히 재현하여 Adam moment·step을 복원했다. 목적함수는 step 3000에서 41→40 보존 방향으로 전환했다. 이후 최근100 updates만 사용해 loss span/mean ≤.001, net mean normal angle ≤.001°, d/r mean absolute change ≤1e-5를 검사했다. 종료 상한은 누적10000이다. 478은 재실행하지 않았으며 이전 결과를 보존했다.\n\n|Sample|3000-step I_N MSE|최종 I_N MSE|누적 step|종료 판정|\n|---|---:|---:|---:|---|\n'
    for row in results:
        analysis+=f"|{row['sample']}|{row['fixed_initial_near_mse']:.6g}|{row['measured_refinement_terminal_near_mse']:.6g}|{row['step']}|{row['status']}|\n"
        target=ROOT/row['sample']/'theta_joint'
        c=json.loads((target/'condition.json').read_text(encoding='utf-8'))
        assert c['start_step']==3000 and c['train_light_count']==40 and c['termination']['step']<=10000
        assert len(c['trajectory'])==c['termination']['step']-3000+1
        assert c['trajectory'][0]['step']==3000
        assert c['termination']['step']>=3100
        assert all(t['step']>=3100 for t in c['trajectory'] if 'stability_window' in t)
        assert len(c['frames'])<=40
        window=c['trajectory'][-1]['stability_window'];change=window['net_map_change']
        stopping_rows.append(f"<tr><td>{row['sample']}</td><td>{row['step']}</td><td>{window['relative_loss_span']:.5g}</td><td>{change['normal_angular_mean_deg']:.5g}°</td><td>{change['diffuse']:.5g}</td><td>{change['roughness']:.5g}</td></tr>")
        analysis+=f"\n{row['sample']} 종료 구간: loss span/mean={window['relative_loss_span']:.6g}, net normal={change['normal_angular_mean_deg']:.6g}°, |Δd|={change['diffuse']:.6g}, |Δr|={change['roughness']:.6g}.\n"

    analysis+='\nTest 40방향은 원래 pred의 응답과 비교하며 gradient·종료 판정에 사용하지 않는다. I_N MSE는 직접 최적화하는 수치이므로 감소를 재질 정확도 검증으로 해석하지 않는다. 기존 41방향 loss와 이번 40방향 loss의 total은 목적함수가 달라 같은 곡선으로 연결하지 않았다.\n'
    stopping='<h2>종료 판정 · 최근 100 updates</h2><p>기준: loss span/mean ≤0.001 · net normal ≤0.001° · |Δd|, |Δr| ≤1e-5</p><table><tr><th>Sample</th><th>누적 step</th><th>Loss span/mean</th><th>Net normal</th><th>|Δd|</th><th>|Δr|</th></tr>'+''.join(stopping_rows)+'</table>'
    p=ROOT/'summary.html';text=p.read_text(encoding='utf-8');text=text.replace('<section id="spherical-sampling">',stopping+'<section id="spherical-sampling">');p.write_text(text,encoding='utf-8')
    (ROOT/'ANALYSIS.md').write_text(analysis,encoding='utf-8')
    (ROOT/'viridis_rgb.json').write_bytes((SOURCE/'viridis_rgb.json').read_bytes())
    p=ROOT/'checks.json';d=json.loads(p.read_text(encoding='utf-8'));d.update(continuation_steps_checked=True,objective_switch_recorded=True,stability_windows_post_switch_only=True,max_display_frames=40)
    p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('CONTINUATION_REPORT_READY')


if __name__=='__main__': main()
