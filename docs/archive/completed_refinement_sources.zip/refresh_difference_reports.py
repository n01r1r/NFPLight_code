"""Refresh saved FP32 real-data report differences on CPU; never infer or optimize."""
from __future__ import annotations
import json
import os
from pathlib import Path
import re
import shutil
from capture_processing.difference_visualization import saved_comparison,comparison_html

ROOT=Path(__file__).resolve().parent
OUTPUT=ROOT/'artifacts/difference_display_refresh_20261008'
ACTIVE=(
    'spherical_refinement_20261007','measured_spherical_refinement_20261007_lambda01',
    'measured_spherical_refinement_20261007_continue10k_40lights',
    'measured_spherical_refinement_20261007_fresh478_40lights',
    'cue_constrained_refinement_20261007','cue_constraints_lambda_20261007',
)
START='<!-- physical-differences:start -->'
END='<!-- physical-differences:end -->'


def stat(path): return path.stat().st_size,path.stat().st_mtime_ns


def insert(page,section):
    block=START+section+END
    if START in page:
        return re.sub(re.escape(START)+'.*?'+re.escape(END),lambda _:block,page,count=1,flags=re.S)
    for marker in ('</main>','</body>','</html>'):
        if marker in page:return page.replace(marker,block+marker,1)
    return page+block


def main():
    OUTPUT.mkdir(exist_ok=True)
    paths=[]
    for name in ACTIVE:
        folder=ROOT/'artifacts'/name
        paths.extend(folder.glob('*/theta_joint/centered_render_values.npz'))
        paths.extend(folder.glob('*/*/theta_joint/centered_render_values.npz'))
    sources=set(paths)
    sources.update(path.parent/'render_materials.npz' for path in paths)
    sources.update(path.parent/'condition.json' for path in paths if (path.parent/'condition.json').exists())
    protected={str(path):stat(path) for path in sources}
    records=[]
    per_root={}
    for path in paths:
        target=path.parent
        if not (target/'render_materials.npz').exists():continue
        record=saved_comparison(target)
        records.append({'folder':str(target),'display_ranges':record['display_ranges']})
        sample_folder=target.parent
        if (sample_folder/'report.html').is_file():
            page=sample_folder/'report.html'
            section=comparison_html(target,'theta_joint',record)
            text=page.read_text(encoding='utf-8')
            # Replace old endpoint comparisons; retain historical diagnostics and losses.
            text=re.sub(r'<section class="map-comparison".*?</section>','',text,flags=re.S)
            page.write_text(insert(text,section),encoding='utf-8')
        base=sample_folder.parent
        per_root.setdefault(base,[]).append((target,record))
    for base,items in per_root.items():
        page=base/'summary.html'
        if not page.is_file():continue
        section=''.join(f'<section class="physical-comparison"><h2>{target.parent.name}</h2>'+comparison_html(target,os.path.relpath(target,base).replace(os.sep,'/'),record)+'</section>' for target,record in items)
        text=page.read_text(encoding='utf-8')
        text=re.sub(r'<section class="map-comparison".*?</section>','',text,flags=re.S)
        page.write_text(insert(text,section),encoding='utf-8')
    # Unified report contains display copies only: read its declared numeric sources.
    from build_unified_refinement_report import SOURCES
    unified=ROOT/'artifacts/measured_refinement_20261007_unified'
    sections=[]
    for sample,source in SOURCES.items():
        original=ROOT/source/sample/'theta_joint'
        if not (original/'difference_display.json').is_file():continue
        record=json.loads((original/'difference_display.json').read_text(encoding='utf-8'))
        target=unified/sample/'theta_joint'
        target.mkdir(parents=True,exist_ok=True)
        for asset in original.glob('difference_*.png'):shutil.copyfile(asset,target/asset.name)
        shutil.copyfile(original/'difference_display.json',target/'difference_display.json')
        sections.append(f'<section class="physical-comparison"><h2>{sample}</h2>'+comparison_html(target,f'{sample}/theta_joint',record)+'</section>')
    page=unified/'summary.html'
    if sections and page.is_file():
        text=re.sub(r'<section class="map-comparison".*?</section>','',page.read_text(encoding='utf-8'),flags=re.S)
        page.write_text(insert(text,''.join(sections)),encoding='utf-8')
    assert all(stat(Path(path))==value for path,value in protected.items())
    links=0
    pages=[base/'summary.html' for base in per_root]+[unified/'summary.html']+[path.parent.parent/'report.html' for path in paths]
    for page in pages:
        if not page.exists():continue
        text=page.read_text(encoding='utf-8')
        for src in re.findall(r'src="([^"]+)"',text):
            if not src.startswith(('data:','http:','https:')):
                assert (page.parent/src).is_file(),(page,src)
                links+=1
    summary={'refreshed_comparisons':records,'checked_relative_image_links':links,
             'protected_numeric_files_unchanged':len(protected),'new_inference_or_optimization':False,
             'sha256_executed':False,'excluded_without_saved_fp32':[
                 'fabric_checkpoint_comparison_20261008','fabric_checkpoint_comparison_patch20_20261008',
                 'fabric_C_pretrained33_gain9_20261008'],
             'limitations':['Reports without saved FP32 predictions/renders cannot be converted from PNG.',
                            'Historical intermediate montages retain recorded signed-map scale; no optimizer replay.']}
    (OUTPUT/'verification.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
    print(json.dumps({'comparisons':len(records),'protected':len(protected),'image_links':links}))


if __name__=='__main__':main()
