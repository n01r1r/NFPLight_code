"""Fresh 478 refinement: measured center + 0.1 off-center teacher MSE."""
import json
from pathlib import Path
import numpy as np
import torch
import run_measured_spherical_refinement as base
import run_spherical_refinement as r

OUTPUT = Path('artifacts/measured_spherical_refinement_20261007_fresh478_40lights')
SOURCE = Path('artifacts/measured_spherical_refinement_20261007_lambda01')
SAMPLE = '260818_174845_478'


def main():
    OUTPUT.mkdir(exist_ok=False)
    baseline = {str(p): r._file_stat(p) for p in SOURCE.rglob('*') if p.is_file()}
    plan = json.loads((SOURCE/'plan.json').read_text(encoding='utf-8'))
    plan.update(active_samples=[SAMPLE], preservation_train_count=40, measured_train_count=1,
                objective='centered I_N MSE + 0.1 mean40 off-center preservation MSE',
                initialization='original prediction; F0 fixed to 0.04; fresh Adam',
                max_steps=10000, learning_rate=.01, seed=0, normal_or_map_loss=False,
                precision='FP32', light_chunk_size=8)
    r._json(OUTPUT/'plan.json', plan)
    device = torch.device('cuda')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    render = r._make_renderer(device)
    folder = OUTPUT/SAMPLE
    target = folder/'theta_joint'
    target.mkdir(parents=True)
    metadata = json.loads((SOURCE/SAMPLE/'metrics.json').read_text(encoding='utf-8'))
    old = json.loads((SOURCE/SAMPLE/'theta_joint/condition.json').read_text(encoding='utf-8'))
    with np.load(SOURCE/SAMPLE/'theta_joint/render_materials.npz') as values:
        pred = torch.from_numpy(values['original'].copy()).to(device)
    near, far, provenance = r.reconstruct_selected_pair(sample=SAMPLE, refresh=r.REFRESH_ROOT/SAMPLE/'refresh_20261006')
    q = metadata['lamp_intensity']['q']
    train = torch.tensor(old['train_xyz'][1:], dtype=torch.float32, device=device)
    test = torch.tensor(old['evaluation_xyz'], dtype=torch.float32, device=device)
    assert train.shape == (40, 3) and (train[:, :2].norm(dim=1) > 0).all()
    frames, states = [], []
    def snapshot(step, state, final):
        if (step % 300 == 0 or final) and not any(f['step'] == step for f in frames):
            states.append(state.cpu().clone())
            frames.append({'step': step, 'path': f'theta_joint/step_{step:05d}.webp'})
        if step % 500 == 0:
            print(SAMPLE, step, flush=True)
    result = r.analyze_condition(pred, render, train, test, q, mode='fixed', regime='measured40',
        steps=10000, lr=.01, seed=0, stability=True, snapshot_callback=snapshot,
        light_chunk_size=8, measured_target=near.to(device), measured_light=r.ring(0, device=device),
        preservation_weight=.1)
    c = {k: result[k] for k in ('train_light_count', 'best_step', 'termination', 'metrics', 'trajectory', 'objective')}
    c.update(theta_deg='joint', train_xyz=train.cpu().tolist(), evaluation_xyz=test.cpu().tolist(),
             frames=frames, display_scales=r.display_scales(pred.cpu(), states))
    assert len(frames) <= 40
    r._json(target/'condition.json', c)
    r._json(target/'display_scales.json', c['display_scales'])
    r.save_frame(folder/'original.webp', pred.cpu(), pred.cpu(), c['display_scales'])
    for f, state in zip(frames, states):
        r.save_frame(folder/f['path'], pred.cpu(), state, c['display_scales'], lossless=f['step'] in (0, frames[-1]['step']))
    np.savez_compressed(target/'render_materials.npz', original=pred.cpu().numpy(), updated=result['last'].cpu().numpy(), best=result['best'].cpu().numpy())
    torch.save(result['checkpoint'], target/'terminal_optimizer.pth')
    base.save_render_comparison(target, pred, result['last'], near, far, render, q, provenance)
    base.make_plots(target, c['trajectory'])
    record = {'sample': SAMPLE, 'mode': 'joint', 'provenance': provenance,
              'lamp_intensity': metadata['lamp_intensity'], 'display_scales': c['display_scales'], 'conditions': [c]}
    r._json(folder/'metrics.json', {**record, 'conditions': [{k: v for k, v in c.items() if k != 'trajectory'} | {'condition_path': 'theta_joint/condition.json'}]})
    r._json(OUTPUT/'summary.json', {'plan': plan, 'samples': [{k: v for k, v in record.items() if k != 'conditions'}]})
    assert all(r._file_stat(Path(p)) == stat for p, stat in baseline.items())
    r._json(OUTPUT/'checks.json', {'prior_files_unchanged': len(baseline), 'train_count': 40, 'test_count': 40,
        'fresh_optimizer': True, 'FP32': True, 'normal_or_map_loss': False, 'sha256_executed': False})
    print('DONE', c['termination'], c['trajectory'][-1], flush=True)


if __name__ == '__main__':
    main()
