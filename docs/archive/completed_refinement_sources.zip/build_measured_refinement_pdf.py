"""Landscape PDF with five-column maps, measured references, loss components and dynamics."""
import json
from pathlib import Path
from io import BytesIO
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import Paragraph, Table, TableStyle
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.colors import HexColor

ROOT=Path('artifacts/measured_spherical_refinement_20261007_lambda01')
OUTPUT=Path('output/pdf/measured_spherical_refinement_20261007_lambda01.pdf')


def build(root=None, output=None):
    global ROOT, OUTPUT
    if root is not None: ROOT=Path(root)
    if output is not None: OUTPUT=Path(output)
    pdfmetrics.registerFont(TTFont('Serif','C:/Windows/Fonts/georgia.ttf'))
    pdfmetrics.registerFont(TTFont('SerifBold','C:/Windows/Fonts/georgiab.ttf'))
    pdfmetrics.registerFont(TTFont('KRSerif','C:/Windows/Fonts/batang.ttc',subfontIndex=0))
    summary=json.loads((ROOT/'summary.json').read_text(encoding='utf-8'))
    records=[]
    for sample in summary['plan']['active_samples']:
        record=json.loads((ROOT/sample/'metrics.json').read_text(encoding='utf-8'))
        record['condition']=json.loads((ROOT/sample/'theta_joint/condition.json').read_text(encoding='utf-8'))
        records.append(record)
    assert len(records) in (2,3)
    continuation='objective_switch_at_step' in summary['plan']
    count=40 if continuation else 41
    OUTPUT.parent.mkdir(exist_ok=True,parents=True)
    W,H=landscape(A4);M=34;total=2+4*len(records);page=0
    pdf=canvas.Canvas(str(OUTPUT),pagesize=(W,H),pageCompression=1)
    pdf.setTitle('Measured refinement - F0=0.04, lambda=0.1')
    def text(x,y,value,size=10,font='Serif'):
        assert x>=M-1 and y>=15 and y<=H-20,(x,y,value)
        pdf.setFillColor(HexColor('#20252c'));pdf.setFont(font,size);pdf.drawString(x,y,value)
    def paragraph(x,y,value,width,size=9,font='KRSerif'):
        p=Paragraph(value,ParagraphStyle('caption',fontName=font,fontSize=size,leading=size*1.45,textColor=HexColor('#303740')))
        _,height=p.wrap(width,H)
        assert y-height>=38,(value,y,height)
        p.drawOn(pdf,x,y-height)
        return y-height
    def image(path,x,y,width,height,box=None):
        with Image.open(path) as im:
            im=im.convert('RGB')
            if box: im=im.crop(box)
            assert x>=M-1 and y>=38 and x+width<=W-M+1 and y+height<=H-60
            pdf.drawImage(ImageReader(im),x,y,width=width,height=height,mask='auto')
    def begin(title,subtitle=''):
        nonlocal page
        page+=1
        text(M,H-34,'NFPLight | Measured refinement | F0 = 0.04 | lambda = 0.1',9)
        text(M,H-62,title,17,'SerifBold')
        if subtitle: text(M,H-81,subtitle,9)
    def end():
        pdf.setStrokeColor(HexColor('#d8dde3'));pdf.line(M,30,W-M,30)
        text(M,18,'FP32 | terminal state | linear RGB differences',8)
        text(W-M-50,18,f'{page} / {total}',8)
        pdf.showPage()
    begin('Measured I_N fitting with response preservation')
    method=f'L = measured MSE + 0.1 × preservation MSE<br/>Measured: centered render - I_N. Preservation: mean over {count} lights against original pred render.<br/>Fixed q; n/d/r optimized; F0=0.04 fixed. '
    method += 'Continuation from step 3000 with restored Adam moments; center removed from preservation.' if continuation else 'Original pred initialization.'
    paragraph(M,H-101,method,W-2*M,11,'Serif')
    rows=[['Sample','Step','Stop','Measured MSE','Preservation MSE','Total','Test MSE']]
    for record in records:
        c=record['condition'];t=c['trajectory'][-1]
        rows.append([record['sample'],str(c['termination']['step']),'criteria met' if c['termination']['status']=='stability_criteria_met' else 'max steps',f"{t['measured_mse']:.5g}",f"{t['preservation_mse']:.5g}",f"{t['total_loss']:.5g}",f"{t['common_heldout_mse']:.5g}"])
    table=Table(rows,colWidths=[154,38,70,106,112,94,100])
    table.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'Serif'),('FONTSIZE',(0,0),(-1,-1),9),('BACKGROUND',(0,0),(-1,0),HexColor('#edf2f6')),('BOTTOMPADDING',(0,0),(-1,-1),11),('TOPPADDING',(0,0),(-1,-1),11),('LINEBELOW',(0,0),(-1,-1),.4,HexColor('#d8dde3'))]))
    _,height=table.wrap(W-2*M,H);table.drawOn(pdf,M,H-222-height)
    stop_caption='Adam lr=0.01; seed=0; every 100 updates: total loss span/mean &lt;=0.001; net mean normal angle &lt;=0.001 deg; d/r mean absolute change &lt;=1e-5.'
    stop_caption += '<br/>Continuation: step 3000 to maximum 10000; first stopping window begins after the objective switch.' if continuation else '<br/>Minimum 300 / maximum 3000 updates.'
    stop_caption += ' Test: 40 unused azimuth directions, no gradient or stopping influence.'
    paragraph(M,415,stop_caption,W-2*M,9,'Serif')
    baseline=[['I_N MSE','Original pred','Resume step 3000' if continuation else 'F0 fixed initial','Previous terminal','New terminal']]
    for record in records:
        comp=json.loads((ROOT/record['sample']/'theta_joint/render_comparison.json').read_text(encoding='utf-8'))['near_mse_comparison']
        baseline.append([record['sample']]+[f'{comp[key]:.5g}' for key in ['original_pred_near_mse','fixed_initial_near_mse','previous_preservation_only_terminal_near_mse','measured_refinement_terminal_near_mse']])
    table=Table(baseline,colWidths=[154,155,155,155,155])
    table.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'Serif'),('FONTSIZE',(0,0),(-1,-1),9),('BACKGROUND',(0,0),(-1,0),HexColor('#edf2f6')),('BOTTOMPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('LINEBELOW',(0,0),(-1,-1),.4,HexColor('#d8dde3'))]))
    _,height=table.wrap(W-2*M,H);table.drawOn(pdf,M,(245 if continuation else 200)-height)
    if continuation:
        stopping=[['Last 100 updates','Step','Loss span/mean','Net normal (deg)','Mean |delta d|','Mean |delta r|']]
        for record in records:
            condition=record['condition'];window=condition['trajectory'][-1]['stability_window'];change=window['net_map_change']
            stopping.append([record['sample'],str(condition['termination']['step']),f"{window['relative_loss_span']:.5g}",f"{change['normal_angular_mean_deg']:.5g}",f"{change['diffuse']:.5g}",f"{change['roughness']:.5g}"])
        table=Table(stopping,colWidths=[154,50,140,140,145,145])
        table.setStyle(TableStyle([('FONTNAME',(0,0),(-1,-1),'Serif'),('FONTSIZE',(0,0),(-1,-1),8),('BACKGROUND',(0,0),(-1,0),HexColor('#edf2f6')),('BOTTOMPADDING',(0,0),(-1,-1),6),('TOPPADDING',(0,0),(-1,-1),6),('LINEBELOW',(0,0),(-1,-1),.4,HexColor('#d8dde3'))]))
        _,height=table.wrap(W-2*M,H);table.drawOn(pdf,M,155-height)
    paragraph(M,70,'I_N MSE is optimized directly; its reduction does not establish material ground-truth accuracy.',W-2*M,9,'Serif')
    end()
    sampling_caption='Preservation: 40 | Measured center: 1 | Test: 40' if continuation else 'Train: 41 | Test: 40'
    begin('Spherical lighting - top view',sampling_caption+' | XY projection | radial distance = 4 sin(theta)')
    image(ROOT/'spherical_sampling_top_view.png',M+80,45,600,447)
    end()
    for record in records:
        sample=record['sample'];c=record['condition'];target=ROOT/sample/'theta_joint'
        meta=json.loads((target/'render_comparison.json').read_text(encoding='utf-8'));scales=c['display_scales']
        begin(sample,'Original / terminal / signed difference | centered light (0,0,4) | q = %.6g | step %d'%(meta['q'],c['termination']['step']))
        cell=108;gap=7;top=H-112;x0=M
        for col,title in enumerate(['Normal n','Diffuse d','Roughness r','Specular / F0','Re-rendering']): text(x0+col*(cell+gap),top,title,9)
        for row,name in enumerate(['original','updated','difference']):
            y=top-25-row*133
            text(x0,y,name.title(),9,'SerifBold')
            for col in range(4): image(target/f'summary_{name}.webp',x0+col*(cell+gap),y-114,cell,cell,(col*256,0,(col+1)*256,256))
            image(target/f'render_{name}.webp',x0+4*(cell+gap),y-114,cell,cell)
        for col,value in enumerate([f"Angle 0-{scales['normal']:.4g} deg",f"Delta d +/-{scales['diffuse']:.4g}",f"Delta r +/-{scales['roughness']:.4g}",f"Delta s +/-{scales['specular']:.4g}",f"Delta RGB +/-{meta['difference_scale']:.4g}"]): text(x0+col*(cell+gap),63,value,8)
        palette=json.loads((ROOT/'viridis_rgb.json').read_text(encoding='utf-8'))
        for index,rgb in enumerate(palette):
            pdf.setFillColorRGB(*rgb);pdf.rect(M+index*cell/len(palette),54,cell/len(palette)+.1,4,fill=1,stroke=0)
        text(M,45,'Signed RGB/gray: mid-gray = 0. Angle: purple = 0, yellow = max. Display maps/render: gamma 2.2.',8)
        reference_x=M+600
        text(reference_x,top,'Measured',11,'SerifBold')
        for index,side in enumerate(['near','far']):
            y=top-30-index*160;text(reference_x,y,'Near I_N' if side=='near' else 'Far I_F - distance reference',9)
            image(target/f'measured_{side}.webp',reference_x,y-140,130,130)
        stats=meta['difference_statistics']['updated_minus_original']
        text(reference_x,130,'Updated - original render',9,'SerifBold')
        for offset,key in enumerate(['min','max','mean']):
            text(reference_x,112-offset*15,f"{key} {stats[key]:.5g}",9)
        end()
        begin(sample+' - re-rendering minus I_N','Signed linear RGB | shared range +/-%.5g | mid-gray = 0'%meta['near_difference_scale'])
        for col,name in enumerate(['original','updated']):
            x=M+col*390;text(x,H-115,name.title()+' re-rendering - I_N',12,'SerifBold')
            image(target/f'render_{name}_minus_near.webp',x,H-425,280,280)
            stats=meta['difference_statistics'][name+'_minus_near']
            text(x,H-447,'min %.5g | max %.5g | mean %.5g'%(stats['min'],stats['max'],stats['mean']),10)
        paragraph(M,101,'Statistics: signed differences over all pixels and RGB channels. Unclipped rendering - clipped linear I_N input.<br/>Rendering/I_N display: clip [0,1], gamma 2.2. Difference display: 0.5 + delta/(2M), no gamma.',W-2*M,9,'Serif')
        end()
        begin(sample+' - dynamics','Measured MSE | unweighted preservation MSE | total = measured + 0.1 preservation')
        image(target/'response.png',M+75,45,625,450)
        end()
        begin(sample+' - gradient / update','Combined objective gradient; Adam updates; fixed F0 gradient = 0')
        image(target/'optimizer.png',M+40,45,700,450)
        end()
    assert page==total
    pdf.save()
    print('PDF',OUTPUT,'pages',page)


if __name__=='__main__': build()
