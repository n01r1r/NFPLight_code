from pathlib import Path

from capture_processing.refinement_report import build_index_refinement_summary, insert_refinement_section, validate_refinement_links


def test_report_section_replacement_is_idempotent_and_preserves_page():
    page = '<main><p>existing</p><details class="technical"><summary>formula</summary></details></main>'
    section = '<section id="prediction-refinement"><p>new</p></section>'
    once = insert_refinement_section(page, section)
    twice = insert_refinement_section(once, section)
    assert twice == once
    assert twice.count('id="prediction-refinement"') == 1
    assert "existing" in twice and "formula" in twice


def test_report_link_validation_checks_gamma_and_linear_assets(tmp_path: Path):
    (tmp_path / "normal.png").write_bytes(b"png")
    (tmp_path / "diffuse.png").write_bytes(b"png")
    (tmp_path / "diffuse_gamma22.png").write_bytes(b"png")
    html = '<img class="case-image" src="normal.png"><img class="case-image" data-linear-src="diffuse.png" data-gamma-src="diffuse_gamma22.png">'
    assert validate_refinement_links(html, tmp_path) == []
    assert 'data-gamma-src' in html and 'data-linear-src' in html


def test_index_section_is_idempotent_without_nested_markers():
    record = {"sample": "260930_152732_008", "selection": "fallback", "metrics": {
        "lamp_intensity": {"q": 16.0}, "lamp_intensity_post_refined": {"q": 15.9}, "final_teacher_mse": 0.1}}
    section = build_index_refinement_summary([record], "../prediction")
    page = '<main><p>index</p></main>'
    once = insert_refinement_section(page, section)
    twice = insert_refinement_section(once, section)
    assert once == twice
    assert once.count('prediction-refinement:start') == 1
    assert once.count('prediction-refinement:end') == 1
