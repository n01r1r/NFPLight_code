import pytest
import torch

from capture_processing.rendering_loss_analysis import (
    F0_RAW,
    analyze_condition,
    build_common_heldout_lights,
    build_light_regimes,
    insert_analysis_section,
    validate_analysis_links,
)


def test_light_regimes_have_fixed_camera_geometry_and_expected_counts():
    regimes = build_light_regimes(torch.device("cpu"))
    assert tuple(regimes) == ("center", "small", "wide")
    assert regimes["center"].shape == (1, 3)
    assert regimes["small"].shape == (5, 3)
    assert regimes["wide"].shape == (5, 3)
    assert torch.equal(regimes["center"][0], torch.tensor([0.0, 0.0, 4.0]))
    assert regimes["small"][0].tolist() == [0.0, 0.0, 4.0]
    assert regimes["wide"][0].tolist() == [0.0, 0.0, 4.0]


def _toy_renderer(material, lights, intensity):
    diffuse = (material[:, 3:6] + 1.0) * 0.5
    roughness = (material[:, 6:7] + 1.0) * 0.5
    specular = (material[:, 7:10] + 1.0) * 0.5
    light_gain = (1.0 + 0.05 * lights[:, 0]).reshape(1, -1, 1, 1, 1)
    value = (diffuse + 0.1 * roughness + 0.4 * specular).unsqueeze(1)
    return value.expand(-1, lights.shape[0], -1, -1, -1) * light_gain * float(intensity)


def _prediction():
    value = torch.zeros(1, 10, 4, 4, dtype=torch.float32)
    value[:, :3] = torch.tensor([[[[0.0]], [[0.0]], [[1.0]]]])
    value[:, 3:6] = 0.2
    value[:, 6:7] = 0.1
    value[:, 7:10] = 0.6
    return value


def test_free_control_is_exactly_stationary_when_teacher_is_same_render():
    regimes = build_light_regimes("cpu")
    result = analyze_condition(
        _prediction(),
        _toy_renderer,
        regimes["center"],
        build_common_heldout_lights("cpu"),
        1.0,
        mode="free",
        regime="center",
        steps=4,
        lr=0.01,
    )
    assert len(result["trajectory"]) == 5
    assert result["metrics"]["free_exact_unchanged"] is True
    assert result["metrics"]["best_train_mse"] == pytest.approx(0.0)
    assert all(item["gradient_rms_raw"]["s"] == pytest.approx(0.0) for item in result["trajectory"])


def test_fixed_control_reduces_loss_and_keeps_specular_constant():
    regimes = build_light_regimes("cpu")
    result = analyze_condition(
        _prediction(),
        _toy_renderer,
        regimes["small"],
        build_common_heldout_lights("cpu"),
        1.0,
        mode="fixed",
        regime="small",
        steps=12,
        lr=0.05,
    )
    assert result["metrics"]["best_train_mse"] < result["metrics"]["initial_train_mse"]
    assert result["metrics"]["fixed_specular_raw"] == pytest.approx(F0_RAW)
    assert result["metrics"]["fixed_specular_gradient_rms"] == pytest.approx(0.0)
    assert result["trajectory"][0]["step"] == 0
    assert result["trajectory"][-1]["step"] == 12
    assert all(item["gradient_rms_raw"]["s"] == pytest.approx(0.0) for item in result["trajectory"])
    assert torch.allclose(result["last"][:, 7:], torch.full_like(result["last"][:, 7:], F0_RAW))


def test_real_renderer_free_control_has_zero_loss_and_zero_gradients():
    from utils.render_util import svBRDF

    renderer = svBRDF()
    surface = renderer.surface(4, range=1, dtype=torch.float32)
    camera = torch.tensor([[0.0, 0.0, 4.0]], dtype=torch.float32)

    def real_renderer(material, lights, intensity):
        light, view, distance, _ = renderer.torch_generate(camera, lights, surface=surface)
        renderer.lampIntensity = float(intensity)
        return renderer._render(material, light, view, distance)

    result = analyze_condition(
        _prediction(),
        real_renderer,
        torch.tensor([[0.0, 0.0, 4.0]], dtype=torch.float32),
        torch.tensor([[0.5, 0.5, 4.0]], dtype=torch.float32),
        1.0,
        mode="free",
        regime="center",
        steps=3,
        lr=0.01,
    )
    assert result["metrics"]["free_exact_unchanged"] is True
    assert result["metrics"]["best_train_mse"] == pytest.approx(0.0, abs=1e-12)
    assert all(item["gradient_rms_raw"]["n"] == pytest.approx(0.0, abs=1e-7) for item in result["trajectory"])


def test_best_state_is_an_evaluated_trajectory_state_and_zero_normals_reject():
    regimes = build_light_regimes("cpu")
    result = analyze_condition(
        _prediction(),
        _toy_renderer,
        regimes["wide"],
        build_common_heldout_lights("cpu"),
        1.0,
        mode="fixed",
        regime="wide",
        steps=4,
        lr=0.05,
    )
    values = [item["train_mse"] for item in result["trajectory"]]
    assert result["metrics"]["best_train_mse"] == pytest.approx(min(values))
    assert result["best_step"] == values.index(min(values))
    invalid = _prediction()
    invalid[:, :3] = 0.0
    with pytest.raises(ValueError, match="zero normal"):
        analyze_condition(
            invalid,
            _toy_renderer,
            regimes["center"],
            build_common_heldout_lights("cpu"),
            1.0,
            mode="free",
            regime="center",
            steps=1,
        )


def test_analysis_report_marker_is_idempotent_and_link_checker_is_strict(tmp_path):
    page = '<main><section id="prediction-refinement">old</section></main>'
    section = '<section id="rendering-loss-analysis">new</section>'
    once = insert_analysis_section(page, section)
    twice = insert_analysis_section(once, section)
    assert once == twice
    assert once.count("rendering-loss-analysis:start") == 1
    assert "prediction-refinement" in twice
    (tmp_path / "ok.png").write_bytes(b"png")
    assert validate_analysis_links('<img src="ok.png">', tmp_path) == []
    assert validate_analysis_links('<img src="missing.png">', tmp_path) == ["src: missing.png"]


def test_measured_objective_and_chunked_gradient_match_direct_autograd():
    from capture_processing.rendering_loss_analysis import initial_material
    pred = _prediction()
    lights = build_light_regimes('cpu')['small']
    observed = torch.full((1, 3, 4, 4), .35)
    center = torch.tensor([[0., 0., 4.]])
    material = initial_material(pred, 'fixed').detach().requires_grad_(True)
    teacher = _toy_renderer(pred, lights, 1.).detach()
    preservation = (_toy_renderer(material, lights, 1.)-teacher).square().mean()
    measured = (_toy_renderer(material, center, 1.)[:, 0]-observed).square().mean()
    direct = measured + .1*preservation
    direct.backward()
    result = analyze_condition(pred, _toy_renderer, lights, center, 1., mode='fixed', regime='measured', steps=1, measured_target=observed, measured_light=center, preservation_weight=.1, light_chunk_size=2)
    entry = result['trajectory'][0]
    assert entry['total_loss'] == pytest.approx(float(direct), rel=1e-6)
    assert entry['preservation_mse'] == pytest.approx(float(preservation), rel=1e-6)
    assert entry['measured_mse'] == pytest.approx(float(measured), rel=1e-6)
    for name,sl in [('n',slice(0,3)),('d',slice(3,6)),('r',slice(6,7))]:
        assert entry['gradient_rms_raw'][name] == pytest.approx(float(material.grad[:,sl].square().mean().sqrt()), rel=1e-6, abs=1e-10)
    assert entry['gradient_rms_raw']['s'] == 0
    assert result['trajectory'][-1]['measured_mse'] < entry['measured_mse']
    assert torch.equal(result['last'][:,7:],result['initial'][:,7:])


def test_adam_resume_matches_uninterrupted_run_and_changed_objective_is_explicit():
    import copy
    pred=_prediction();lights=build_light_regimes('cpu')['small'];center=torch.tensor([[0.,0.,4.]])
    args=dict(mode='fixed',regime='measured',measured_target=torch.full((1,3,4,4),.35),measured_light=center,preservation_weight=.1,light_chunk_size=2)
    full=analyze_condition(pred,_toy_renderer,lights,center,1.,steps=8,**args)
    prefix=analyze_condition(pred,_toy_renderer,lights,center,1.,steps=3,**args)
    resumed=analyze_condition(pred,_toy_renderer,lights,center,1.,steps=8,resume_state=copy.deepcopy(prefix['checkpoint']),**args)
    assert torch.equal(full['last'],resumed['last'])
    assert resumed['start_step']==3
    for a,b in zip(full['trajectory'][3:],resumed['trajectory']):
        assert a['total_loss']==b['total_loss']
    changed=analyze_condition(pred,_toy_renderer,lights[1:],center,1.,steps=8,resume_state=copy.deepcopy(prefix['checkpoint']),**args)
    assert changed['train_light_count']==len(lights)-1
    assert changed['trajectory'][0]['measured_mse']==prefix['trajectory'][-1]['measured_mse']
    assert torch.equal(changed['last'][:,7:],prefix['last'][:,7:])

@pytest.mark.parametrize('constants', [('n',), ('d', 'r'), ('d',)])
def test_spatial_constants_remain_exact_after_updates(constants):
    pred = _prediction()
    pred[:, 0, :, 2:] = 0.2
    pred[:, 3:7, :, 2:] += 0.15
    lights = build_light_regimes('cpu')['small']
    def renderer(material, directions, intensity):
        return _toy_renderer(material, directions, intensity) + 0.1 * material[:, :3].unsqueeze(1)

    result = analyze_condition(pred, renderer, lights, lights, 1.,
        mode='fixed', regime='constrained', steps=5, spatial_constants=constants,
        measured_target=torch.zeros(1,3,4,4), measured_light=lights[:1], preservation_weight=.1)
    for name, sl in [('n',slice(0,3)), ('d',slice(3,6)), ('r',slice(6,7))]:
        if name in constants:
            for key in ('initial', 'last', 'best'):
                value = result[key][:,sl]
                assert torch.equal(value, value[:,:,:1,:1].expand_as(value))
    if constants == ('d',):
        for sl in (slice(0,3), slice(6,7)):
            assert torch.equal(result['initial'][:,sl], pred[:,sl])
            assert not torch.equal(result['last'][:,sl], result['initial'][:,sl])
            value = result['last'][:,sl]
            assert not torch.equal(value, value[:,:,:1,:1].expand_as(value))
    assert result['trajectory'][-1]['total_loss'] < result['trajectory'][0]['total_loss']
    assert torch.equal(result['last'][:,7:], torch.full_like(pred[:,7:], F0_RAW))


def test_color_cue_adds_separate_scaled_loss_to_measured_objective():
    pred = _prediction()
    checker = torch.arange(4).remainder(2).float().mul(0.2).add(0.3)
    checker = checker.view(1, 1, 1, 4).expand(1, 1, 4, 4)
    pred[:, :3] = torch.cat((checker * 0.1, torch.zeros_like(checker), torch.full_like(checker, 0.99 ** 0.5)), dim=1)
    target = torch.cat((checker, 1.0 - checker, torch.full_like(checker, 0.2)), dim=1)
    center = torch.tensor([[0.0, 0.0, 4.0]])
    result = analyze_condition(
        pred, _toy_renderer, center, center, 1.0, mode="fixed", regime="cue",
        steps=1, measured_target=target, measured_light=center,
        preservation_weight=0.1,
        cue_config={"lowpass_kernel": 1, "local_kernel": 3, "cue_budget": 0.2, "detail_budget": 0.0},
    )

    initial = result["trajectory"][0]
    assert initial["cue_loss"] == pytest.approx(1.0, rel=1e-5)
    assert initial["normal_detail_loss"] == pytest.approx(0.0, abs=1e-8)
    assert initial["total_loss"] == pytest.approx(
        initial["measured_mse"] + initial["weighted_preservation_mse"]
        + 0.2 * result["cue_contract"]["reference_measured_mse"] * initial["cue_loss"],
        rel=1e-6,
    )
    assert result["checkpoint"]["cue_contract"] == result["cue_contract"]
    assert result["cue_contract"]["roughness_lowpass_kernel_source"] == "inherits_lowpass_kernel"
    with pytest.raises(ValueError, match="cue checkpoint resume is unsupported"):
        analyze_condition(
            pred, _toy_renderer, center, center, 1.0, mode="fixed", regime="cue-resume",
            steps=3, measured_target=target, measured_light=center, preservation_weight=0.1,
            resume_state=result["checkpoint"],
        )
    assert "cue_loss" not in analyze_condition(
        _prediction(), _toy_renderer, center, center, 1.0, mode="fixed", regime="legacy", steps=1
    )["trajectory"][0]


def test_color_cue_all_inactive_is_a_finite_zero_regularizer():
    center = torch.tensor([[0.0, 0.0, 4.0]])
    result = analyze_condition(
        _prediction(), _toy_renderer, center, center, 1.0,
        mode="fixed", regime="cue-dark", steps=1,
        measured_target=torch.zeros(1, 3, 4, 4), measured_light=center,
        cue_config={"lowpass_kernel": 1, "local_kernel": 3},
    )

    assert result["trajectory"][0]["cue_loss"] == 0.0
    assert result["trajectory"][0]["normal_detail_loss"] == 0.0


def test_mixed_roughness_scale_is_recorded_and_used_for_initial_normalization():
    from capture_processing.color_cue import build_color_cue_context
    from capture_processing.rendering_loss_analysis import initial_material, physical_maps

    pred = _prediction()
    checker = torch.arange(4).remainder(2).float().mul(2).sub(1)
    checker = checker.view(1, 1, 1, 4).expand(1, 1, 4, 4)
    pred[:, :3] = torch.cat((checker * 0.1, torch.zeros_like(checker), torch.full_like(checker, 0.99 ** 0.5)), dim=1)
    pred[:, 6:7] = 0.2 * checker
    target = torch.cat((0.5 + 0.2 * checker, 0.5 - 0.2 * checker, torch.full_like(checker, 0.5)), dim=1)
    center = torch.tensor([[0.0, 0.0, 4.0]])
    config = {"lowpass_kernel": 1, "roughness_lowpass_kernel": 3, "local_kernel": 3}
    result = analyze_condition(
        pred, _toy_renderer, center, center, 1.0, mode="fixed", regime="mixed-cue", steps=1,
        measured_target=target, measured_light=center, cue_config=config,
    )
    initial_maps = physical_maps(initial_material(pred, "fixed"))
    expected = build_color_cue_context(
        initial_maps["normal"], initial_maps["roughness"], target,
        lowpass_kernel=1, roughness_lowpass_kernel=3, local_kernel=3,
    )

    assert result["cue_contract"]["config"] == config | {"cue_budget": 0.1, "detail_budget": 1.0}
    assert result["cue_contract"]["roughness_initial_cue"] == pytest.approx(float(expected.roughness_scale))
    assert result["cue_contract"]["roughness_lowpass_kernel_source"] == "explicit"
    assert result["checkpoint"]["cue_contract"] == result["cue_contract"]


def test_scale_space_bands_are_recorded_in_contract_and_trajectory():
    pred = _prediction()
    checker = torch.arange(4).remainder(2).float().mul(2).sub(1)
    checker = checker.view(1, 1, 1, 4).expand(1, 1, 4, 4)
    pred[:, :3] = torch.cat((checker * 0.1, torch.zeros_like(checker), torch.full_like(checker, 0.99 ** 0.5)), dim=1)
    pred[:, 6:7] = 0.2 * checker
    target = torch.cat((0.5 + 0.2 * checker, 0.5 - 0.2 * checker, torch.full_like(checker, 0.5)), dim=1)
    center = torch.tensor([[0.0, 0.0, 4.0]])
    result = analyze_condition(
        pred, _toy_renderer, center, center, 1.0, mode="fixed", regime="scale-space", steps=1,
        measured_target=target, measured_light=center,
        cue_config={"lowpass_kernel": 1, "local_kernel": 3,
                    "normal_cue_kernels": [1, 3], "roughness_cue_kernels": [1, 3]},
    )

    entry = result["trajectory"][0]
    assert result["cue_contract"]["normal_cue_bands_initial"].keys() == {"1", "3"}
    assert result["cue_contract"]["roughness_cue_bands_initial"].keys() == {"1", "3"}
    assert entry["normal_cue_bands"].keys() == {"1", "3"}
    assert entry["roughness_cue_bands"].keys() == {"1", "3"}
    assert all(item["raw"] >= 0 and item["normalized"] >= 0 for item in entry["normal_cue_bands"].values())


@pytest.mark.parametrize(
    ("config", "error"),
    [
        ({"normal_cue_kernels": [1]}, "provided together"),
        ({"normal_cue_kernels": [1, 1], "roughness_cue_kernels": [1]}, "unique"),
        ({"normal_cue_kernels": [2], "roughness_cue_kernels": [1]}, "positive odd"),
        ({"normal_cue_kernels": [], "roughness_cue_kernels": [1]}, "nonempty"),
    ],
)
def test_scale_space_rejects_incomplete_or_invalid_kernel_lists(config, error):
    center = torch.tensor([[0.0, 0.0, 4.0]])

    with pytest.raises(ValueError, match=error):
        analyze_condition(
            _prediction(), _toy_renderer, center, center, 1.0,
            mode="fixed", regime="invalid-scale-space", steps=1, cue_config=config,
        )


def test_legacy_single_band_matches_singleton_scale_space_numerically():
    pred = _prediction()
    checker = torch.arange(4).remainder(2).float().mul(2).sub(1)
    checker = checker.view(1, 1, 1, 4).expand(1, 1, 4, 4)
    pred[:, :3] = torch.cat((checker * 0.1, torch.zeros_like(checker), torch.full_like(checker, 0.99 ** 0.5)), dim=1)
    pred[:, 6:7] = 0.2 * checker
    target = torch.cat((0.5 + 0.2 * checker, 0.5 - 0.2 * checker, torch.full_like(checker, 0.5)), dim=1)
    center = torch.tensor([[0.0, 0.0, 4.0]])
    legacy_config = {"lowpass_kernel": 1, "local_kernel": 3, "cue_budget": 0.2, "detail_budget": 0.0}
    scale_config = legacy_config | {"normal_cue_kernels": [1], "roughness_cue_kernels": [1]}
    args = dict(
        prediction=pred, render_fn=_toy_renderer, train_lights=center, common_lights=center,
        lamp_intensity=1.0, mode="fixed", regime="numeric-compat", steps=4,
        measured_target=target, measured_light=center,
    )
    legacy = analyze_condition(**args, cue_config=legacy_config)
    scale_space = analyze_condition(**args, cue_config=scale_config)

    assert torch.equal(legacy["last"], scale_space["last"])
    assert [row["total_loss"] for row in legacy["trajectory"]] == [row["total_loss"] for row in scale_space["trajectory"]]
    assert [row["cue_loss"] for row in legacy["trajectory"]] == [row["cue_loss"] for row in scale_space["trajectory"]]
