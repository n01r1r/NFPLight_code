import torch
import pytest

from run_prediction_refinement import CAPTURE_GROUPS, average_selected_counts, select_frame_indices
from capture_processing.prediction_refinement import (
    F0_RAW,
    estimate_lamp_intensity,
    fixed_specular_raw,
    refine_prediction,
)


def test_fixed_specular_is_immutable_and_raw_f0_is_minus_point_nine_two():
    prediction = torch.zeros(1, 10, 4, 4, dtype=torch.float32)
    prediction[:, 7:] = 0.7
    before = prediction.clone()
    fixed = fixed_specular_raw(prediction)
    assert torch.equal(prediction, before)
    assert torch.allclose(fixed, torch.full_like(fixed, F0_RAW))


def test_refinement_reduces_teacher_error_with_fixed_specular():
    prediction = torch.zeros(1, 10, 4, 4, dtype=torch.float32)
    prediction[:, 2] = 1.0
    prediction[:, 3:6] = -0.2
    prediction[:, 6] = 0.1
    prediction[:, 7:] = 0.6

    def synthetic_render(material, lights, intensity):
        diffuse = (material[:, 3:6] + 1.0) * 0.5
        rough = (material[:, 6:7] + 1.0) * 0.5
        specular = (material[:, 7:10] + 1.0) * 0.5
        image = diffuse + 0.1 * rough + 0.25 * specular
        return image.unsqueeze(1).expand(-1, lights.shape[0], -1, -1, -1) * float(intensity)

    lights = torch.tensor([[0.0, 0.0, 4.0]], dtype=torch.float32)
    source_before = prediction.clone()
    result = refine_prediction(prediction, synthetic_render, lights, steps=60, lr=0.05)
    assert torch.equal(prediction, source_before)
    assert result["metrics"]["final_teacher_mse"] < result["metrics"]["initial_teacher_mse"]
    assert torch.allclose(result["refined_prediction"][:, 7:], torch.full((1, 3, 4, 4), F0_RAW))
    assert result["metrics"]["finite_gradient_steps"] == 60


def test_refinement_accepts_real_svbrdf_renderer_path():
    from utils.render_util import svBRDF

    prediction = torch.zeros(1, 10, 8, 8, dtype=torch.float32)
    prediction[:, 2] = 1.0
    prediction[:, 3:6] = 0.1
    prediction[:, 6] = 0.2
    prediction[:, 7:] = 0.6
    renderer = svBRDF()
    surface = renderer.surface(8, range=1, dtype=torch.float32)

    def real_render(material, lights, intensity):
        renderer.lampIntensity = float(intensity)
        images = []
        for position in lights:
            one = position.reshape(1, 3)
            light, view, distance, _ = renderer.torch_generate(one, one, surface=surface)
            images.append(renderer._render(material, light, view, distance)[:, 0])
        return torch.stack(images, dim=1)

    lights = torch.tensor([[0.0, 0.0, 4.0], [1.0, 0.0, 4.0]], dtype=torch.float32)
    result = refine_prediction(prediction, real_render, lights, steps=8, lr=0.02)
    assert torch.isfinite(result["refined_prediction"]).all()
    assert result["metrics"]["final_teacher_mse"] <= result["metrics"]["initial_teacher_mse"]


def test_lamp_intensity_recovers_known_scalar_and_rejects_empty_support():
    unit = torch.full((1, 3, 2, 2), 0.05, dtype=torch.float32)
    observed = unit * 7.0
    fit = estimate_lamp_intensity(unit, observed)
    assert fit["q"] == pytest.approx(7.0)
    assert fit["fitted_rmse"] == pytest.approx(0.0)
    with pytest.raises(ValueError, match="support is empty"):
        estimate_lamp_intensity(unit, observed, torch.zeros(1, 2, 2, dtype=torch.bool))


def test_invalid_prediction_is_rejected():
    prediction = torch.zeros(1, 10, 4, 4, dtype=torch.float32)
    prediction[0, 0, 0, 0] = float("nan")
    with pytest.raises(ValueError, match="non-finite"):
        fixed_specular_raw(prediction)


def test_selection_uses_recorded_average_or_fallback_indices():
    averaged = {"selected_frames": {"averaged": True, "selected_indices": {"near": [0, 1, 2, 3, 4], "far": [0, 1, 2, 3, 4]}}}
    fallback = {"selected_frames": {"averaged": False, "selected_indices": {"near": [0], "far": [0]}}}
    assert select_frame_indices(averaged, CAPTURE_GROUPS[1]) == ({"near": [0, 1, 2, 3, 4], "far": [0, 1, 2, 3, 4]}, True)
    assert select_frame_indices(fallback, CAPTURE_GROUPS[-1]) == ({"near": [0], "far": [0]}, False)


def test_selection_rejects_unknown_sample():
    with pytest.raises(ValueError, match="unsupported sample"):
        select_frame_indices({"selected_frames": {}}, "not_a_capture")


def test_selected_counts_are_averaged_before_color_transform():
    first = torch.tensor([[[[1.0]]], [[[3.0]]]], dtype=torch.float32).numpy()
    second = torch.tensor([[[[5.0]]], [[[7.0]]]], dtype=torch.float32).numpy()
    averaged = average_selected_counts([first, second])
    assert averaged.dtype.name == "float32"
    assert averaged.tolist() == [[[[3.0]]], [[[5.0]]]]
    with pytest.raises(ValueError, match="selected counts are empty"):
        average_selected_counts([])
