import json
from pathlib import Path
from revise_fixed_f0_report import section, index


def test_fixed_only_presentation_defines_reference_and_preserves_raw_records():
    root = Path('artifacts/rendering_loss_analysis_20261006')
    summary = json.loads((root / 'summary.json').read_text(encoding='utf-8'))
    record = summary['samples'][0]
    page = section(record, '..')
    assert '/free/' not in page
    assert '이중' not in page
    assert '원본은 ground truth가 아니다' in page
    assert 'Mean absolute error' not in page
    assert 'rendering.png' in page
    assert 'maps.png' in page
    assert '미사용 · 최종' in page
    assert 'f0-gallery five' in page
    assert 'repeat(5,minmax(190px,1fr))' in page
    assert 'grid-template-columns:90px' not in page
    assert 'data-f0-gamma' in page
    assert '선택 step' in page
    assert '미사용 조명 영상은 저장하지 않았으므로' in page
    assert 'q=' in page
    assert 'OBSERVATIONS' not in page
    assert 'Council 검토' in page
    assert 'center_changes.png' in page
    assert 'small_changes.png' in page
    assert 'wide_changes.png' in page
    assert 'original_specular' in page
    assert '단일 변화 영상' in page
    assert '중간 회색=0' in page
    assert '<th>small</th>' not in page
    assert 'XY 반경 0.25 · 5광원' in page
    assert 'center free' not in index(summary['samples'], '.')
    for sample in summary['samples']:
        for regime in ('center', 'small', 'wide'):
            assert 'free' in sample['conditions'][regime]  # historical data retained
            assert sample['conditions'][regime]['fixed']['trajectory'][0]['gradient_rms_raw']['s'] == 0
