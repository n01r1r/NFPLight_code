import torch

from run_spherical_refinement import ring, SNAPSHOTS, SAMPLES, EXCLUDED_SAMPLES
from capture_processing.rendering_loss_analysis import analyze_condition


def test_sphere_and_chunked_loss_contract():
    assert SAMPLES == ('260818_174845_478','260818_175005_078','260930_152732_008')
    assert not set(SAMPLES) & set(EXCLUDED_SAMPLES)
    lights = torch.cat([ring(t) for t in (0,5,10,20,30,45)])
    assert len(lights) == 41
    assert torch.allclose(lights.norm(dim=1), torch.full((41,),4.))
    assert not torch.allclose(ring(20), ring(20,22.5))
    assert len(SNAPSHOTS)+1 == 40
    pred = torch.zeros(1,10,2,2); pred[:,2] = 1

    def render(x,l,q):
        return (x[:,3:6]+x[:,7:10]).unsqueeze(1).expand(-1,len(l),-1,-1,-1)*q

    kwargs = dict(mode='fixed',regime='test',steps=3)
    full = analyze_condition(pred,render,lights,lights,1.,**kwargs)
    chunked = analyze_condition(pred,render,lights,lights,1.,light_chunk_size=8,**kwargs)
    assert torch.allclose(full['last'],chunked['last'],atol=1e-6)
    assert abs(full['metrics']['initial_train_mse']-chunked['metrics']['initial_train_mse']) < 1e-6
    stable = analyze_condition(pred,render,ring(0),ring(0),1.,mode='free',regime='stationary',steps=400,stability=True)
    assert stable['termination'] == {'step':300,'status':'stability_criteria_met'}


def test_pdf_uses_active_population_with_archived_records_present(tmp_path, monkeypatch):
    import json
    import build_spherical_refinement_pdf as builder
    summary={'plan':{'active_samples':list(SAMPLES)},'samples':[{'sample':s} for s in SAMPLES]}
    (tmp_path/'summary.json').write_text(json.dumps(summary),encoding='utf-8')
    for sample in SAMPLES:
        folder=tmp_path/sample;folder.mkdir()
        (folder/'metrics.json').write_text(json.dumps({'sample':sample,'conditions':[{'condition_path':'condition.json'}]}),encoding='utf-8')
        (folder/'condition.json').write_text(json.dumps({'theta_deg':'joint'}),encoding='utf-8')
    for sample in EXCLUDED_SAMPLES:
        folder=tmp_path/sample;folder.mkdir()
        (folder/'metrics.json').write_text(json.dumps({'sample':sample,'conditions':[]}),encoding='utf-8')
    monkeypatch.setattr(builder,'ROOT',tmp_path)
    assert [r['sample'] for r in builder.records()]==list(SAMPLES)
