import re
import shutil
import subprocess
import json
from pathlib import Path

import numpy as np
from PIL import Image
import pytest

from build_cue_constraints_report import SAMPLES, build_summary, _add_residual_images, _stop_label


def _saved_cell(base: Path, sample: str, constants: tuple[str, ...], weight: float, *, flat: bool) -> None:
    base.mkdir(parents=True)
    target = base / "theta_joint"
    target.mkdir()
    short = SAMPLES[sample][0]
    variant = f"{''.join(constants)}_lambda_{str(weight).replace('.', 'p')}"
    if flat:
        (base / "plan.json").write_text(json.dumps({
            "sample": sample,
            "spatial_constants": list(constants),
            "preservation_weight": weight,
            "variant_id": variant,
            "source_prediction_path": "cached/original.npz",
        }), encoding="utf-8")
    (base / "metrics.json").write_text(json.dumps({
        "sample": sample,
        "spatial_constants": list(constants),
        "preservation_weight": weight,
        "source_prediction_path": "cached/original.npz",
        "lamp_intensity": {"q": 16.0},
        "final_frame_path": "theta_joint/step_01400.webp",
    }), encoding="utf-8")
    (target / "condition.json").write_text(json.dumps({
        "objective": {"spatial_constants": list(constants), "preservation_weight": weight},
        "termination": {"step": 1400, "status": "stability_criteria_met"},
        "trajectory": [{"measured_mse": .001, "preservation_mse": .002, "common_heldout_mse": .003}],
        "frames": [{"step": 1400, "path": "theta_joint/step_01400.webp"}],
    }), encoding="utf-8")
    maps = np.zeros((1, 10, 256, 256), dtype=np.float32)
    maps[:, 2] = 1.0
    maps[:, 7:10] = -0.92
    maps[:, 6] = np.linspace(-.5, .5, 256, dtype=np.float32)[None, None, :, None]
    np.savez_compressed(target / "render_materials.npz", updated=maps)
    np.savez_compressed(target / 'centered_render_values.npz',
        original=np.full((1,3,256,256), .2, dtype=np.float32),
        updated=np.full((1,3,256,256), .3+weight, dtype=np.float32),
        near=np.full((1,3,256,256), .3, dtype=np.float32))
    Image.new("RGB", (1024, 512), (32, 64, 96)).save(base / "original.webp", format="WEBP", lossless=True)
    Image.new("RGB", (1024, 512), (96, 64, 32)).save(target / "step_01400.webp", format="WEBP", lossless=True)
    for name, color in (("center_original", (30, 40, 50)), ("center_updated", (50, 40, 30)), ("measured_near", (60, 70, 80))):
        Image.new("RGB", (256, 256), color).save(target / f"{name}.webp", format="WEBP", lossless=True)


def _report_fixture(tmp_path: Path) -> tuple[Path, Path]:
    repo = tmp_path
    root = repo / "artifacts" / "cue_constraints_lambda_20261007"
    root.mkdir(parents=True)
    reused = [
        ("260818_174845_478", ("d",), .1, "artifacts/reuse_478_d"),
        ("260818_174845_478", ("d", "r"), .1, "artifacts/reuse_478_dr"),
        ("260818_175005_078", ("n",), .1, "artifacts/reuse_078_n"),
    ]
    (root / "experiment_plan.json").write_text(json.dumps({
        "reuse": [
            {"sample": sample, "constants": list(constants), "lambda": weight, "root": source}
            for sample, constants, weight, source in reused
        ]
    }), encoding="utf-8")
    for sample, constants, weight, source in reused:
        _saved_cell(repo / source / sample, sample, constants, weight, flat=False)

    new_cells = [
        ("260818_174845_478", ("d",), .5),
        ("260818_174845_478", ("d", "r"), .5),
        ("260818_175005_078", ("n", "r"), .1),
        ("260818_175005_078", ("n",), .5),
        ("260818_175005_078", ("n", "r"), .5),
    ]
    for sample, constants, weight in new_cells:
        variant = f"{''.join(constants)}_lambda_{str(weight).replace('.', 'p')}"
        _saved_cell(root / sample / variant, sample, constants, weight, flat=True)
    return repo, root


def test_report_is_self_contained_and_uses_one_matrix_template(tmp_path: Path):
    repo, root = _report_fixture(tmp_path)
    output = root / "summary.html"
    result = build_summary(root, output, repo)
    text = output.read_text(encoding="utf-8")

    assert result["complete_cells"] == 8
    assert result["pending_cells"] == 0
    assert text.index('id="sample-260818_174845_478"') < text.index('id="sample-260818_175005_078"')
    map_tables = re.findall(r'<table class="map-table">(.*?)</table>', text, re.S)
    assert len(map_tables) == 2
    assert text.count('<table class="metric-table">') == 2
    headers = [re.search(r"<thead>.*?</thead>", table, re.S).group(0) for table in map_tables]
    assert headers[0] == headers[1]
    assert all('<col span="7">' in table for table in map_tables)
    assert "table-layout:fixed;min-width:1540px" in text
    assert text.count('type="checkbox"') == 8
    assert text.count(" checked>") == 8
    assert "window.setVariantVisible = setVariantVisible" in text
    assert "data-run-id=" in text and "data-run-toggle=" in text
    assert "λ=0.1" in text and "λ=0.5" in text
    assert "Held-out MSE" in text
    assert "total_loss" not in text
    assert "data:image/png;base64," in text
    assert 'src="http' not in text and 'href="http' not in text
    assert "결과 대기" not in text
    assert "공간 상수" not in text
    assert "ΔE00 · render / I<sub>N</sub>" in text
    assert "constant" in text


def test_incomplete_cell_stays_pending_without_fabricated_metrics_or_images(tmp_path: Path):
    repo, root = _report_fixture(tmp_path)
    incomplete = root / "260818_175005_078" / "n_lambda_0p5" / "theta_joint" / "center_updated.webp"
    incomplete.unlink()
    output = root / "summary.html"

    result = build_summary(root, output, repo)
    text = output.read_text(encoding="utf-8")

    assert result["complete_cells"] == 7
    assert result["pending_cells"] == 1
    assert "결과 대기" in text
    assert "완료 기록 없음" not in text
    assert "1,400 - 수렴" in text
    assert "stability_criteria_met" not in text
    assert "data-run-id=\"078-n-lambda-0p5\"" in text


def test_variant_checkbox_hides_and_restores_both_report_rows(tmp_path: Path):
    node = shutil.which("node")
    if not node:
        pytest.skip("Node.js is unavailable for the inline toggle check")
    repo, root = _report_fixture(tmp_path)
    output = root / "summary.html"
    build_summary(root, output, repo)
    text = output.read_text(encoding="utf-8")
    script = re.search(r"<script>\s*(.*?)\s*</script>", text, re.S).group(1)
    harness = f"""
const rows = [
  {{dataset: {{runId: "478-d-lambda-0p1"}}, hidden: false}},
  {{dataset: {{runId: "478-d-lambda-0p1"}}, hidden: false}},
  {{dataset: {{runId: "078-n-lambda-0p1"}}, hidden: false}}
];
const control = {{
  dataset: {{runToggle: "478-d-lambda-0p1"}},
  checked: true,
  handlers: {{}},
  addEventListener(name, handler) {{ this.handlers[name] = handler; }}
}};
global.document = {{
  querySelectorAll(selector) {{ return selector === "[data-run-id]" ? rows : [control]; }}
}};
global.window = {{}};
eval({json.dumps(script)});
control.checked = false;
control.handlers.change();
if (!rows[0].hidden || !rows[1].hidden || rows[2].hidden) throw new Error("checkbox did not hide matching rows only");
window.setVariantVisible("478-d-lambda-0p1", true);
if (rows[0].hidden || rows[1].hidden || rows[2].hidden) throw new Error("exported toggle did not restore matching rows");
"""
    result = subprocess.run([node, "-e", harness], capture_output=True, text=True, check=False)
    assert result.returncode == 0, result.stderr


def test_delta_e_residual_uses_shared_range_and_embedded_legend():
    import base64
    import io
    cells = [{'ready':True,'images':{},'original_images':{},
              'residuals':{'updated':np.full((16,16),value,np.float32),
                           'original':np.zeros((16,16),np.float32)}} for value in (.25,1.)]
    _add_residual_images(cells)
    assert all(cell['residual_scale'] == 1 for cell in cells)
    def pixels(tag):
        uri = re.search(r'src="([^"]+)"',tag).group(1)
        return np.asarray(Image.open(io.BytesIO(base64.b64decode(uri.split(',')[1]))))
    assert pixels(cells[0]['images']['difference']).shape == (103,128,3)
    assert not np.array_equal(pixels(cells[0]['images']['difference'])[:16],pixels(cells[1]['images']['difference'])[:16])
    assert 'embedded legend' in cells[0]['images']['difference']
    cells[0]['residuals']['updated'] *= -1
    import pytest
    with pytest.raises(ValueError,match='nonnegative'):
        _add_residual_images(cells)
    assert _stop_label({'step':7400,'termination':'stability_criteria_met'}) == '7,400 - 수렴'
    assert _stop_label({'step':10000,'termination':'max_steps_reached'}) == '10,000 - 수렴X'
