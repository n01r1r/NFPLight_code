import argparse
import pytest
import torch

from run_cue_constrained_refinement import (
    _check_final_losses,
    parse_constants,
    validate_variant,
    variant_id,
)
from capture_processing.rendering_loss_analysis import analyze_condition


def test_variant_controls_match_the_confirmed_sample_grid():
    assert parse_constants('n,r') == ('n', 'r')
    assert parse_constants('d,r') == ('d', 'r')
    assert validate_variant('260818_175005_078', ('n', 'r'), 0.1) == 0.1
    assert validate_variant('260818_174845_478', ('d',), 0.5) == 0.5
    assert variant_id(('d', 'r'), 0.5) == 'd_r_lambda_0p5'
    with pytest.raises(ValueError, match='unsupported constants'):
        validate_variant('260818_175005_078', ('d',), 0.1)
    with pytest.raises(ValueError, match='preservation weight'):
        validate_variant('260818_174845_478', ('d',), 0.2)
    with pytest.raises(argparse.ArgumentTypeError):
        parse_constants('n,n')


def test_lambda_scales_only_preservation_and_constants_stay_uniform():
    prediction = torch.zeros(1, 10, 2, 2, dtype=torch.float32)
    prediction[:, 2] = 0.9
    prediction[:, 3:6] = torch.tensor(
        [[[[ -0.8, -0.2], [0.1, 0.7]],
          [[ -0.6, 0.4], [0.2, 0.8]],
          [[ -0.4, 0.5], [-0.1, 0.6]]]],
        dtype=torch.float32,
    )
    prediction[:, 6] = torch.tensor([[[[-0.7, -0.1], [0.3, 0.8]]]])
    prediction[:, 7:] = 0.6
    before = prediction.clone()

    def render(material, lights, intensity):
        diffuse = (material[:, 3:6] + 1.0) * 0.5
        roughness = (material[:, 6:7] + 1.0) * 0.5
        image = diffuse + 0.05 * roughness + 0.01
        return image.unsqueeze(1).expand(-1, lights.shape[0], -1, -1, -1) * float(intensity)

    train = torch.tensor([[1.0, 0.0, 4.0], [0.0, 1.0, 4.0]], dtype=torch.float32)
    evaluation = torch.tensor([[-1.0, 0.0, 4.0], [0.0, -1.0, 4.0]], dtype=torch.float32)
    center = torch.tensor([[0.0, 0.0, 4.0]], dtype=torch.float32)
    measured = torch.full((1, 3, 2, 2), 0.4, dtype=torch.float32)
    results = []
    for weight in (0.1, 0.5):
        result = analyze_condition(
            prediction,
            render,
            train,
            evaluation,
            1.0,
            mode='fixed',
            regime='runner-contract-test',
            steps=1,
            lr=0.01,
            seed=0,
            measured_target=measured,
            measured_light=center,
            preservation_weight=weight,
            spatial_constants=('d', 'r'),
        )
        row = result['trajectory'][0]
        assert row['total_loss'] == pytest.approx(
            row['measured_mse'] + weight * row['preservation_mse'], rel=1e-6
        )
        assert result['objective']['preservation_weight'] == weight
        for state_name in ('initial', 'last'):
            state = result[state_name]
            for channels in (slice(3, 6), slice(6, 7)):
                values = state[:, channels]
                assert torch.equal(values, values[:, :, :1, :1].expand_as(values))
        results.append(row)
    assert results[0]['preservation_mse'] > 0
    assert results[1]['total_loss'] - results[0]['total_loss'] == pytest.approx(
        0.4 * results[0]['preservation_mse'], rel=1e-5
    )
    assert torch.equal(prediction, before)


def test_final_loss_audit_uses_existing_numerical_tolerance():
    recomputed = {
        'measured_mse': 2.0e-5,
        'preservation_mse': 3.0e-4,
        'weighted_preservation_mse': 1.5e-4,
        'total_loss': 1.7e-4,
    }
    terminal = {key: value * (1 + 1e-6) for key, value in recomputed.items()}
    assert _check_final_losses(recomputed, terminal) == terminal
    terminal['measured_mse'] += 1e-5
    with pytest.raises(AssertionError, match='measured_mse'):
        _check_final_losses(recomputed, terminal)
