import pytest
import torch

from capture_processing.color_cue import build_color_cue_context, evaluate_color_cue


def _maps(size=32):
    y = torch.linspace(0, 2 * torch.pi, size)
    xx, yy = torch.meshgrid(y, y, indexing="xy")
    normal = torch.stack((0.1 * torch.sin(yy), 0.1 * torch.sin(xx), torch.ones_like(xx)))
    normal = torch.nn.functional.normalize(normal, dim=0).unsqueeze(0)
    roughness = (0.5 + 0.1 * torch.sin(xx + yy)).view(1, 1, size, size)
    chroma = (0.5 + 0.2 * torch.sin(xx)).clamp_min(0)
    target = torch.stack((chroma, 1 - chroma, torch.full_like(chroma, 0.5))).unsqueeze(0)
    return normal.float(), roughness.float(), target.float()


def test_initial_active_cue_is_unit_scaled_and_detail_is_zero():
    normal, roughness, target = _maps()
    context = build_color_cue_context(normal, roughness, target, lowpass_kernel=9, local_kernel=31)

    terms = evaluate_color_cue(normal, roughness, context)

    assert terms["normal_active"] is True
    assert terms["cue_loss"].item() == pytest.approx(1.0, rel=1e-6)
    assert terms["normal_detail_loss"].item() == pytest.approx(0.0, abs=1e-8)


def test_full_resolution_cue_detects_yarn_scale_color_correlated_normal():
    size = 32
    checker = torch.arange(size).remainder(2).float().mul(2).sub(1)
    checker = checker.view(1, 1, 1, size).expand(1, 1, size, size)
    normal = torch.cat((checker * 0.1, torch.zeros_like(checker), torch.full_like(checker, (0.99 ** 0.5))), dim=1)
    target = torch.cat((0.5 + checker * 0.2, 1.0 - checker * 0.2, torch.full_like(checker, 0.5)), dim=1)
    roughness = torch.full((1, 1, size, size), 0.5)

    full = build_color_cue_context(normal, roughness, target, lowpass_kernel=1, local_kernel=7)
    lowpass = build_color_cue_context(normal, roughness, target, lowpass_kernel=5, local_kernel=7)

    assert full.normal_active
    assert full.normal_scale.item() > 1e-3
    assert lowpass.normal_scale.item() < full.normal_scale.item() * 0.1


def test_partially_dark_target_is_rejected_before_chromaticity_pooling():
    normal, roughness, target = _maps()
    target[:, :, :1, :1] = 0

    with pytest.raises(ValueError, match="partially dark chromaticity unsupported"):
        build_color_cue_context(normal, roughness, target, lowpass_kernel=3, local_kernel=7)


def test_fully_dark_target_has_inactive_cue_even_if_channel_ratios_vary():
    normal, roughness, target = _maps()
    target = target * 1e-5

    context = build_color_cue_context(normal, roughness, target, lowpass_kernel=3, local_kernel=7)

    assert context.dark_fraction == 1.0
    assert not context.normal_active
    assert not context.roughness_active
    assert torch.isfinite(evaluate_color_cue(normal, roughness, context)["cue_loss"])


@pytest.mark.parametrize("brightness_scaled", [False, True])
def test_scalar_brightness_with_constant_chromaticity_does_not_activate_cue(brightness_scaled):
    size = 64
    x = torch.arange(size, dtype=torch.float32).view(1, 1, 1, size).expand(1, 1, size, size)
    broad = torch.sin(2 * torch.pi * x / 32)
    fine = torch.sin(2 * torch.pi * x / 4)
    one = torch.ones_like(x)
    normal = torch.nn.functional.normalize(torch.cat((0.15 * broad, 0.08 * fine, one), dim=1), dim=1)
    roughness = 0.5 + 0.1 * broad
    if brightness_scaled:
        brightness = 0.1 + 0.8 * x / 63
        target = torch.cat((0.2 * brightness, 0.4 * brightness, 0.6 * brightness), dim=1)
    else:
        target = torch.cat((0.5 + 0.2 * broad,) * 3, dim=1)

    context = build_color_cue_context(normal, roughness, target, lowpass_kernel=9, local_kernel=31)

    assert not context.normal_active
    assert not context.roughness_active
    assert context.normal_scale.item() < 1e-8
    assert context.roughness_scale.item() < 1e-8


def test_lowpass_cue_with_detail_anchor_retains_fine_normal_signal():
    size = 64
    x = torch.arange(size, dtype=torch.float32).view(1, 1, 1, size).expand(1, 1, size, size)
    broad = torch.sin(2 * torch.pi * x / 32)
    fine = torch.sin(2 * torch.pi * x / 4)
    one = torch.ones_like(x)
    initial = torch.nn.functional.normalize(torch.cat((0.15 * broad + 0.08 * fine, torch.zeros_like(x), one), dim=1), dim=1)
    target = torch.cat((0.5 + 0.2 * broad, 0.5 - 0.2 * broad, 0.5 * one), dim=1)
    roughness = torch.full((1, 1, size, size), 0.5)

    def refine(kernel, detail_budget):
        context = build_color_cue_context(initial, roughness, target, lowpass_kernel=kernel, local_kernel=7)
        raw = torch.nn.Parameter(initial.clone())
        optimizer = torch.optim.Adam([raw], lr=0.01)
        for _ in range(5):
            optimizer.zero_grad()
            current = torch.nn.functional.normalize(raw, dim=1)
            terms = evaluate_color_cue(current, roughness, context)
            loss = 0.1 * terms["cue_loss"] + detail_budget * terms["normal_detail_loss"]
            loss.backward()
            optimizer.step()
        return torch.nn.functional.normalize(raw.detach(), dim=1)

    def fine_error(value):
        high = value - torch.nn.functional.avg_pool2d(
            torch.nn.functional.pad(value, (4, 4, 4, 4), mode="reflect"), 9, stride=1
        )
        high_initial = initial - torch.nn.functional.avg_pool2d(
            torch.nn.functional.pad(initial, (4, 4, 4, 4), mode="reflect"), 9, stride=1
        )
        return ((high - high_initial).square().mean() / high_initial.square().mean()).sqrt()

    full_resolution = refine(1, 0.0)
    lowpass_anchored = refine(9, 1.0)

    assert fine_error(lowpass_anchored) < fine_error(full_resolution) * 0.5


def test_roughness_filter_is_independent_from_normal_and_detail_filter():
    normal, roughness, target = _maps()
    mixed = build_color_cue_context(
        normal, roughness, target, lowpass_kernel=9, roughness_lowpass_kernel=1, local_kernel=7
    )
    other_roughness = build_color_cue_context(
        normal, roughness, target, lowpass_kernel=9, roughness_lowpass_kernel=5, local_kernel=7
    )
    full_resolution = build_color_cue_context(normal, roughness, target, lowpass_kernel=1, local_kernel=7)

    mixed_terms = evaluate_color_cue(normal, roughness, mixed)
    other_terms = evaluate_color_cue(normal, roughness, other_roughness)
    full_terms = evaluate_color_cue(normal, roughness, full_resolution)

    assert mixed.roughness_lowpass_kernel == 1
    assert mixed_terms["normal_cue_raw"] == pytest.approx(other_terms["normal_cue_raw"], abs=0.0)
    assert mixed_terms["normal_detail_raw"] == pytest.approx(other_terms["normal_detail_raw"], abs=0.0)
    assert mixed_terms["roughness_cue_raw"] == pytest.approx(full_terms["roughness_cue_raw"], abs=0.0)


def test_roughness_filter_none_matches_explicit_normal_filter():
    normal, roughness, target = _maps()
    default = build_color_cue_context(normal, roughness, target, lowpass_kernel=5, local_kernel=7)
    explicit = build_color_cue_context(
        normal, roughness, target, lowpass_kernel=5, roughness_lowpass_kernel=5, local_kernel=7
    )

    assert default.roughness_lowpass_kernel == 5
    assert torch.equal(default.normal_scale, explicit.normal_scale)
    assert torch.equal(default.roughness_scale, explicit.roughness_scale)
    assert torch.equal(default.detail_scale, explicit.detail_scale)


def test_initial_multiscale_cue_is_unit_scaled_across_active_bands():
    normal, roughness, target = _maps(size=64)
    context = build_color_cue_context(
        normal, roughness, target, lowpass_kernel=9, local_kernel=7,
        normal_cue_kernels=(5, 9, 17), roughness_cue_kernels=(1, 5, 9),
    )

    terms = evaluate_color_cue(normal, roughness, context)

    assert context.normal_cue_kernels == (5, 9, 17)
    assert context.roughness_cue_kernels == (1, 5, 9)
    assert terms["cue_loss"].item() == pytest.approx(1.0, rel=1e-6)
    assert all(
        value == pytest.approx(1.0, rel=1e-6)
        for value, active in zip(terms["normal_cue_band_normalized"], terms["normal_cue_band_active"])
        if active
    )


def test_six_band_loss_matches_independently_normalized_contexts():
    normal, roughness, target = _maps(size=64)
    current_normal = normal.flip(-1).contiguous()
    current_roughness = (roughness.flip(-1) * 0.9 + 0.05).contiguous()
    normal_kernels = (5, 9, 17)
    roughness_kernels = (1, 5, 9)
    multiscale = build_color_cue_context(
        normal, roughness, target, lowpass_kernel=9, local_kernel=7,
        normal_cue_kernels=normal_kernels, roughness_cue_kernels=roughness_kernels,
    )
    terms = evaluate_color_cue(current_normal, current_roughness, multiscale)
    normal_ratios = []
    for kernel in normal_kernels:
        context = build_color_cue_context(normal, roughness, target, lowpass_kernel=kernel, local_kernel=7)
        single = evaluate_color_cue(current_normal, current_roughness, context)
        if context.normal_active:
            normal_ratios.append(single["normal_cue_raw"] / context.normal_scale)
    roughness_ratios = []
    for kernel in roughness_kernels:
        context = build_color_cue_context(
            normal, roughness, target, lowpass_kernel=9, roughness_lowpass_kernel=kernel, local_kernel=7
        )
        single = evaluate_color_cue(current_normal, current_roughness, context)
        if context.roughness_active:
            roughness_ratios.append(single["roughness_cue_raw"] / context.roughness_scale)
    components = [torch.stack(normal_ratios).mean(), torch.stack(roughness_ratios).mean()]

    assert terms["cue_loss"] == pytest.approx(float(torch.stack(components).mean()), rel=1e-6)
    assert terms["normal_detail_raw"] == pytest.approx(
        evaluate_color_cue(current_normal, current_roughness,
            build_color_cue_context(normal, roughness, target, lowpass_kernel=9, local_kernel=7)
        )["normal_detail_raw"],
        abs=0.0,
    )
