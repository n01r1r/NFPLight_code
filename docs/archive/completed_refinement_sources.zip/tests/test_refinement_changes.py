import pytest
import torch
from render_refinement_changes import change_fields, signed_rgb
import numpy as np


def test_physical_signed_rgb_difference_and_normal_angular_change():
    original = torch.zeros(1, 10, 2, 2, dtype=torch.float32)
    original[:, 2] = 1
    current = original.clone()
    current[:, :3] = 0
    current[:, 0] = 1
    current[:, 3] = .4
    current[:, 4] = -.2
    current[:, 6] = .2
    current[:, 7:] = -.92
    delta = change_fields(original, current)
    assert torch.allclose(delta['normal_angle_deg'], torch.full((1, 2, 2), 90.))
    assert delta['diffuse'][0, 0].mean() == pytest.approx(.2)
    assert delta['diffuse'][0, 1].mean() == pytest.approx(-.1)
    assert delta['roughness'].mean() == pytest.approx(.1)
    assert delta['specular'].mean() == pytest.approx(-.46)
    unchanged = change_fields(current, current)
    assert unchanged['normal_angle_deg'].max() == pytest.approx(0, abs=1e-6)
    assert unchanged['specular'].abs().max() == 0


def test_single_signed_rgb_image_preserves_channel_sign_and_neutral_zero():
    delta = np.array([[[1.]], [[0.]], [[-1.]]], dtype=np.float32)
    assert np.array_equal(signed_rgb(delta, 1)[0, 0], [1, .5, 0])
    assert np.array_equal(signed_rgb(np.zeros((3, 1, 1), np.float32), 1)[0, 0], [.5, .5, .5])
    assert np.array_equal(signed_rgb(np.array([[[-1.]]], np.float32), 1)[0, 0], [0, 0, 0])
