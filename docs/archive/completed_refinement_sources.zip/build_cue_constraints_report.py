"""Build a single-file comparison report from saved cue-constraint results."""

from __future__ import annotations

import argparse
import base64
import html
import io
import json
import math
from pathlib import Path
from capture_processing.difference_visualization import render_delta_e00, display_range, png_bytes
from typing import Any

import numpy as np
from PIL import Image


REPO_ROOT = Path(__file__).resolve().parent
DEFAULT_ROOT = REPO_ROOT / "artifacts" / "cue_constraints_lambda_20261007"
SAMPLES = {
    "260818_174845_478": ("478", (("d",), ("d", "r"))),
    "260818_175005_078": ("078", (("n",), ("n", "r"))),
}
LAMBDAS = (0.1, 0.5)
MAP_COLUMNS = (
    ("normal", "Normal", (0, 0, 256, 256)),
    ("diffuse", "Diffuse", (256, 0, 512, 256)),
    ("roughness", "Roughness", (512, 0, 768, 256)),
    ("f0", "F₀", (768, 0, 1024, 256)),
)


def _read_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _constants(value: Any) -> tuple[str, ...] | None:
    if value is None:
        return None
    if isinstance(value, str):
        value = value.replace("+", ",").split(",")
    if not isinstance(value, (list, tuple)):
        return None
    names = {str(item).strip() for item in value}
    if not names <= {"n", "d", "r"}:
        raise ValueError(f"unsupported spatial constants: {value!r}")
    return tuple(name for name in ("n", "d", "r") if name in names)


def _weight(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if math.isfinite(result) else None


def _source_record(*sources: dict[str, Any]) -> Any:
    for source in sources:
        if not isinstance(source, dict):
            continue
        for key in ("source_prediction_path", "original_prediction_path", "prediction_source", "original_prediction_source"):
            value = source.get(key)
            if isinstance(value, (str, dict)):
                return value
    return None


def _cell_metadata(*sources: dict[str, Any]) -> tuple[str | None, tuple[str, ...] | None, float | None]:
    sample = None
    constants = None
    weight = None
    for source in sources:
        if not isinstance(source, dict):
            continue
        sample = sample or source.get("sample")
        spatial_constants = source.get("spatial_constants")
        if isinstance(spatial_constants, dict) and sample:
            spatial_constants = spatial_constants.get(sample)
        constants = constants or _constants(spatial_constants)
        weight = weight if weight is not None else _weight(source.get("preservation_weight"))
        objective = source.get("objective")
        if isinstance(objective, dict):
            constants = constants or _constants(objective.get("spatial_constants"))
            weight = weight if weight is not None else _weight(objective.get("preservation_weight"))
    return sample, constants, weight


def _cell_id(short: str, constants: tuple[str, ...], preservation_weight: float) -> str:
    code = "".join(constants)
    lambda_code = "0p1" if math.isclose(preservation_weight, 0.1) else "0p5"
    return f"{short}-{code}-lambda-{lambda_code}"


def _reuse_paths(plan: dict[str, Any], repo_root: Path) -> dict[tuple[str, tuple[str, ...], float], Path]:
    paths = {}
    for record in plan.get("reuse", []):
        constants = _constants(record.get("constants", record.get("spatial_constants")))
        weight = _weight(record.get("lambda", record.get("preservation_weight")))
        sample = record.get("sample")
        if sample and constants is not None and weight is not None:
            source = Path(str(record["root"]).replace("\\", "/"))
            if not source.is_absolute():
                source = repo_root / source
            paths[(sample, constants, weight)] = source / sample
    return paths


def _new_run_paths(root: Path) -> dict[tuple[str, tuple[str, ...], float], Path]:
    paths: dict[tuple[str, tuple[str, ...], float], Path] = {}
    for plan_path in root.glob("*/*/plan.json"):
        run_dir = plan_path.parent
        metadata = _read_json(plan_path)
        metrics_path = run_dir / "metrics.json"
        if metrics_path.is_file():
            metrics = _read_json(metrics_path)
        else:
            metrics = {}
        sample, constants, weight = _cell_metadata(metadata, metrics)
        if sample is None or constants is None or weight is None:
            continue
        key = (sample, constants, weight)
        if key in paths:
            raise ValueError(f"multiple new result directories match {key}: {paths[key]} and {run_dir}")
        paths[key] = run_dir
    return paths


def _data_uri(path: Path, crop: tuple[int, int, int, int] | None, cache: dict[tuple[Path, Any], str]) -> str:
    key = (path.resolve(), crop)
    if key in cache:
        return cache[key]
    with Image.open(path) as source:
        image = source.convert("RGB")
        if crop is not None:
            image = image.crop(crop)
        if image.size != (256, 256):
            raise ValueError(f"report images must resolve to 256×256 pixels: {path} has {image.size}")
        output = io.BytesIO()
        image.save(output, format="PNG", optimize=False)
    uri = "data:image/png;base64," + base64.b64encode(output.getvalue()).decode("ascii")
    cache[key] = uri
    return uri


def _image_tag(uri: str, alt: str) -> str:
    return f'<img src="{uri}" width="256" height="256" alt="{html.escape(alt, quote=True)}" loading="lazy">'


def _number(value: Any) -> str:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return "기록 없음"
    if not math.isfinite(result):
        raise ValueError(f"report metric is not finite: {value!r}")
    return f"{result:.6g}"


def _resolve_saved_path(base: Path, relative: Any) -> Path | None:
    if not isinstance(relative, str) or not relative:
        return None
    candidate = base / relative.replace("\\", "/")
    return candidate if candidate.is_file() else None


def _load_cell(
    sample: str,
    constants: tuple[str, ...],
    preservation_weight: float,
    base: Path | None,
    short: str,
    cache: dict[tuple[Path, Any], str],
) -> dict[str, Any]:
    run_id = _cell_id(short, constants, preservation_weight)
    cell: dict[str, Any] = {
        "id": run_id,
        "constants": constants,
        "weight": preservation_weight,
        "label": ' + '.join({'n': 'normal', 'd': 'diffuse', 'r': 'roughness'}[name] for name in constants) + ' constant',
        "ready": False,
        "reason": "결과 대기",
    }
    if base is None:
        return cell

    metrics_path = base / "metrics.json"
    condition_path = base / "theta_joint" / "condition.json"
    materials_path = base / "theta_joint" / "render_materials.npz"
    if not all(path.is_file() for path in (metrics_path, condition_path, materials_path)):
        return cell

    metrics = _read_json(metrics_path)
    condition = _read_json(condition_path)
    objective = condition.get("objective", {})
    actual_constants = _constants(objective.get("spatial_constants"))
    actual_weight = _weight(objective.get("preservation_weight"))
    if actual_constants != constants or actual_weight is None or not math.isclose(actual_weight, preservation_weight):
        raise ValueError(f"saved objective does not match report cell {run_id}: {objective!r}")
    termination = condition.get("termination")
    trajectory = condition.get("trajectory")
    if not isinstance(termination, dict) or not termination.get("status") or termination.get("step") is None:
        return cell
    if not isinstance(trajectory, list) or not trajectory:
        return cell

    frame_path = None
    frames = condition.get("frames", [])
    if frames and isinstance(frames[-1], dict):
        frame_path = _resolve_saved_path(base, frames[-1].get("path"))
    if frame_path is None:
        frame_path = _resolve_saved_path(base, metrics.get("final_frame_path"))
    original_path = base / "original.webp"
    center_original = base / "theta_joint" / "center_original.webp"
    center_updated = base / "theta_joint" / "center_updated.webp"
    measured = base / "theta_joint" / "measured_near.webp"
    image_paths = (frame_path, original_path, center_original, center_updated, measured)
    if any(path is None or not path.is_file() for path in image_paths):
        return cell
    render_values = base / 'theta_joint' / 'centered_render_values.npz'
    if not render_values.is_file():
        return cell
    with np.load(render_values) as values:
        residuals = {}
        for stage in ('original', 'updated'):
            render, near = values[stage], values['near']
            if render.shape != (1, 3, 256, 256) or near.shape != render.shape:
                raise ValueError(f'{render_values}: expected [1,3,256,256] rendering and I_N')
            if render.dtype != np.float32 or near.dtype != np.float32:
                raise ValueError(f'{render_values}: rendering and I_N must be FP32')
            delta = render_delta_e00(near[0].transpose(1,2,0), render[0].transpose(1,2,0))
            if not np.isfinite(delta).all():
                raise ValueError(f'{render_values}: non-finite render minus I_N')
            residuals[stage] = delta.copy()
    cell['residuals'] = residuals

    with np.load(materials_path) as saved:
        if "updated" not in saved.files:
            return cell
        updated = saved["updated"]
        if updated.dtype != np.float32 or updated.ndim != 4 or updated.shape[0:2] != (1, 10):
            raise ValueError(f"{materials_path} must contain updated FP32 [1,10,H,W] maps")
        if not np.isfinite(updated).all():
            raise ValueError(f"{materials_path} contains non-finite material values")
        if not np.all(updated[:, 7:10] == np.float32(-0.92)):
            raise ValueError(f"{materials_path} does not preserve fixed F₀=0.04")
        roughness = np.clip((updated[:, 6].astype(np.float64) + 1.0) * 0.5, 0.05, 1.0)
        roughness_std = float(roughness.std())

    last = trajectory[-1]
    metric_aliases = (
        ("measured_mse", ("measured_mse", "train_measured_mse")),
        ("preservation_mse", ("preservation_mse", "raw_preservation_mse")),
        ("heldout_mse", ("common_heldout_mse", "heldout_mse")),
    )
    rendered_metrics = {}
    for target, names in metric_aliases:
        value = next((last[name] for name in names if name in last), None)
        if value is None:
            return cell
        rendered_metrics[target] = _number(value)

    cell["images"] = {
        image_key: _image_tag(
            _data_uri(frame_path, crop, cache), f"{sample} 최종 {key} 절대 표시"
        )
        for image_key, key, crop in MAP_COLUMNS
    }
    cell["original_images"] = {
        image_key: _image_tag(
            _data_uri(original_path, crop, cache), f"{sample} 원본 pretrained {key} 절대 표시"
        )
        for image_key, key, crop in MAP_COLUMNS
    }
    cell["images"].update({
        "center": _image_tag(_data_uri(center_updated, None, cache), f"{sample} λ={preservation_weight:g} 중앙 재렌더링"),
        "measured": _image_tag(_data_uri(measured, None, cache), f"{sample} 측정 I_N reference"),
    })
    cell["original_images"].update({
        "center": _image_tag(_data_uri(center_original, None, cache), f"{sample} 원본 pretrained 중앙 렌더링"),
        "measured": _image_tag(_data_uri(measured, None, cache), f"{sample} 측정 I_N reference"),
    })
    cell["metrics"] = rendered_metrics
    cell["roughness_std"] = _number(roughness_std)
    cell["step"] = int(termination["step"])
    cell["termination"] = str(termination["status"])
    cell["ready"] = True
    cell["reason"] = ""
    cell["source"] = str(base)
    plan_path = base / "plan.json"
    if not plan_path.is_file():
        plan_path = base.parent / "plan.json"
    plan_metadata = _read_json(plan_path) if plan_path.is_file() else {}
    cell["source_prediction"] = _source_record(metrics, plan_metadata)
    lamp = metrics.get("lamp_intensity")
    q = lamp.get("q") if isinstance(lamp, dict) else metrics.get("q")
    if q is None:
        q = plan_metadata.get("q")
    cell["q"] = _number(q) if q is not None else "기록 없음"
    return cell


def _missing_image() -> str:
    return '<span class="pending">결과 대기</span>'


def _difference_uri(delta: np.ndarray, scale: dict) -> str:
    return 'data:image/png;base64,' + base64.b64encode(png_bytes(delta,scale,'CIEDE2000 Delta E00')).decode('ascii')


def _add_residual_images(cells: list[dict[str, Any]]) -> None:
    ready = [cell for cell in cells if cell['ready']]
    if not ready:
        return
    scale = display_range([delta for cell in ready for delta in cell['residuals'].values()])
    for cell in ready:
        cell['residual_scale'] = scale['max']
        cell['residual_range'] = scale
        for stage, key in (('updated', 'images'), ('original', 'original_images')):
            cell[key]['difference'] = _image_tag(_difference_uri(cell['residuals'][stage],scale), 'render versus I_N: CIEDE2000 Delta E00, embedded legend')


def _stop_label(cell):
    status = '수렴' if cell['termination'] == 'stability_criteria_met' else '수렴X'
    return f"{cell['step']:,} - {status}"


def _map_row(label: str, images: dict[str, str] | None, *, run_id: str | None = None, weight: float | None = None, stop: str = "") -> str:
    attrs = f' data-run-id="{html.escape(run_id, quote=True)}"' if run_id else ""
    cells = [images[key] for key in ("normal", "diffuse", "roughness", "f0", "center", "difference", "measured")] if images else [_missing_image()] * 7
    lambda_text = f"λ={weight:.1f}" if weight is not None else "—"
    return (
        f'<tr class="map-row"{attrs}><th scope="row">{html.escape(label)}</th>'
        f'<td class="lambda">{lambda_text}</td><td class="stop">{html.escape(stop)}</td>'
        + "".join(f"<td>{content}</td>" for content in cells)
        + "</tr>"
    )


def _metric_row(cell: dict[str, Any]) -> str:
    run_id = html.escape(cell["id"], quote=True)
    if not cell["ready"]:
        values = ("결과 대기", "결과 대기", "결과 대기", "—", "—")
    else:
        values = (
            cell["metrics"]["measured_mse"],
            cell["metrics"]["preservation_mse"],
            cell["metrics"]["heldout_mse"],
            cell["roughness_std"],
            _stop_label(cell),
        )
    return (
        f'<tr class="metric-row" data-run-id="{run_id}">'
        f'<th scope="row">{html.escape(cell["label"])}</th><td>λ={cell["weight"]:.1f}</td>'
        + "".join(f"<td>{html.escape(value)}</td>" for value in values)
        + "</tr>"
    )


def _render_sample_section(sample: str, short: str, cells: list[dict[str, Any]]) -> str:
    sample_name = html.escape(sample)
    section_id = f"sample-{sample}"
    controls = []
    for cell in cells:
        checked = " checked"
        state = "" if cell["ready"] else " · 결과 대기"
        controls.append(
            f'<label><input type="checkbox" data-run-toggle="{html.escape(cell["id"], quote=True)}"{checked}> '
            f'{html.escape(cell["label"])} · λ={cell["weight"]:.1f}{state}</label>'
        )
    base_case = next((cell for cell in cells if cell["ready"]), None)
    original_images = base_case["original_images"] if base_case else None
    map_rows = [_map_row("원본 pretrained prediction", original_images)]
    for cell in cells:
        stop = _stop_label(cell) if cell["ready"] else "결과 대기"
        map_rows.append(_map_row(cell["label"], cell.get("images") if cell["ready"] else None,
                                 run_id=cell["id"], weight=cell["weight"], stop=stop))
    metric_rows = "".join(_metric_row(cell) for cell in cells)
    return (
        f'<section class="sample" id="{section_id}" data-sample="{short}">'
        f'<h2>Sample {short}</h2><p class="sample-id">{sample_name}</p>'
        '<fieldset class="condition-controls"><legend>표시할 조건</legend>'
        + "".join(controls)
        + '</fieldset><div class="table-scroll"><table class="map-table"><caption>재질 맵과 중앙 렌더링 비교</caption>'
        '<colgroup><col class="condition-col"><col class="lambda-col"><col class="stop-col"><col span="7"></colgroup>'
        '<thead><tr><th>조건</th><th>λ</th><th>Step - 판정</th><th>Normal</th><th>Diffuse</th>'
        '<th>Roughness</th><th>F₀</th><th>Render</th><th>ΔE00 · render / I<sub>N</sub></th><th>I<sub>N</sub></th></tr></thead>'
        f'<tbody>{"".join(map_rows)}</tbody></table></div>'
        f'<p class="display-note">ΔE00 · render / I<sub>N</sub>: CIEDE2000, 샘플 내 조건 공통 범위 0–{base_case["residual_scale"] if base_case else 0:.5g}; viridis, 각 영상에 단위·범위·클리핑 비율 범례. clip/gamma/노출 없는 선형 sRGB→XYZ D65→Lab(2°). P98가 max의 절반 미만이면 P98 표시 상한; 기존 수치·MSE 유지.</p>'
        '<div class="table-scroll"><table class="metric-table"><caption>조건별 지표</caption><thead><tr>'
        '<th>조건</th><th>λ</th><th>측정 MSE</th><th>보존 MSE</th>'
        '<th>Held-out MSE</th><th>Roughness σ</th><th>Step - 판정</th>'
        f'</tr></thead><tbody>{metric_rows}</tbody></table></div>'
        '</section>'
    )


def render_report(
    cells_by_sample: dict[str, list[dict[str, Any]]],
    *,
    pending_count: int = 0,
) -> str:
    sample_sections = []
    for sample, (short, _) in SAMPLES.items():
        sample_sections.append(_render_sample_section(sample, short, cells_by_sample[sample]))
    pending_note = (
        f'<p class="pending-note">{pending_count}개 조건은 결과 파일이 아직 없어 대기 중입니다. '
        '완료로 표시하거나 빈 이미지를 채우지 않았습니다.</p>'
        if pending_count
        else ""
    )
    style = """
<style>
:root{color-scheme:light;--ink:#202b36;--muted:#5d6873;--line:#d8dee4;--paper:#fff;--wash:#f4f6f8;--accent:#245c73}
*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:15px/1.55 Georgia,"Times New Roman",Batang,serif}
main{max-width:1800px;margin:auto;padding:38px clamp(16px,3vw,48px) 64px}h1{font-size:clamp(30px,4vw,48px);line-height:1.12;margin:8px 0 12px}
h2{font-size:28px;font-weight:500;margin:38px 0 2px}.sample-id,.muted,.display-note,.metric-note{color:var(--muted)}
.intro{max-width:1000px}.intro p{margin:8px 0}.sample{border-top:2px solid var(--ink);margin-top:44px;padding-top:8px}
.condition-controls{border:1px solid var(--line);border-radius:8px;padding:12px 16px;margin:20px 0 16px;display:flex;flex-wrap:wrap;gap:10px 22px}
.condition-controls legend{padding:0 6px;font-size:14px;color:var(--muted)}.condition-controls label{display:flex;align-items:center;gap:7px;cursor:pointer}
input[type=checkbox]{accent-color:var(--accent);width:17px;height:17px}.table-scroll{overflow-x:auto;margin:12px 0 8px}
table{border-collapse:collapse;width:100%;min-width:980px;font-variant-numeric:tabular-nums}caption{text-align:left;font-size:19px;padding:10px 0}
table.map-table{table-layout:fixed;min-width:1540px}.map-table col.condition-col{width:180px}.map-table col.lambda-col{width:64px}.map-table col.stop-col{width:150px}
th,td{text-align:left;vertical-align:top;border-bottom:1px solid var(--line);padding:9px 8px}
thead th{position:sticky;top:0;background:var(--wash);font-weight:600;z-index:1}
.map-table img{display:block;width:100%;height:auto;object-fit:contain;background:#eef1f3;border:1px solid #e3e7ea}
.map-row>th{font-weight:600}.lambda,.stop{white-space:nowrap}.pending{display:grid;place-items:center;min-height:128px;border:1px dashed #a9b2ba;border-radius:4px;color:var(--muted);background:#fafbfc}
.pending-note{padding:12px;background:#fff7e6;border-left:3px solid #bb7b19}.display-note,.metric-note{font-size:13px;max-width:1100px}
.metric-table{min-width:980px}.metric-table th{font-weight:600}.provenance{margin:18px 0;border-top:1px solid var(--line);padding-top:12px}
.provenance summary{cursor:pointer;font-weight:600}.provenance li{margin:8px 0;overflow-wrap:anywhere}footer{margin-top:50px;padding-top:14px;border-top:1px solid var(--line);color:var(--muted);font-size:13px}
@media(max-width:700px){main{padding:24px 12px 40px}.condition-controls{gap:10px}h2{font-size:24px}}
@media print{main{max-width:none;padding:12mm}.condition-controls{display:none}.table-scroll{overflow:visible}table{min-width:0}table.map-table{min-width:0}.map-table img{max-width:120px}.sample{break-before:page}}
</style>
"""
    script = """
<script>
function setVariantVisible(id, visible) {
  document.querySelectorAll("[data-run-id]").forEach((row) => {
    if (row.dataset.runId === id) row.hidden = !visible;
  });
}
window.setVariantVisible = setVariantVisible;
document.querySelectorAll("[data-run-toggle]").forEach((control) => {
  control.addEventListener("change", () => setVariantVisible(control.dataset.runToggle, control.checked));
});
</script>
"""
    return (
        '<!doctype html><html lang="ko"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<title>Constant · λ 비교 · 478 / 078</title>'
        + style
        + '</head><body><main><header class="intro"><p class="muted">FP32 · 고정 F₀=0.04 · sample 478 / 078</p>'
        '<h1>Constant · λ 비교</h1>'
        '<p>478: diffuse / diffuse + roughness constant. 078: normal / normal + roughness constant.</p>'
        '<details><summary>설정·표시</summary><p>FP32 · q 고정 · Adam 0.01 · seed 0 · 최대 10,000 step. '
        'Loss = 측정 MSE + λ × 40방향 보존 MSE. 수렴은 기존 안정화 기준 충족을 뜻합니다.</p>'
        '<p>Normal=(n+1)/2, diffuse·F₀·render·I_N은 gamma 1/2.2, roughness는 linear [0,1]. '
        'F₀=0.04는 최적화 행에 적용합니다. render − I_N은 clip 전 linear RGB 차이입니다.</p>'
        '<p>Held-out은 원본 가상 응답과의 비교입니다. Roughness σ는 설명용이며 정답·물리적 정확도 판정이 아닙니다. '
        'λ가 다른 total objective는 순위 비교하지 않습니다.</p></details></header>'
        + pending_note
        + "".join(sample_sections)
        + script
        + '</main></body></html>'
    )


def build_summary(root: Path = DEFAULT_ROOT, output: Path | None = None, repo_root: Path = REPO_ROOT) -> dict[str, Any]:
    root = Path(root)
    output = Path(output) if output is not None else root / "summary.html"
    plan = _read_json(root / "experiment_plan.json")
    reused = _reuse_paths(plan, Path(repo_root))
    discovered = _new_run_paths(root)
    cache: dict[tuple[Path, Any], str] = {}
    cells_by_sample: dict[str, list[dict[str, Any]]] = {}
    pending = 0
    for sample, (short, constant_sets) in SAMPLES.items():
        cells = []
        for preservation_weight in LAMBDAS:
            for constants in constant_sets:
                key = (sample, constants, preservation_weight)
                base = reused.get(key) or discovered.get(key)
                cell = _load_cell(sample, constants, preservation_weight, base, short, cache)
                cells.append(cell)
                pending += not cell["ready"]
        _add_residual_images(cells)
        cells_by_sample[sample] = cells
    html_text = render_report(cells_by_sample, pending_count=pending)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(html_text, encoding="utf-8")
    return {"path": output, "complete_cells": 8 - pending, "pending_cells": pending}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=DEFAULT_ROOT)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = build_summary(args.root, args.output)
    print(f"{result['path']} · complete {result['complete_cells']}/8 · pending {result['pending_cells']}/8")


if __name__ == "__main__":
    main()
