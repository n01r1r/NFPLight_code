"""Fixed measured-chromaticity cues for normal and roughness refinement."""

from __future__ import annotations

from dataclasses import dataclass

import torch
import torch.nn.functional as F


@dataclass(frozen=True)
class ColorCueContext:
    chromaticity: torch.Tensor
    roughness_chromaticity: torch.Tensor
    initial_normal: torch.Tensor
    initial_roughness: torch.Tensor
    initial_normal_detail: torch.Tensor
    normal_scale: torch.Tensor
    roughness_scale: torch.Tensor
    detail_scale: torch.Tensor
    normal_active: bool
    roughness_active: bool
    detail_active: bool
    lowpass_kernel: int
    roughness_lowpass_kernel: int
    local_kernel: int
    dark_fraction: float
    saturated_fraction: float
    normal_cue_kernels: tuple[int, ...] | None = None
    roughness_cue_kernels: tuple[int, ...] | None = None
    normal_cue_chromaticities: tuple[torch.Tensor, ...] = ()
    roughness_cue_chromaticities: tuple[torch.Tensor, ...] = ()
    initial_normal_cue_maps: tuple[torch.Tensor, ...] = ()
    initial_roughness_cue_maps: tuple[torch.Tensor, ...] = ()
    normal_cue_scales: tuple[torch.Tensor, ...] = ()
    roughness_cue_scales: tuple[torch.Tensor, ...] = ()
    normal_cue_band_active: tuple[bool, ...] = ()
    roughness_cue_band_active: tuple[bool, ...] = ()


def _validate_kernel(value: int, name: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 1 or value % 2 == 0:
        raise ValueError(f"{name} must be a positive odd integer")


def _validate_kernels(values: tuple[int, ...] | list[int], name: str) -> tuple[int, ...]:
    if not isinstance(values, (tuple, list)) or not values:
        raise ValueError(f"{name} must be a nonempty list or tuple")
    kernels = tuple(values)
    for value in kernels:
        _validate_kernel(value, name)
    if len(set(kernels)) != len(kernels):
        raise ValueError(f"{name} must contain unique kernels")
    return kernels


def _pool(value: torch.Tensor, kernel: int) -> torch.Tensor:
    if kernel == 1:
        return value
    pad = kernel // 2
    if pad >= min(value.shape[-2:]):
        raise ValueError("reflect padding requires kernel radius smaller than image dimensions")
    return F.avg_pool2d(F.pad(value, (pad, pad, pad, pad), mode="reflect"), kernel, stride=1)


def _validate_maps(normal: torch.Tensor, roughness: torch.Tensor, *, name: str) -> None:
    if normal.dtype != torch.float32 or roughness.dtype != torch.float32:
        raise TypeError(f"{name} maps must be FP32")
    if normal.ndim != 4 or normal.shape[1] != 3:
        raise ValueError(f"{name} normal must have shape [B,3,H,W]")
    if roughness.shape != (normal.shape[0], 1, *normal.shape[-2:]):
        raise ValueError(f"{name} roughness must match normal spatial shape with one channel")
    if normal.device != roughness.device:
        raise ValueError(f"{name} maps must be on the same device")
    if not torch.isfinite(normal).all() or not torch.isfinite(roughness).all():
        raise ValueError(f"{name} maps must be finite")
    norm = torch.linalg.vector_norm(normal, dim=1)
    if ((norm - 1.0).abs() > 1e-3).any():
        raise ValueError(f"{name} normal must be unit length")
    if (roughness < 0.05).any() or (roughness > 1.0).any():
        raise ValueError(f"{name} roughness must be in [0.05,1]")


def _cue_energy(chromaticity: torch.Tensor, value: torch.Tensor, kernel: int) -> torch.Tensor:
    # Covariance is unchanged by constant offsets; centering reduces FP32 cancellation.
    chromaticity = chromaticity - chromaticity.mean(dim=(-2, -1), keepdim=True)
    value = value - value.mean(dim=(-2, -1), keepdim=True)
    batch, color_channels, height, width = chromaticity.shape
    map_channels = value.shape[1]
    product = (chromaticity.unsqueeze(2) * value.unsqueeze(1)).reshape(
        batch, color_channels * map_channels, height, width
    )
    covariance = _pool(product, kernel).reshape(batch, color_channels, map_channels, height, width)
    mean_color = _pool(chromaticity, kernel)
    mean_value = _pool(value, kernel)
    covariance = covariance - mean_color.unsqueeze(2) * mean_value.unsqueeze(1)
    variance = (_pool(chromaticity.square(), kernel) - mean_color.square()).clamp_min(0.0)
    return (covariance.square() / (variance.unsqueeze(2) + 1e-6)).mean()


def build_color_cue_context(
    initial_normal: torch.Tensor,
    initial_roughness: torch.Tensor,
    measured_target: torch.Tensor,
    *,
    lowpass_kernel: int = 9,
    roughness_lowpass_kernel: int | None = None,
    local_kernel: int = 31,
    normal_cue_kernels: tuple[int, ...] | list[int] | None = None,
    roughness_cue_kernels: tuple[int, ...] | list[int] | None = None,
) -> ColorCueContext:
    """Freeze measured chromaticity and initial scales for one FP32 optimization."""
    _validate_kernel(lowpass_kernel, "lowpass_kernel")
    if roughness_lowpass_kernel is None:
        roughness_lowpass_kernel = lowpass_kernel
    _validate_kernel(roughness_lowpass_kernel, "roughness_lowpass_kernel")
    _validate_kernel(local_kernel, "local_kernel")
    if (normal_cue_kernels is None) != (roughness_cue_kernels is None):
        raise ValueError("normal_cue_kernels and roughness_cue_kernels must be provided together")
    if normal_cue_kernels is not None:
        normal_cue_kernels = _validate_kernels(normal_cue_kernels, "normal_cue_kernels")
        roughness_cue_kernels = _validate_kernels(roughness_cue_kernels, "roughness_cue_kernels")
    _validate_maps(initial_normal, initial_roughness, name="initial")
    if measured_target.dtype != torch.float32:
        raise TypeError("measured_target must be FP32")
    if measured_target.shape != (initial_normal.shape[0], 3, *initial_normal.shape[-2:]):
        raise ValueError("measured_target must match normal shape with three channels")
    if initial_normal.device != measured_target.device:
        raise ValueError("color cue inputs must be on the same device")
    if not torch.isfinite(measured_target).all():
        raise ValueError("color cue inputs must be finite")
    if (measured_target < 0).any():
        raise ValueError("measured_target must be nonnegative")
    all_kernels = [lowpass_kernel, roughness_lowpass_kernel, local_kernel]
    if normal_cue_kernels is not None:
        all_kernels.extend(normal_cue_kernels)
        all_kernels.extend(roughness_cue_kernels)
    if any(kernel // 2 >= min(initial_normal.shape[-2:]) for kernel in all_kernels):
        raise ValueError("reflect padding requires kernel radius smaller than image dimensions")

    dark_fraction = float((measured_target.detach().sum(dim=1) < 1e-4).float().mean())
    if 0.0 < dark_fraction < 1.0:
        raise ValueError("partially dark chromaticity unsupported")
    if dark_fraction == 1.0:
        chromaticity = torch.zeros_like(measured_target)
    else:
        chromaticity = measured_target.detach() / measured_target.detach().sum(dim=1, keepdim=True).clamp_min(1e-4)
    chromaticity = _pool(chromaticity, lowpass_kernel)
    roughness_chromaticity = (
        chromaticity
        if roughness_lowpass_kernel == lowpass_kernel
        else _pool(
            measured_target.detach() / measured_target.detach().sum(dim=1, keepdim=True).clamp_min(1e-4),
            roughness_lowpass_kernel,
        )
    )
    if dark_fraction == 1.0:
        roughness_chromaticity = torch.zeros_like(measured_target)
    normal_low = _pool(initial_normal.detach(), lowpass_kernel)
    roughness_low = _pool(initial_roughness.detach(), roughness_lowpass_kernel)
    initial_detail = initial_normal.detach() - normal_low
    normal_scale = _cue_energy(chromaticity, normal_low, local_kernel).detach()
    roughness_scale = _cue_energy(roughness_chromaticity, roughness_low, local_kernel).detach()
    detail_scale = initial_detail.square().mean().detach()
    normal_cue_chromaticities = ()
    roughness_cue_chromaticities = ()
    initial_normal_cue_maps = ()
    initial_roughness_cue_maps = ()
    normal_cue_scales = ()
    roughness_cue_scales = ()
    normal_cue_band_active = ()
    roughness_cue_band_active = ()
    if normal_cue_kernels is not None:
        normal_cue_chromaticities = tuple(_pool(
            torch.zeros_like(measured_target) if dark_fraction == 1.0 else measured_target.detach() / measured_target.detach().sum(dim=1, keepdim=True).clamp_min(1e-4),
            kernel,
        ) for kernel in normal_cue_kernels)
        roughness_cue_chromaticities = tuple(_pool(
            torch.zeros_like(measured_target) if dark_fraction == 1.0 else measured_target.detach() / measured_target.detach().sum(dim=1, keepdim=True).clamp_min(1e-4),
            kernel,
        ) for kernel in roughness_cue_kernels)
        initial_normal_cue_maps = tuple(_pool(initial_normal.detach(), kernel) for kernel in normal_cue_kernels)
        initial_roughness_cue_maps = tuple(_pool(initial_roughness.detach(), kernel) for kernel in roughness_cue_kernels)
        normal_cue_scales = tuple(
            _cue_energy(c, m, local_kernel).detach()
            for c, m in zip(normal_cue_chromaticities, initial_normal_cue_maps)
        )
        roughness_cue_scales = tuple(
            _cue_energy(c, m, local_kernel).detach()
            for c, m in zip(roughness_cue_chromaticities, initial_roughness_cue_maps)
        )
        normal_cue_band_active = tuple(bool(scale >= 1e-8) for scale in normal_cue_scales)
        roughness_cue_band_active = tuple(bool(scale >= 1e-8) for scale in roughness_cue_scales)
    return ColorCueContext(
        chromaticity=chromaticity,
        roughness_chromaticity=roughness_chromaticity,
        initial_normal=normal_low,
        initial_roughness=roughness_low,
        initial_normal_detail=initial_detail,
        normal_scale=normal_scale,
        roughness_scale=roughness_scale,
        detail_scale=detail_scale,
        normal_active=(any(normal_cue_band_active) if normal_cue_kernels is not None else bool(normal_scale >= 1e-8)),
        roughness_active=(any(roughness_cue_band_active) if roughness_cue_kernels is not None else bool(roughness_scale >= 1e-8)),
        detail_active=bool(detail_scale >= 1e-8),
        lowpass_kernel=lowpass_kernel,
        roughness_lowpass_kernel=roughness_lowpass_kernel,
        local_kernel=local_kernel,
        dark_fraction=dark_fraction,
        saturated_fraction=float((measured_target.detach().amax(dim=1) >= 1.0).float().mean()),
        normal_cue_kernels=normal_cue_kernels,
        roughness_cue_kernels=roughness_cue_kernels,
        normal_cue_chromaticities=normal_cue_chromaticities,
        roughness_cue_chromaticities=roughness_cue_chromaticities,
        initial_normal_cue_maps=initial_normal_cue_maps,
        initial_roughness_cue_maps=initial_roughness_cue_maps,
        normal_cue_scales=normal_cue_scales,
        roughness_cue_scales=roughness_cue_scales,
        normal_cue_band_active=normal_cue_band_active,
        roughness_cue_band_active=roughness_cue_band_active,
    )


def evaluate_color_cue(
    normal: torch.Tensor,
    roughness: torch.Tensor,
    context: ColorCueContext,
) -> dict[str, torch.Tensor | bool]:
    """Return normalized covariance cue and phase-sensitive normal-detail loss."""
    _validate_maps(normal, roughness, name="current")
    if normal.shape != context.initial_normal.shape:
        raise ValueError("current maps must match cue context shape")
    if normal.device != context.chromaticity.device:
        raise ValueError("current maps must match cue context device")
    normal_low = _pool(normal, context.lowpass_kernel)
    roughness_low = _pool(roughness, context.roughness_lowpass_kernel)
    if context.normal_cue_kernels is None:
        normal_raw = _cue_energy(context.chromaticity, normal_low, context.local_kernel)
        roughness_raw = _cue_energy(context.roughness_chromaticity, roughness_low, context.local_kernel)
        active = []
        if context.normal_active:
            active.append(normal_raw / context.normal_scale)
        if context.roughness_active:
            active.append(roughness_raw / context.roughness_scale)
        cue_loss = torch.stack(active).mean() if active else normal_raw * 0.0
        band_results = {}
    else:
        normal_band_raw = tuple(
            _cue_energy(chroma, _pool(normal, kernel), context.local_kernel)
            for kernel, chroma in zip(context.normal_cue_kernels, context.normal_cue_chromaticities)
        )
        roughness_band_raw = tuple(
            _cue_energy(chroma, _pool(roughness, kernel), context.local_kernel)
            for kernel, chroma in zip(context.roughness_cue_kernels, context.roughness_cue_chromaticities)
        )
        normal_band_normalized = tuple(
            raw / scale if active else raw * 0.0
            for raw, scale, active in zip(normal_band_raw, context.normal_cue_scales, context.normal_cue_band_active)
        )
        roughness_band_normalized = tuple(
            raw / scale if active else raw * 0.0
            for raw, scale, active in zip(roughness_band_raw, context.roughness_cue_scales, context.roughness_cue_band_active)
        )
        components = []
        if any(context.normal_cue_band_active):
            components.append(torch.stack([
                value for value, active in zip(normal_band_normalized, context.normal_cue_band_active) if active
            ]).mean())
        if any(context.roughness_cue_band_active):
            components.append(torch.stack([
                value for value, active in zip(roughness_band_normalized, context.roughness_cue_band_active) if active
            ]).mean())
        normal_raw = torch.stack(normal_band_raw).mean()
        roughness_raw = torch.stack(roughness_band_raw).mean()
        cue_loss = torch.stack(components).mean() if components else normal_raw * 0.0
        band_results = {
            "normal_cue_kernels": context.normal_cue_kernels,
            "normal_cue_band_raw": normal_band_raw,
            "normal_cue_band_normalized": normal_band_normalized,
            "normal_cue_band_active": context.normal_cue_band_active,
            "roughness_cue_kernels": context.roughness_cue_kernels,
            "roughness_cue_band_raw": roughness_band_raw,
            "roughness_cue_band_normalized": roughness_band_normalized,
            "roughness_cue_band_active": context.roughness_cue_band_active,
        }
    detail = normal - _pool(normal, context.lowpass_kernel)
    detail_raw = (detail - context.initial_normal_detail).square().mean()
    detail_loss = detail_raw / context.detail_scale if context.detail_active else detail_raw * 0.0
    return {
        "cue_loss": cue_loss,
        "normal_cue_raw": normal_raw,
        "roughness_cue_raw": roughness_raw,
        "normal_detail_loss": detail_loss,
        "normal_detail_raw": detail_raw,
        "normal_active": context.normal_active,
        "roughness_active": context.roughness_active,
        "detail_active": context.detail_active,
    } | band_results


__all__ = ["ColorCueContext", "build_color_cue_context", "evaluate_color_cue"]
