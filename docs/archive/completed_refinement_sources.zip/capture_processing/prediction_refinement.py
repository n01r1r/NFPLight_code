"""Prediction-only fixed-F0 refinement for the original FP32 estimator output."""

from __future__ import annotations

from collections.abc import Callable
import math
from typing import Any

import torch
import torch.nn.functional as F


F0_PHYSICAL = 0.04
F0_RAW = 2.0 * F0_PHYSICAL - 1.0
DEFAULT_LAMP_INTENSITY = 16.0


def _check_prediction(prediction: torch.Tensor) -> None:
    if prediction.ndim != 4 or prediction.shape[1] != 10:
        raise ValueError(f"prediction must have shape [B,10,H,W], got {tuple(prediction.shape)}")
    if prediction.dtype != torch.float32:
        raise TypeError(f"prediction must be FP32, got {prediction.dtype}")
    if not torch.isfinite(prediction).all():
        raise ValueError("prediction contains non-finite values")


def fixed_specular_raw(prediction: torch.Tensor, physical_f0: float = F0_PHYSICAL) -> torch.Tensor:
    """Return immutable raw RGB specular channels for a physical F0."""
    _check_prediction(prediction)
    if not 0.0 <= physical_f0 <= 1.0:
        raise ValueError("physical F0 must be in [0,1]")
    return torch.full_like(prediction[:, 7:10], 2.0 * float(physical_f0) - 1.0)


def _logit_unit(value: torch.Tensor) -> torch.Tensor:
    return torch.logit(value.clamp(1e-4, 1.0 - 1e-4))


def _bounded_raw(value: torch.Tensor) -> torch.Tensor:
    """Map unconstrained values to raw [-1,1] with nonzero boundary gradients."""
    return value.sigmoid().mul(2.0).sub(1.0)


def _safe_normalize(normal: torch.Tensor) -> torch.Tensor:
    length = torch.linalg.vector_norm(normal, dim=1, keepdim=True)
    unit = normal / length.clamp_min(1e-8)
    fallback = torch.zeros_like(normal)
    fallback[:, 2:3] = 1.0
    return torch.where(length > 1e-8, unit, fallback)


def _raw_to_latent(prediction: torch.Tensor) -> torch.Tensor:
    return torch.cat((
        prediction[:, :3],
        _logit_unit((prediction[:, 3:6] + 1.0) * 0.5),
        _logit_unit(((prediction[:, 6:7] + 1.0) * 0.5 - 0.05) / 0.95),
    ), dim=1)


def _latent_to_prediction(latent: torch.Tensor, fixed_s: torch.Tensor) -> torch.Tensor:
    normal = _safe_normalize(latent[:, :3])
    diffuse = _bounded_raw(latent[:, 3:6])
    roughness = _bounded_raw(latent[:, 6:7].clamp(-20.0, 20.0))
    # The sigmoid parameterization keeps the effective roughness in [0.05, 1].
    roughness = 2.0 * (0.05 + 0.95 * ((roughness + 1.0) * 0.5)) - 1.0
    return torch.cat((normal, diffuse, roughness, fixed_s), dim=1)


def project_fixed_prediction(prediction: torch.Tensor, physical_f0: float = F0_PHYSICAL) -> torch.Tensor:
    """Project an estimator output to normalized n/d/r and fixed RGB F0."""
    _check_prediction(prediction)
    fixed_s = fixed_specular_raw(prediction, physical_f0)
    return _latent_to_prediction(_raw_to_latent(prediction), fixed_s)


def _validate_render(rendered: torch.Tensor, name: str) -> None:
    if rendered.ndim != 5 or rendered.shape[2] != 3:
        raise ValueError(f"{name} must have shape [B,L,3,H,W], got {tuple(rendered.shape)}")
    if rendered.dtype != torch.float32 or not torch.isfinite(rendered).all():
        raise ValueError(f"{name} must be finite FP32")


def estimate_lamp_intensity(
    unit_near: torch.Tensor,
    observed_near: torch.Tensor,
    valid_mask: torch.Tensor | None = None,
    *,
    default_intensity: float = DEFAULT_LAMP_INTENSITY,
) -> dict[str, float | int | str]:
    """Fit nonnegative scalar lamp intensity from scalar mean RGB per pixel.

    ``observed_near`` is used only for this brightness calibration. The fitted
    q minimizes ``sum((q*u - I_N)^2)`` on finite, unsaturated support, where
    both ``u`` and ``I_N`` are channel means at each pixel.
    """
    if unit_near.dtype != torch.float32 or observed_near.dtype != torch.float32:
        raise TypeError("lamp intensity inputs must be FP32")
    if unit_near.ndim != 4 or observed_near.ndim != 4 or unit_near.shape != observed_near.shape:
        raise ValueError("lamp intensity inputs must share [B,3,H,W] shape")
    if not torch.isfinite(unit_near).all() or not torch.isfinite(observed_near).all():
        raise ValueError("lamp intensity inputs contain non-finite values")
    if valid_mask is None:
        valid_mask = (observed_near.amax(dim=1) <= 0.95) & (unit_near.amax(dim=1) <= 0.95)
    if valid_mask.shape != observed_near.shape[:1] + observed_near.shape[2:]:
        raise ValueError("valid_mask must have shape [B,H,W]")
    valid = valid_mask.to(dtype=torch.bool) & torch.isfinite(unit_near.mean(dim=1))
    unit_scalar = unit_near.mean(dim=1)
    observed_scalar = observed_near.mean(dim=1)
    if not valid.any():
        raise ValueError("lamp intensity support is empty")
    u = unit_scalar[valid]
    target = observed_scalar[valid]
    denom = torch.sum(u * u)
    if not torch.isfinite(denom) or float(denom) <= 0.0:
        raise ValueError("unit near render has zero intensity on support")
    q = torch.clamp(torch.sum(u * target) / denom, min=0.0)
    default_rmse = torch.sqrt(torch.mean((float(default_intensity) * u - target) ** 2))
    fitted_rmse = torch.sqrt(torch.mean((q * u - target) ** 2))
    return {
        "method": "nonnegative_least_squares_scalar_mean_rgb",
        "q": float(q),
        "default_intensity": float(default_intensity),
        "default_rmse": float(default_rmse),
        "fitted_rmse": float(fitted_rmse),
        "support_pixels": int(valid.sum()),
        "observed_scalar_mean_rgb": float(target.mean()),
        "unit_scalar_mean_rgb": float(u.mean()),
    }


def refine_prediction(
    prediction: torch.Tensor,
    render_fn: Callable[[torch.Tensor, torch.Tensor, float], torch.Tensor],
    train_lights: torch.Tensor,
    *,
    lamp_intensity: float = DEFAULT_LAMP_INTENSITY,
    steps: int = 300,
    lr: float = 0.01,
    prior_weight: float = 1e-4,
    physical_f0: float = F0_PHYSICAL,
    seed: int = 0,
    heldout_lights: torch.Tensor | None = None,
) -> dict[str, Any]:
    """Fit n/d/r to detached multi-light renders of the original prediction."""
    _check_prediction(prediction)
    if train_lights.ndim != 2 or train_lights.shape[1] != 3:
        raise ValueError("train_lights must have shape [L,3]")
    if train_lights.dtype != torch.float32 or not torch.isfinite(train_lights).all():
        raise ValueError("train_lights must be finite FP32")
    if steps < 1 or lr <= 0.0 or prior_weight < 0.0 or lamp_intensity < 0.0:
        raise ValueError("steps, lr, prior_weight, and lamp_intensity are invalid")
    if not all(math.isfinite(float(value)) for value in (lamp_intensity, lr, prior_weight, physical_f0)):
        raise ValueError("refinement scalar controls must be finite")
    if heldout_lights is not None and (
        heldout_lights.ndim != 2 or heldout_lights.shape[1] != 3
        or heldout_lights.dtype != torch.float32 or not torch.isfinite(heldout_lights).all()
    ):
        raise ValueError("heldout_lights must be finite FP32 with shape [L,3]")
    torch.manual_seed(seed)
    teacher = render_fn(prediction, train_lights, float(lamp_intensity)).detach()
    _validate_render(teacher, "teacher render")
    initial_fixed = project_fixed_prediction(prediction, physical_f0)
    initial_render = render_fn(initial_fixed, train_lights, float(lamp_intensity))
    _validate_render(initial_render, "initial fixed render")
    latent = torch.nn.Parameter(_raw_to_latent(prediction).detach().clone())
    optimizer = torch.optim.Adam([latent], lr=lr)
    best_loss = float("inf")
    best_latent = latent.detach().clone()
    finite_gradient_steps = 0
    for _ in range(steps):
        material = _latent_to_prediction(latent, fixed_specular_raw(prediction, physical_f0))
        rendered = render_fn(material, train_lights, float(lamp_intensity))
        _validate_render(rendered, "student render")
        image_loss = F.mse_loss(rendered, teacher)
        prior = F.mse_loss(material[:, :7], initial_fixed[:, :7])
        total = image_loss + float(prior_weight) * prior
        if not torch.isfinite(total):
            raise FloatingPointError("refinement objective became non-finite")
        optimizer.zero_grad(set_to_none=True)
        total.backward()
        if latent.grad is None or not torch.isfinite(latent.grad).all():
            raise FloatingPointError("refinement gradient became non-finite")
        finite_gradient_steps += 1
        if float(total.detach()) < best_loss:
            best_loss = float(total.detach())
            best_latent = latent.detach().clone()
        optimizer.step()
    refined = _latent_to_prediction(best_latent, fixed_specular_raw(prediction, physical_f0)).detach()
    final_render = render_fn(refined, train_lights, float(lamp_intensity)).detach()
    _validate_render(final_render, "final render")
    result: dict[str, Any] = {
        "refined_prediction": refined,
        "initial_fixed_prediction": initial_fixed.detach(),
        "teacher_renders": teacher,
        "initial_render": initial_render.detach(),
        "final_render": final_render,
        "metrics": {
            "initial_teacher_mse": float(F.mse_loss(initial_render, teacher)),
            "final_teacher_mse": float(F.mse_loss(final_render, teacher)),
            "best_total_objective": float(best_loss),
            "steps": int(steps),
            "finite_gradient_steps": int(finite_gradient_steps),
            "f0_physical": float(physical_f0),
            "f0_raw": float(2.0 * physical_f0 - 1.0),
            "prior_weight": float(prior_weight),
            "seed": int(seed),
        },
    }
    if heldout_lights is not None:
        heldout_teacher = render_fn(prediction, heldout_lights, float(lamp_intensity)).detach()
        heldout_initial = render_fn(initial_fixed, heldout_lights, float(lamp_intensity)).detach()
        heldout_final = render_fn(refined, heldout_lights, float(lamp_intensity)).detach()
        _validate_render(heldout_teacher, "heldout teacher render")
        _validate_render(heldout_initial, "heldout initial render")
        _validate_render(heldout_final, "heldout final render")
        result["metrics"].update({
            "heldout_initial_teacher_mse": float(F.mse_loss(heldout_initial, heldout_teacher)),
            "heldout_final_teacher_mse": float(F.mse_loss(heldout_final, heldout_teacher)),
        })
    return result


__all__ = [
    "DEFAULT_LAMP_INTENSITY", "F0_PHYSICAL", "F0_RAW", "estimate_lamp_intensity",
    "fixed_specular_raw", "project_fixed_prediction", "refine_prediction",
]
