"""Rendering-loss diagnostics for original prediction versus fixed physical F0."""

from __future__ import annotations

import html
import math
import re
from pathlib import Path
from typing import Callable

import torch
import torch.nn.functional as F

from capture_processing.color_cue import build_color_cue_context, evaluate_color_cue


F0_PHYSICAL = 0.04
F0_RAW = 2.0 * F0_PHYSICAL - 1.0
CAMERA_XYZ = (0.0, 0.0, 4.0)
START_MARKER = "<!-- rendering-loss-analysis:start -->"
END_MARKER = "<!-- rendering-loss-analysis:end -->"


def build_light_regimes(device: torch.device | str) -> dict[str, torch.Tensor]:
    """Return centered, radius-.25, and radius-1.5 lights at z=4."""
    device = torch.device(device)

    def five(radius: float) -> torch.Tensor:
        return torch.tensor(
            [
                [0.0, 0.0, 4.0],
                [radius, 0.0, 4.0],
                [-radius, 0.0, 4.0],
                [0.0, radius, 4.0],
                [0.0, -radius, 4.0],
            ],
            dtype=torch.float32,
            device=device,
        )

    return {
        "center": torch.tensor([[0.0, 0.0, 4.0]], dtype=torch.float32, device=device),
        "small": five(0.25),
        "wide": five(1.5),
    }


def build_common_heldout_lights(device: torch.device | str) -> torch.Tensor:
    """Return eight diagonal z=4 lights at radii .75 and 1.25."""
    device = torch.device(device)
    values = []
    for radius in (0.75, 1.25):
        diagonal = radius / math.sqrt(2.0)
        values.extend(
            [
                [diagonal, diagonal, 4.0],
                [-diagonal, diagonal, 4.0],
                [-diagonal, -diagonal, 4.0],
                [diagonal, -diagonal, 4.0],
            ]
        )
    return torch.tensor(values, dtype=torch.float32, device=device)


def build_scan_lights(device: torch.device | str) -> dict[str, torch.Tensor]:
    """Return center and cardinal/diagonal scans for the four requested radii."""
    device = torch.device(device)
    result = {}
    for radius in (0.0, 0.25, 0.75, 1.5):
        points = [[0.0, 0.0, 4.0]]
        if radius:
            diagonal = radius / math.sqrt(2.0)
            points.extend(
                [
                    [radius, 0.0, 4.0],
                    [-radius, 0.0, 4.0],
                    [0.0, radius, 4.0],
                    [0.0, -radius, 4.0],
                    [diagonal, diagonal, 4.0],
                    [-diagonal, diagonal, 4.0],
                    [-diagonal, -diagonal, 4.0],
                    [diagonal, -diagonal, 4.0],
                ]
            )
        result[f"radius_{radius:g}"] = torch.tensor(points, dtype=torch.float32, device=device)
    return result


def _validate_prediction(prediction: torch.Tensor) -> None:
    if prediction.ndim != 4 or prediction.shape[1] != 10:
        raise ValueError(f"prediction must have shape [B,10,H,W], got {tuple(prediction.shape)}")
    if prediction.dtype != torch.float32:
        raise TypeError(f"prediction must be FP32, got {prediction.dtype}")
    if not torch.isfinite(prediction).all():
        raise ValueError("prediction contains non-finite values")
    normal_norm = torch.linalg.vector_norm(prediction[:, :3], dim=1)
    if (normal_norm <= 1e-8).any():
        raise ValueError("prediction contains a zero normal")
    for name, value in (
        ("diffuse", prediction[:, 3:6]),
        ("roughness", prediction[:, 6:7]),
        ("specular", prediction[:, 7:10]),
    ):
        if value.amin() < -1.00001 or value.amax() > 1.00001:
            raise ValueError(f"{name} raw values must be in [-1,1]")


def initial_material(prediction: torch.Tensor, mode: str) -> torch.Tensor:
    """Create render-equivalent direct raw maps for the free or fixed-F0 mode."""
    _validate_prediction(prediction)
    if mode not in {"free", "fixed"}:
        raise ValueError("mode must be free or fixed")
    material = prediction.detach().clone()
    if mode == "fixed":
        material[:, 6:7].clamp_(min=-0.9, max=1.0)
        material[:, 7:10] = F0_RAW
    return material


def physical_maps(material: torch.Tensor) -> dict[str, torch.Tensor]:
    """Decode renderer physical maps, including the renderer's roughness floor."""
    _validate_prediction(material)
    normal = material[:, :3] / torch.linalg.vector_norm(material[:, :3], dim=1, keepdim=True)
    return {
        "normal": normal,
        "diffuse": (material[:, 3:6] + 1.0) * 0.5,
        "roughness": ((material[:, 6:7] + 1.0) * 0.5).clamp(min=0.05, max=1.0),
        "specular": (material[:, 7:10] + 1.0) * 0.5,
    }


def _validate_lights(lights: torch.Tensor, name: str) -> None:
    if lights.ndim != 2 or lights.shape[0] == 0 or lights.shape[1] != 3 or lights.dtype != torch.float32:
        raise ValueError(f"{name} must have shape [L,3] FP32")
    if not torch.isfinite(lights).all():
        raise ValueError(f"{name} contains non-finite coordinates")


def _validate_render(rendered: torch.Tensor, name: str) -> None:
    if rendered.ndim != 5 or rendered.shape[2] != 3 or rendered.dtype != torch.float32:
        raise ValueError(f"{name} must have shape [B,L,3,H,W] FP32")
    if not torch.isfinite(rendered).all():
        raise ValueError(f"{name} contains non-finite values")


def _compose(parameters: dict[str, torch.Tensor]) -> torch.Tensor:
    height = max(value.shape[-2] for value in parameters.values())
    width = max(value.shape[-1] for value in parameters.values())
    return torch.cat([parameters[name].expand(-1, -1, height, width)
                      for name in ("n", "d", "r", "s")], dim=1)


def _project_parameters(parameters: dict[str, torch.Tensor], mode: str) -> None:
    with torch.no_grad():
        parameters["d"].clamp_(-1.0, 1.0)
        parameters["r"].clamp_(-0.9, 1.0)
        if mode == "free":
            parameters["s"].clamp_(-1.0, 1.0)
        else:
            parameters["s"].fill_(F0_RAW)
    _validate_prediction(_compose(parameters))


def _rms(value: torch.Tensor | None) -> float:
    if value is None:
        return 0.0
    return float(torch.sqrt(torch.mean(value.detach() * value.detach())))


def _mean_abs(value: torch.Tensor) -> float:
    return float(value.detach().abs().mean())


def _validate_cue_config(config: dict | None) -> dict | None:
    if config is None:
        return None
    if not isinstance(config, dict):
        raise TypeError("cue_config must be a dict or None")
    defaults = {
        "lowpass_kernel": 9,
        "roughness_lowpass_kernel": None,
        "local_kernel": 31,
        "cue_budget": 0.1,
        "detail_budget": 1.0,
    }
    band_names = {"normal_cue_kernels", "roughness_cue_kernels"}
    if set(config) - set(defaults) - band_names:
        raise ValueError("cue_config contains unsupported keys")
    values = defaults | config
    has_normal_bands = values.get("normal_cue_kernels") is not None
    has_roughness_bands = values.get("roughness_cue_kernels") is not None
    if has_normal_bands != has_roughness_bands:
        raise ValueError("normal_cue_kernels and roughness_cue_kernels must be provided together")
    if has_normal_bands:
        if config.get("roughness_lowpass_kernel") is not None:
            raise ValueError("roughness_lowpass_kernel cannot be combined with scale-space cue kernels")
        for name in ("normal_cue_kernels", "roughness_cue_kernels"):
            kernels = values[name]
            if not isinstance(kernels, (list, tuple)) or not kernels:
                raise ValueError(f"{name} must be a nonempty list or tuple")
            normalized = []
            for value in kernels:
                if isinstance(value, bool) or not isinstance(value, int) or value < 1 or value % 2 == 0:
                    raise ValueError(f"{name} must contain positive odd integers")
                normalized.append(value)
            if len(set(normalized)) != len(normalized):
                raise ValueError(f"{name} must contain unique kernels")
            values[name] = normalized
    for name in ("lowpass_kernel", "local_kernel"):
        value = values[name]
        if isinstance(value, bool) or not isinstance(value, int) or value < 1 or value % 2 == 0:
            raise ValueError(f"{name} must be a positive odd integer")
    if values["roughness_lowpass_kernel"] is None:
        values["roughness_lowpass_kernel"] = values["lowpass_kernel"]
    else:
        value = values["roughness_lowpass_kernel"]
        if isinstance(value, bool) or not isinstance(value, int) or value < 1 or value % 2 == 0:
            raise ValueError("roughness_lowpass_kernel must be None or a positive odd integer")
    for name in ("cue_budget", "detail_budget"):
        value = values[name]
        if isinstance(value, bool) or not math.isfinite(float(value)) or float(value) < 0:
            raise ValueError(f"{name} must be finite and nonnegative")
        values[name] = float(value)
    return values


def _map_metrics(current: torch.Tensor, original: torch.Tensor) -> dict[str, float]:
    current_maps = physical_maps(current)
    original_maps = physical_maps(original)
    result = {name: _mean_abs(current_maps[name] - original_maps[name]) for name in current_maps}
    current_normal = current_maps["normal"]
    original_normal = original_maps["normal"]
    dot = (current_normal * original_normal).sum(dim=1)
    cross_norm = torch.linalg.vector_norm(torch.cross(current_normal, original_normal, dim=1), dim=1)
    result["normal_angular_mean_deg"] = float(torch.rad2deg(torch.atan2(cross_norm, dot)).mean())
    return result


def _update_metrics(after: dict[str, torch.Tensor], before: dict[str, torch.Tensor]) -> dict[str, float]:
    return {name: _mean_abs(after[name] - before[name]) for name in ("n", "d", "r", "s")}


def analyze_condition(
    prediction: torch.Tensor,
    render_fn: Callable[[torch.Tensor, torch.Tensor, float], torch.Tensor],
    train_lights: torch.Tensor,
    common_lights: torch.Tensor,
    lamp_intensity: float,
    *,
    mode: str,
    regime: str,
    steps: int = 300,
    lr: float = 0.01,
    seed: int = 0,
    stability: bool = False,
    snapshot_callback: Callable | None = None,
    light_chunk_size: int | None = None,
    measured_target: torch.Tensor | None = None,
    measured_light: torch.Tensor | None = None,
    preservation_weight: float = 1.0,
    resume_state: dict | None = None,
    spatial_constants: tuple[str, ...] = (),
    cue_config: dict | None = None,
) -> dict:
    """Optimize rendering MSE, optionally with measured RGB and an absolute-step Adam resume.

    Without measurement options the original teacher-only objective is unchanged.
    ``steps`` is the absolute update limit; resumed stability windows restart.
    """
    _validate_prediction(prediction)
    cue_settings = _validate_cue_config(cue_config)
    if resume_state is not None and "cue_contract" in resume_state:
        raise ValueError("cue checkpoint resume is unsupported")
    if len(set(spatial_constants)) != len(spatial_constants) or any(
        name not in {"n", "d", "r"} for name in spatial_constants
    ):
        raise ValueError('spatial_constants must contain unique n/d/r names')
    if spatial_constants and resume_state is not None:
        raise ValueError('constrained optimization requires a fresh optimizer')
    _validate_lights(train_lights, "train_lights")
    _validate_lights(common_lights, "common_lights")
    if mode not in {"free", "fixed"} or not regime:
        raise ValueError("mode and regime are required")
    if cue_settings is not None:
        if mode != "fixed":
            raise ValueError("color cue requires fixed-F0 mode")
        if spatial_constants:
            raise ValueError("color cue cannot be combined with spatial_constants")
        if resume_state is not None:
            raise ValueError("color cue requires a fresh optimizer")
    if steps < 1 or lr <= 0.0 or lamp_intensity < 0.0:
        raise ValueError("steps, lr, and lamp_intensity must be positive")
    if not all(math.isfinite(float(v)) for v in (lr, lamp_intensity)):
        raise ValueError("analysis controls must be finite")
    if light_chunk_size is not None and light_chunk_size < 1:
        raise ValueError('light_chunk_size must be positive')
    measurement_enabled = measured_target is not None
    if measurement_enabled:
        if measured_light is None:
            raise ValueError('measured_light is required with measured_target')
        _validate_lights(measured_light, 'measured light')
        if measured_light.shape != (1, 3):
            raise ValueError('measurement requires one light')
        if measured_target.shape != (prediction.shape[0], 3, *prediction.shape[-2:]):
            raise ValueError('measured target must match prediction RGB spatial shape')
        if measured_target.dtype != torch.float32 or measured_target.device != prediction.device:
            raise ValueError('measured target must be FP32 on prediction device')
        if not torch.isfinite(measured_target).all():
            raise ValueError('measured target must be finite')
        if not math.isfinite(preservation_weight) or preservation_weight < 0:
            raise ValueError('preservation weight must be finite and nonnegative')
        measured_target = measured_target.detach()
    elif measured_light is not None or preservation_weight != 1.0:
        raise ValueError('measurement options require measured_target')
    if cue_settings is not None and not measurement_enabled:
        raise ValueError("color cue requires measured_target")
    torch.manual_seed(seed)
    initial = initial_material(prediction, mode)
    start_step = 0
    if resume_state is not None:
        start_step = int(resume_state['step'])
        if not 0 <= start_step < steps:
            raise ValueError('resume step must be below absolute maximum steps')
        initial = resume_state['material'].detach().clone().to(prediction.device)
        _validate_prediction(initial)
        if initial.shape != prediction.shape or initial.dtype != torch.float32:
            raise ValueError('resume material must match FP32 prediction shape')
        if mode == 'fixed' and not torch.equal(initial[:,7:], torch.full_like(initial[:,7:], F0_RAW)):
            raise ValueError('resume material violates fixed F0')
    with torch.no_grad():
        teacher_train = render_fn(prediction, train_lights, float(lamp_intensity)).detach()
        teacher_common = render_fn(prediction, common_lights, float(lamp_intensity)).detach()
    _validate_render(teacher_train, "teacher train render")
    _validate_render(teacher_common, "teacher common render")
    parameters = {
        name: torch.nn.Parameter(initial[:, sl].detach().clone())
        for name, sl in (
            ("n", slice(0, 3)),
            ("d", slice(3, 6)),
            ("r", slice(6, 7)),
            ("s", slice(7, 10)),
        )
    }
    for name in spatial_constants:
        value = parameters[name].detach()
        if name == 'n':
            value = F.normalize(value, dim=1)
        value = value.mean(dim=(-2, -1), keepdim=True)
        if name == 'n':
            if (torch.linalg.vector_norm(value, dim=1) <= 1e-8).any():
                raise ValueError('mean normal is undefined')
            value = F.normalize(value, dim=1)
        parameters[name] = torch.nn.Parameter(value.clone())
    initial = _compose(parameters).detach().clone()
    if mode == "fixed":
        parameters["s"].requires_grad_(False)
    cue_context = None
    cue_reference_mse = None
    cue_contract = None
    if cue_settings is not None:
        multiscale = "normal_cue_kernels" in cue_settings
        roughness_kernel_source = (
            "roughness_cue_kernels" if multiscale else
            "explicit" if cue_config.get("roughness_lowpass_kernel") is not None else
            "inherits_lowpass_kernel"
        )
        initial_maps = physical_maps(initial)
        cue_context = build_color_cue_context(
            initial_maps["normal"], initial_maps["roughness"], measured_target,
            lowpass_kernel=cue_settings["lowpass_kernel"],
            roughness_lowpass_kernel=cue_settings["roughness_lowpass_kernel"],
            local_kernel=cue_settings["local_kernel"],
            normal_cue_kernels=(tuple(cue_settings["normal_cue_kernels"]) if multiscale else None),
            roughness_cue_kernels=(tuple(cue_settings["roughness_cue_kernels"]) if multiscale else None),
        )
        with torch.no_grad():
            initial_measured = render_fn(initial, measured_light, float(lamp_intensity))
            _validate_render(initial_measured, "initial measured render")
            cue_reference_mse = F.mse_loss(initial_measured[:, 0], measured_target).detach()
        cue_contract = {
            "version": 1,
            "config": dict(cue_settings),
            "roughness_lowpass_kernel_source": roughness_kernel_source,
            "reference_measured_mse": float(cue_reference_mse),
            "normal_initial_cue": float(cue_context.normal_scale),
            "roughness_initial_cue": float(cue_context.roughness_scale),
            "normal_detail_initial_energy": float(cue_context.detail_scale),
            "normal_active": cue_context.normal_active,
            "roughness_active": cue_context.roughness_active,
            "detail_active": cue_context.detail_active,
            "dark_fraction": cue_context.dark_fraction,
            "saturated_fraction": cue_context.saturated_fraction,
            "variance_epsilon": 1e-6,
            "activity_threshold": 1e-8,
        }
        if cue_context.normal_cue_kernels is not None:
            cue_contract["normal_cue_bands_initial"] = {
                str(kernel): {"raw": float(scale), "active": active}
                for kernel, scale, active in zip(
                    cue_context.normal_cue_kernels,
                    cue_context.normal_cue_scales,
                    cue_context.normal_cue_band_active,
                )
            }
            cue_contract["roughness_cue_bands_initial"] = {
                str(kernel): {"raw": float(scale), "active": active}
                for kernel, scale, active in zip(
                    cue_context.roughness_cue_kernels,
                    cue_context.roughness_cue_scales,
                    cue_context.roughness_cue_band_active,
                )
            }
    optimized = [
        parameters[name]
        for name in ("n", "d", "r", "s")
        if mode == "free" or name != "s"
    ]
    optimizer = torch.optim.Adam(optimized, lr=lr)
    if resume_state is not None:
        optimizer.load_state_dict(resume_state['optimizer_state'])
        if any(group['lr'] != lr for group in optimizer.param_groups):
            raise ValueError('resume learning rate differs')
    trajectory = []
    best_loss = float("inf")
    best_step = start_step
    best_state = initial.detach().clone()
    previous_update = {name: 0.0 for name in ("n", "d", "r", "s")}
    if resume_state is not None:
        previous_update = dict(resume_state['previous_update'])
    stable = False
    window_reference = None
    for step in range(start_step, steps + 1):
        optimizer.zero_grad(set_to_none=True)
        current = _compose(parameters)
        chunk_size = light_chunk_size or len(train_lights)
        train_loss = torch.zeros((), device=current.device)
        per_light_loss = []
        preservation_loss = torch.zeros((), device=current.device)
        for start in range(0, len(train_lights), chunk_size):
            stop = min(start + chunk_size, len(train_lights))
            # Recompose to release each chunk's graph before rendering the next.
            train_render = render_fn(_compose(parameters), train_lights[start:stop], float(lamp_intensity))
            _validate_render(train_render, 'student train render')
            difference = (train_render - teacher_train[:, start:stop]).square()
            local = difference.mean() * ((stop-start) / len(train_lights))
            if not torch.isfinite(local):
                raise FloatingPointError('rendering loss is non-finite')
            preservation_loss += local.detach()
            weighted_local = local * (preservation_weight if measurement_enabled else 1.0)
            weighted_local.backward()
            train_loss += weighted_local.detach()
            per_light_loss.extend(difference.detach().mean(dim=(0,2,3,4)).cpu().tolist())
            del train_render, difference, local
        if measurement_enabled:
            measured_render = render_fn(_compose(parameters), measured_light, float(lamp_intensity))[:, 0]
            measured_loss = F.mse_loss(measured_render, measured_target)
            if not torch.isfinite(measured_loss):
                raise FloatingPointError('measurement loss is non-finite')
            measured_loss.backward()
            train_loss += measured_loss.detach()
            del measured_render
        cue_terms = None
        if cue_context is not None:
            current_maps = physical_maps(_compose(parameters))
            cue_terms = evaluate_color_cue(current_maps["normal"], current_maps["roughness"], cue_context)
            cue_penalty = cue_reference_mse * (
                cue_settings["cue_budget"] * cue_terms["cue_loss"]
                + cue_settings["detail_budget"] * cue_terms["normal_detail_loss"]
            )
            if not torch.isfinite(cue_penalty):
                raise FloatingPointError("color cue loss is non-finite")
            cue_penalty.backward()
            train_loss += cue_penalty.detach()
        with torch.no_grad():
            common_render = render_fn(current.detach(), common_lights, float(lamp_intensity))
            _validate_render(common_render, "student common render")
            common_loss = F.mse_loss(common_render, teacher_common)
            common_per_light = (common_render-teacher_common).square().mean(dim=(0,2,3,4)).cpu().tolist()
            map_metrics = _map_metrics(current.detach(), prediction)
        gradients = {
            name: _rms(parameters[name].grad) if mode == "free" or name != "s" else 0.0
            for name in ("n", "d", "r", "s")
        }
        if any(not math.isfinite(value) for value in gradients.values()):
            raise FloatingPointError("rendering gradient is non-finite")
        entry = {
            "step": int(step),
            "phase": "initial" if step == 0 else "post_update",
            "train_mse": float(train_loss.detach()),
            "train_mse_per_light": per_light_loss,
            "common_heldout_mse": float(common_loss.detach()),
            "common_mse_per_light": common_per_light,
            "map_mae_physical": map_metrics,
            "gradient_rms_raw": gradients,
            "update_mean_abs_raw": previous_update,
        }
        if measurement_enabled:
            entry.update(measured_mse=float(measured_loss.detach()),
                         preservation_mse=float(preservation_loss),
                         weighted_preservation_mse=float(preservation_loss)*preservation_weight,
                         total_loss=float(train_loss))
        if cue_terms is not None:
            cue_weighted = cue_reference_mse * cue_settings["cue_budget"] * cue_terms["cue_loss"]
            detail_weighted = cue_reference_mse * cue_settings["detail_budget"] * cue_terms["normal_detail_loss"]
            entry.update(
                cue_loss=float(cue_terms["cue_loss"].detach()),
                normal_cue_raw=float(cue_terms["normal_cue_raw"].detach()),
                roughness_cue_raw=float(cue_terms["roughness_cue_raw"].detach()),
                normal_detail_loss=float(cue_terms["normal_detail_loss"].detach()),
                normal_detail_raw=float(cue_terms["normal_detail_raw"].detach()),
                weighted_cue_loss=float(cue_weighted.detach()),
                weighted_normal_detail_loss=float(detail_weighted.detach()),
            )
            if "normal_cue_band_raw" in cue_terms:
                entry["normal_cue_bands"] = {
                    str(kernel): {"raw": float(raw.detach()), "normalized": float(normalized.detach()), "active": active}
                    for kernel, raw, normalized, active in zip(
                        cue_terms["normal_cue_kernels"], cue_terms["normal_cue_band_raw"],
                        cue_terms["normal_cue_band_normalized"], cue_terms["normal_cue_band_active"],
                    )
                }
                entry["roughness_cue_bands"] = {
                    str(kernel): {"raw": float(raw.detach()), "normalized": float(normalized.detach()), "active": active}
                    for kernel, raw, normalized, active in zip(
                        cue_terms["roughness_cue_kernels"], cue_terms["roughness_cue_band_raw"],
                        cue_terms["roughness_cue_band_normalized"], cue_terms["roughness_cue_band_active"],
                    )
                }
        trajectory.append(entry)
        if snapshot_callback is not None:
            snapshot_callback(step, current.detach(), False)
        if entry["train_mse"] < best_loss:
            best_loss = entry["train_mse"]
            best_step = step
            best_state = current.detach().clone()
        if stability and step >= max(300, start_step + 100) and step % 100 == 0:
            losses = [v['train_mse'] for v in trajectory[-101:]]
            relative_span = (max(losses) - min(losses)) / max(sum(losses) / len(losses), 1e-30)
            changes = _map_metrics(current.detach(), window_reference)
            entry['stability_window'] = {'relative_loss_span': relative_span, 'net_map_change': changes}
            stable = (relative_span <= .001 and changes['normal_angular_mean_deg'] <= .001
                      and changes['diffuse'] <= 1e-5 and changes['roughness'] <= 1e-5)
        if stability and step % 100 == 0:
            window_reference = current.detach().clone()
        if step == steps or stable:
            if snapshot_callback is not None:
                snapshot_callback(step, current.detach(), True)
            break
        before = {name: parameters[name].detach().clone() for name in parameters}
        # Keep an exactly matching free teacher stationary; Adam can amplify tiny FP32 noise.
        if mode == "free" and float(train_loss.detach()) <= 1e-30:
            previous_update = {name: 0.0 for name in previous_update}
            continue
        optimizer.step()
        _project_parameters(parameters, mode)
        previous_update = _update_metrics(parameters, before)
    last_state = _compose(parameters).detach().clone()
    import copy
    checkpoint = {'step': step, 'material': last_state.clone(),
                  'optimizer_state': copy.deepcopy(optimizer.state_dict()),
                  'previous_update': dict(previous_update)}
    if cue_contract is not None:
        checkpoint['cue_contract'] = cue_contract
    objective = {'kind': 'measured_plus_preservation' if measurement_enabled else 'teacher_rendering',
                 'spatial_constants': list(spatial_constants),
                 'preservation_weight': preservation_weight,
                 'train_mse_definition': 'total objective' if measurement_enabled else 'preservation MSE'}
    if cue_contract is not None:
        objective['cue_contract'] = cue_contract
    return {
        "checkpoint": checkpoint,
        "start_step": start_step,
        "objective": objective,
        **({"cue_contract": cue_contract} if cue_contract is not None else {}),
        "regime": regime,
        "mode": mode,
        "train_light_count": int(train_lights.shape[0]),
        "lamp_intensity": float(lamp_intensity),
        "steps": int(steps),
        "lr": float(lr),
        "seed": int(seed),
        "trajectory": trajectory,
        "best_step": int(best_step),
        "termination": {'step': step, 'status': 'stability_criteria_met' if stable else 'max_steps_reached'},
        "initial": initial.detach(),
        "best": best_state.detach(),
        "last": last_state.detach(),
        "metrics": {
            "initial_train_mse": trajectory[0]["train_mse"],
            "best_train_mse": float(best_loss),
            "last_train_mse": trajectory[-1]["train_mse"],
            "initial_common_heldout_mse": trajectory[0]["common_heldout_mse"],
            "best_common_heldout_mse": trajectory[best_step-start_step]["common_heldout_mse"],
            "last_common_heldout_mse": trajectory[-1]["common_heldout_mse"],
            "best_map_mae_physical": trajectory[best_step-start_step]["map_mae_physical"],
            "last_map_mae_physical": trajectory[-1]["map_mae_physical"],
            "free_exact_unchanged": bool(mode == "free" and torch.equal(initial, last_state)),
            "fixed_specular_raw": F0_RAW if mode == "fixed" else None,
            "fixed_specular_gradient_rms": 0.0 if mode == "fixed" else None,
        },
        "teacher_train": teacher_train,
        "teacher_common": teacher_common,
    }


def insert_analysis_section(page: str, section: str) -> str:
    block = f"{START_MARKER}{section}{END_MARKER}"
    pattern = re.compile(re.escape(START_MARKER) + r".*?" + re.escape(END_MARKER), re.DOTALL)
    if pattern.search(page):
        return pattern.sub(lambda _: block, page, count=1)
    marker = re.search(r"<details\s+class=technical", page, flags=re.IGNORECASE)
    if marker:
        return page[:marker.start()] + block + page[marker.start():]
    closing = page.lower().rfind("</main>")
    if closing < 0:
        closing = page.lower().rfind("</body>")
    if closing < 0:
        closing = page.lower().rfind("</html>")
    if closing < 0:
        raise ValueError("report page has no insertion point")
    return page[:closing] + block + page[closing:]


def validate_analysis_links(fragment: str, root: Path) -> list[str]:
    errors = []
    for attribute in ("src", "data-linear-src", "data-gamma-src", "href"):
        for value in re.findall(rf"{attribute}=[\"']([^\"']+)[\"']", fragment, flags=re.IGNORECASE):
            if value.startswith(("http:", "https:", "data:", "#", "/")):
                continue
            if not (root / value).is_file():
                errors.append(f"{attribute}: {value}")
    return errors


def _analysis_image(path: str, label: str, *, gamma: str | None = None, plot: bool = False) -> str:
    escaped = html.escape(path, quote=True)
    gamma_attribute = f' data-gamma-src="{html.escape(gamma, quote=True)}"' if gamma else ""
    figure_class = "case-tile analysis-plot" if plot else "case-tile"
    image_style = ' style="width:640px;height:auto"' if plot else ""
    return (
        f'<figure class="{figure_class}"><img class="case-image" src="{escaped}" '
        f'data-linear-src="{escaped}"{gamma_attribute}{image_style} alt="{html.escape(label, quote=True)}">'
        f'<figcaption>{html.escape(label)}</figcaption></figure>'
    )


def _analysis_row(label: str, figures: list[str]) -> str:
    return (
        f'<div class="case-row"><div class="case-label">{html.escape(label)}</div>'
        f'<div class="case-tiles">{"".join(figures)}</div></div>'
    )


def build_analysis_section(sample: str, record: dict, asset_base: str) -> str:
    from revise_fixed_f0_report import section
    return section(record, asset_base)


def build_analysis_index(records: list[dict], artifact_rel: str) -> str:
    from revise_fixed_f0_report import index
    return index(records, artifact_rel)


__all__ = [
    "CAMERA_XYZ",
    "END_MARKER",
    "F0_PHYSICAL",
    "F0_RAW",
    "START_MARKER",
    "analyze_condition",
    "build_analysis_index",
    "build_analysis_section",
    "build_common_heldout_lights",
    "build_light_regimes",
    "build_scan_lights",
    "initial_material",
    "insert_analysis_section",
    "physical_maps",
    "validate_analysis_links",
]
