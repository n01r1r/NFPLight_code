"""Additive HTML integration for prediction-refinement artifacts."""

from __future__ import annotations

import html
import re
from pathlib import Path


START_MARKER = "<!-- prediction-refinement:start -->"
END_MARKER = "<!-- prediction-refinement:end -->"


def insert_refinement_section(page: str, section: str) -> str:
    """Replace only this tool's marked section and preserve the existing page."""
    block = f"{START_MARKER}{section}{END_MARKER}"
    pattern = re.compile(re.escape(START_MARKER) + r".*?" + re.escape(END_MARKER), re.DOTALL)
    if pattern.search(page):
        return pattern.sub(lambda _: block, page, count=1)
    marker = re.search(r"<details\s+class=technical", page, flags=re.IGNORECASE)
    if marker:
        return page[:marker.start()] + block + page[marker.start():]
    closing = page.lower().rfind("</main>")
    if closing < 0:
        closing = page.lower().rfind("</body>")
    if closing < 0:
        closing = page.lower().rfind("</html>")
    if closing < 0:
        raise ValueError("report page has no insertion point")
    return page[:closing] + block + page[closing:]


def validate_refinement_links(fragment: str, root: Path) -> list[str]:
    """Return missing relative image links in a refinement fragment."""
    errors: list[str] = []
    for attribute in ("src", "data-linear-src", "data-gamma-src", "href"):
        for value in re.findall(rf"{attribute}=[\"']([^\"']+)[\"']", fragment, flags=re.IGNORECASE):
            if value.startswith(("http:", "https:", "data:", "#", "/")):
                continue
            if not (root / value).is_file():
                errors.append(f"{attribute}: {value}")
    return errors


def _image(path: str, label: str, *, gamma: str | None = None) -> str:
    attrs = f' data-linear-src="{html.escape(path, quote=True)}"'
    if gamma:
        attrs += f' data-gamma-src="{html.escape(gamma, quote=True)}"'
    return (f'<figure class="case-tile"><img class="case-image" src="{html.escape(path, quote=True)}"'
            f'{attrs} alt="{html.escape(label, quote=True)}"><figcaption>{html.escape(label)}</figcaption></figure>')


def _row(label: str, figures: list[str]) -> str:
    return f'<div class="case-row"><div class="case-label">{html.escape(label)}</div><div class="case-tiles">{"".join(figures)}</div></div>'


def build_refinement_section(sample: str, record: dict, asset_base: str) -> str:
    """Build the marked section; asset_base is relative to the report refresh directory."""
    metrics = record.get("metrics", {})
    lamp = metrics.get("lamp_intensity", {})
    post = metrics.get("lamp_intensity_post_refined", {})
    prefix = asset_base.rstrip("/")
    component_rows = []
    components = (("n · normal", "normal"), ("d · diffuse", "diffuse"),
                  ("r · roughness", "roughness"), ("s · specular", "specular"))
    for stage, label in (("original", "original pred"), ("fixed_f0", "fixed F0=0.04"), ("refined", "refined")):
        figures = []
        for title, stem in components:
            path = f"{prefix}/{stem}_{stage}.png"
            gamma = f"{prefix}/{stem}_{stage}_gamma22.png" if stem in {"diffuse", "specular"} else None
            figures.append(_image(path, f"{title} · {label}", gamma=gamma))
        component_rows.append(_row(label, figures))
    render_rows = [
        _row("near render · frozen training q", [
            _image(f"{prefix}/near_render_teacher_frozen_q.png", "teacher original · frozen q", gamma=f"{prefix}/near_render_teacher_frozen_q_gamma22.png"),
            _image(f"{prefix}/near_render_fixed_f0_frozen_q.png", "fixed F0 initial · frozen q", gamma=f"{prefix}/near_render_fixed_f0_frozen_q_gamma22.png"),
            _image(f"{prefix}/near_render_refined_frozen_q.png", "refined · frozen q", gamma=f"{prefix}/near_render_refined_frozen_q_gamma22.png"),
            _image(f"{prefix}/near_input.png", "I_N calibration reference", gamma=f"{prefix}/near_input_gamma22.png"),
        ]),
        _row("near render · refined recommended q", [
            _image(f"{prefix}/near_render_refined_recommended_q.png", "refined · recommended q", gamma=f"{prefix}/near_render_refined_recommended_q_gamma22.png"),
        ]),
    ]
    summary = (f"<p>FP32 prediction-only refinement; real I_N/I_F are excluded from loss. "
               f"Training q={float(lamp.get('q', float('nan'))):.7g} (frozen); "
               f"refined display recommendation q={float(post.get('q', float('nan'))):.7g}. "
               f"<a href=\"{html.escape(prefix + '/metrics.json', quote=True)}\">metrics.json</a></p>")
    heldout_initial = float(metrics.get("heldout_initial_teacher_mse", float("nan")))
    heldout_final = float(metrics.get("heldout_final_teacher_mse", float("nan")))
    heldout_note = ""
    if heldout_final > heldout_initial:
        heldout_note = ("<p class=\"refinement-caution\"><strong>Held-out caution:</strong> "
                        "the refined held-out teacher MSE increased; this run is reported as "
                        "prediction consistency on the training light set, not as a generalization claim.</p>")
    table = ("<table><thead><tr><th>metric</th><th>value</th></tr></thead><tbody>"
             f"<tr><th>teacher MSE initial fixed-F0</th><td>{float(metrics.get('initial_teacher_mse', float('nan'))):.7g}</td></tr>"
             f"<tr><th>teacher MSE refined</th><td>{float(metrics.get('final_teacher_mse', float('nan'))):.7g}</td></tr>"
             f"<tr><th>training q / fitted I_N RMSE</th><td>{float(lamp.get('q', float('nan'))):.7g} / {float(lamp.get('fitted_rmse', float('nan'))):.7g}</td></tr>"
             f"<tr><th>refined recommended q / fitted I_N RMSE</th><td>{float(post.get('q', float('nan'))):.7g} / {float(post.get('fitted_rmse', float('nan'))):.7g}</td></tr>"
             f"<tr><th>held-out teacher MSE initial / refined</th><td>{float(metrics.get('heldout_initial_teacher_mse', float('nan'))):.7g} / {float(metrics.get('heldout_final_teacher_mse', float('nan'))):.7g}</td></tr>"
             "</tbody></table>")
    body = (f'<section id="prediction-refinement" class="technical"><h2>Prediction refinement · {html.escape(sample)}</h2>'
            f'{summary}{heldout_note}{table}{"".join(component_rows)}{"".join(render_rows)}</section>')
    return body


def build_index_refinement_summary(records: list[dict], artifact_rel: str) -> str:
    rows = []
    for record in records:
        sample = html.escape(str(record["sample"]))
        metrics = record.get("metrics", {})
        lamp = metrics.get("lamp_intensity", {})
        post = metrics.get("lamp_intensity_post_refined", {})
        link = f"{artifact_rel.rstrip('/')}/{sample}/report.html"
        rows.append(f"<tr><th>{sample}</th><td>{html.escape(str(record.get('selection', '')))}</td>"
                    f"<td>{float(lamp.get('q', float('nan'))):.7g}</td><td>{float(post.get('q', float('nan'))):.7g}</td>"
                    f"<td>{float(metrics.get('final_teacher_mse', float('nan'))):.7g}</td><td><a href=\"{html.escape(link, quote=True)}\">refinement</a></td></tr>")
    return (f"<section id=\"prediction-refinement\" class=\"technical\"><h2>Prediction refinement · 5 samples</h2>"
            "<p>Original author FP32 prediction teacher; s=0.04 fixed. Training q is frozen; refined q is a display-only recommendation. This is a prediction-consistency result, not a material-accuracy claim.</p>"
            "<table><thead><tr><th>sample</th><th>frame selection</th><th>training q</th><th>refined recommended q</th><th>refined teacher MSE</th><th></th></tr></thead><tbody>"
            + "".join(rows) + "</tbody></table></section>")


__all__ = ["START_MARKER", "END_MARKER", "build_index_refinement_summary", "build_refinement_section", "insert_refinement_section", "validate_refinement_links"]
