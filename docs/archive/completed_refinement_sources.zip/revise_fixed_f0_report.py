"""Rebuild fixed-F0 presentation from recorded trajectories; no inference."""
import json
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from capture_processing.rendering_loss_analysis import insert_analysis_section

ROOT = Path('artifacts/rendering_loss_analysis_20261006')
CAPTURE = Path('artifacts/fabric_capture_20261002_aligned_paper_equations')
REGIMES = ('center', 'small', 'wide')
COLORS = ('#0072B2', '#D55E00', '#009E73')
STYLES = ('-', '--', ':')
LIGHT_NAMES = {'center': '중앙 · 1광원', 'small': 'XY 반경 0.25 · 5광원', 'wide': 'XY 반경 1.50 · 5광원'}
PLOT_NAMES = {'center': 'Center: 1 light', 'small': 'XY radius 0.25: 5 lights', 'wide': 'XY radius 1.50: 5 lights'}

OBSERVATIONS = {
    '260818_174845_478': 'Wide에서는 diffuse의 직조·대각 무늬 대비가 더 드러난다. 비교적 균일하던 roughness에는 큰 공간 분포와 미세 점무늬가 나타난다.',
    '260818_175005_078': 'Wide의 붉은 직조 영역은 조금 밝아지지만 격자·대각 패턴은 유지된다. Roughness 차이는 현재 표시 크기에서 뚜렷하게 구별하기 어렵다.',
    '260923_141241_844': 'Wide의 diffuse 중앙이 밝아지고, roughness에는 큰 어두운 영역과 미세한 엮임 대비가 나타난다. 이 구조가 실제 재질인지 조명 변화의 보상인지는 현재 자료로 판정할 수 없다.',
    '260923_161825_503': 'Wide의 diffuse에서 어두웠던 문자와 중앙 영역이 황색·주황색으로 크게 밝아진다. Roughness에도 문자·엮임을 따르는 공간 변화가 보인다. Small의 중앙 렌더링은 원본과 비슷하게 보이지만, 미사용 조명에서 측정한 원본 대비 차이는 커졌다.',
    '260930_152732_008': 'Small의 중앙 렌더링은 원본의 색 띠와 중앙 반짝임을 대체로 유지한다. Wide에서는 diffuse의 밝은 띠와 roughness의 상단·측면 분포가 달라진다.',
}

def plot_comparison(record, root=ROOT):
    """Separate quantities/units, shared regime encoding, no dual axes."""
    specs = [
        ('Training lights', 'Mean squared RGB difference', lambda t: t['train_mse'], True),
        ('Eight unused lights', 'Mean squared RGB difference', lambda t: t['common_heldout_mse'], True),
        ('Normal direction vs original', 'Mean angle (degrees)', lambda t: t['map_mae_physical']['normal_angular_mean_deg'], False),
        ('Diffuse vs original', 'Mean absolute difference (0–1)', lambda t: t['map_mae_physical']['diffuse'], False),
        ('Roughness vs original', 'Mean absolute difference (0–1)', lambda t: t['map_mae_physical']['roughness'], False),
    ]
    folder = root / record['sample']
    plt.rcParams.update({'font.size': 12, 'axes.titlesize': 14, 'svg.fonttype': 'none'})
    groups = [('rendering', specs[:2]), ('maps', specs[2:]), ('optimizer', [
        (f'{name} raw gradient', 'Gradient RMS (raw coordinates)', lambda t, k=k: t['gradient_rms_raw'][k], True)
        for name, k in [('Normal', 'n'), ('Diffuse', 'd'), ('Roughness', 'r')]
    ])]
    for filename, panels in groups:
        fig, axes = plt.subplots(1, len(panels), figsize=(5.2 * len(panels), 4.2), constrained_layout=True)
        for ax, (title, ylabel, value, log) in zip(axes, panels):
            for regime, color, style in zip(REGIMES, COLORS, STYLES):
                condition = record['conditions'][regime]['fixed']
                trajectory = condition['trajectory']
                vals = [value(t) for t in trajectory]
                ax.plot([t['step'] for t in trajectory], vals, color=color, ls=style, lw=2, label=PLOT_NAMES[regime])
                best = condition['best_step']
                ax.scatter(best, value(trajectory[best]), color=color, marker='o', s=30, zorder=3)
            if log:
                if min(value(t) for r in REGIMES for t in record['conditions'][r]['fixed']['trajectory']) > 0:
                    ax.set_yscale('log')
                else:
                    ax.set_yscale('symlog', linthresh=1e-12)
            else:
                ax.set_ylim(bottom=0)
            ax.set(title=title, ylabel=ylabel, xlabel='Adam update', xlim=(0, max(record['conditions'][r]['fixed']['steps'] for r in REGIMES)))
            ax.spines[['top', 'right']].set_visible(False)
            ax.grid(axis='y', alpha=.18)
        axes[0].legend(frameon=False, fontsize=9, loc='best')
        fig.savefig(folder / f'{filename}.png', dpi=180)
        fig.savefig(folder / f'{filename}.svg')
        plt.close(fig)

def section(record, base):
    sample = record['sample']
    prefix = f'{base}/{sample}'
    conditions = record['conditions']
    # Observations belong to the reviewed run, not arbitrary future inference.
    reviewed = record.get('artifact', '').replace('\\', '/').endswith(f'rendering_loss_analysis_20261006/{sample}')
    observation = OBSERVATIONS.get(sample, '') if reviewed else '이 실행의 개별 시각 관찰은 아직 기록하지 않았다.'
    observation = observation.replace('Wide', '광원 XY 반경 1.50 조건').replace('Small', '광원 XY 반경 0.25 조건')
    def picture(regime, name, label, rgb=False):
        linear = f'{prefix}/{regime}/fixed/{name}.png'
        gamma = f'{prefix}/{regime}/fixed/{name}_gamma22.png' if rgb else linear
        attributes = f' data-f0-linear="{linear}" data-f0-gamma="{gamma}"' if rgb else ''
        return f'<figure><img src="{gamma}"{attributes} alt="{label}"><figcaption>{label}</figcaption></figure>'
    map_rows = []
    original_cells = []
    for component, label in [('normal','n · Normal'),('diffuse','d · Diffuse'),('roughness','r · Roughness'),('specular','s · F0')]:
        if not reviewed:
            original_cells.append(picture('center', f'map_original_{component}', label, component in ('diffuse', 'specular')))
            continue
        linear = f'{base}/change_images/{sample}/original_{component}.png'
        gamma = linear.replace('.png','_gamma22.png') if component in ('diffuse','specular') else linear
        attributes = f' data-f0-linear="{linear}" data-f0-gamma="{gamma}"' if component in ('diffuse','specular') else ''
        original_cells.append(f'<figure><img src="{gamma}"{attributes} alt="원래 pred {label}"><figcaption>{label}</figcaption></figure>')
    map_rows.append(f'<h4>원래 prediction · n / d / r / s</h4><div class="f0-scroll"><div class="f0-gallery four">{"".join(original_cells)}</div></div>')
    for regime in REGIMES:
        step = conditions[regime]['fixed']['best_step']
        cells = [picture(regime, f'map_best_{component}', label, component in ('diffuse','specular')) for component,label in [('normal','n · Normal'),('diffuse','d · Diffuse'),('roughness','r · Roughness'),('specular','s · F0=0.04 고정')]]
        map_rows.append(f'<h4>F0 고정 후 refinement · {LIGHT_NAMES[regime]} · 선택 step {step}</h4><div class="f0-scroll"><div class="f0-gallery four">{"".join(cells)}</div></div>')
    render_cells = [picture('center', 'render_teacher', '원본 F0의 렌더링', True), picture('center', 'render_step0', 'F0=0.04 고정 직후', True)]
    for regime in REGIMES:
        step = conditions[regime]['fixed']['best_step']
        render_cells.append(picture(regime, 'render_best', f'{LIGHT_NAMES[regime]} · 선택 step {step}', True))
    table_rows = []
    final_rows = []
    for regime in REGIMES:
        c = conditions[regime]['fixed']; m = c['metrics']
        table_rows.append(f"<tr><th>{LIGHT_NAMES[regime]}</th><td>{c['best_step']}</td><td>{m['initial_train_mse']:.4g}</td><td>{m['best_train_mse']:.4g}</td><td>{m['initial_common_heldout_mse']:.4g}</td><td>{m['best_common_heldout_mse']:.4g}</td><td>{m['last_common_heldout_mse']:.4g}</td></tr>")
        figures = [picture(regime, f'map_last_{k}', f'{label} · 최종 step {c["steps"]}', k == 'diffuse') for k, label in [('normal','Normal'),('diffuse','Diffuse'),('roughness','Roughness')]]
        figures.append(picture(regime, 'render_last', f'중앙 렌더 · 최종 step {c["steps"]}', True))
        final_rows.append(f'<h4>{LIGHT_NAMES[regime]}</h4><div class="f0-scroll"><div class="f0-gallery four">{"".join(figures)}</div></div>')
    change_prefix = f'{base}/change_images_rgb/{sample}'
    heatmaps = ''
    if reviewed and (ROOT / 'change_images_rgb' / 'checks.json').is_file():
        scales = json.loads((ROOT / 'change_images_rgb' / 'checks.json').read_text(encoding='utf-8'))['sample_display_scales'][sample]
        for regime in REGIMES:
            title = f'{LIGHT_NAMES[regime]} · 원래 pred → F0 고정 후 선택 상태'
            heatmaps += f'<h4>{title}</h4><img class="f0-plot" src="{change_prefix}/{regime}_changes.png" alt="Normal angular variation and single RGB difference images"><a href="{change_prefix}/{regime}_changes.svg">SVG</a>'
        heatmaps += f'<p class="note">RGB 차이의 공통 표시 범위: diffuse ±{scales["diffuse"]:.5g}, roughness ±{scales["roughness"]:.5g}, F0 ±{scales["specular"]:.5g}. Normal 각도는 0–{scales["normal_angle_deg"]:.5g}도다. RGB 차이는 이 샘플의 세 조건에 같은 범위를 적용했다. 샘플 간 표시 배율은 다르므로 색의 진하기를 직접 비교하지 않는다. Normal 각도 범위는 전체 샘플에 공통이다.</p>'
    q = record['lamp_intensity']['q']
    selected = [conditions[k]['fixed']['metrics']['best_common_heldout_mse'] for k in REGIMES]
    initial = conditions['center']['fixed']['metrics']['initial_common_heldout_mse']
    closest = REGIMES[min(range(3), key=lambda i: selected[i])]
    farther = [k for k, v in zip(REGIMES, selected) if v > initial]
    result = f'미사용 조명 8개에서 원본 렌더링과의 평균 제곱 차이는 {LIGHT_NAMES[closest]}의 선택 상태가 가장 작다.'
    if farther:
        result += f' {", ".join(LIGHT_NAMES[k] for k in farther)}는 F0 고정 직후보다 차이가 커졌다.'
    final_step = max(conditions[k]['fixed']['steps'] for k in REGIMES)
    review_links = ''
    if reviewed:
        review_links = f'<p class="f0-links"><a href="{base}/council_review/verdict.html">Council 검토</a> · <a href="{base}/council_review/qualitative.html">다섯 샘플 정성 비교</a> · <a href="{base}/ANALYSIS.html">전체 해석</a></p>'
    return f'''<section id="rendering-loss-analysis" class="f0-review">
    <style>.f0-review{{font:17px/1.7 Arial,sans-serif;max-width:1320px;margin:28px auto;padding:28px;background:#fafafa;color:#202020;box-sizing:border-box}}.f0-review h2{{font-size:26px}}.f0-review h3{{font-size:22px;margin-top:34px}}.f0-review h4{{font-size:18px;margin:22px 0 10px}}.f0-review p{{max-width:1000px}}.f0-review table{{width:100%;border-collapse:collapse;font-size:14px;white-space:nowrap}}.f0-review th,.f0-review td{{padding:10px;border-bottom:1px solid #bbb;text-align:left}}.f0-review .f0-plot{{display:block;width:100%;height:auto;max-width:none}}.f0-review details{{margin:24px 0}}.f0-review summary{{cursor:pointer;font-weight:bold}}.f0-review .f0-scroll{{overflow-x:auto}}.f0-review .f0-gallery{{display:grid;gap:16px;align-items:start}}.f0-review .four{{grid-template-columns:repeat(4,minmax(210px,1fr))}}.f0-review .five{{grid-template-columns:repeat(5,minmax(190px,1fr))}}.f0-review figure{{margin:0}}.f0-review .f0-gallery img{{width:100%;height:auto;display:block;background:#222}}.f0-review figcaption{{font-size:14px;margin-top:6px}}.f0-review a{{color:#0064a0}}.f0-review button{{padding:7px 14px;margin-right:8px;font:inherit}}.f0-review .note{{color:#555;font-size:15px}}@media(max-width:700px){{.f0-review{{padding:16px;font-size:16px}}}}</style>
    <h2>F0=0.04 고정 후 무엇이 달라졌나 · {sample}</h2>
    <p>F0를 고정한 뒤 normal·diffuse·roughness를 조정해 원본 prediction의 렌더링을 맞췄다. 아래 수치와 이미지는 <strong>원본 대비 차이</strong>를 나타낸다. 원본은 ground truth가 아니다.</p>
    <p>{result}</p>{review_links}
    <h3>눈으로 확인한 변화</h3>
    <p>{observation}</p>
    <p class="note">첫 행은 원래 pred의 n/d/r/s다. 다음 행들은 F0=0.04를 유지하며 n/d/r를 refinement한 결과다. Roughness는 렌더러의 유효값이다. 각 선택 상태는 해당 조건의 학습 조명 차이가 최소인 iteration이며, 최종 step {final_step}과 구분한다.</p>
    <div class="f0-display"><button type="button" onclick="this.closest('.f0-review').querySelectorAll('[data-f0-gamma]').forEach(i=>i.src=i.dataset.f0Gamma)">Gamma 1/2.2</button><button type="button" onclick="this.closest('.f0-review').querySelectorAll('[data-f0-linear]').forEach(i=>i.src=i.dataset.f0Linear)">Linear</button><span class="note">RGB 표시만 전환 · 기본 Gamma</span></div>
    <h3>원래 pred와 F0 고정 후 맵</h3>
    {''.join(map_rows)}
    <h3>그 사이의 변화량 · 맵마다 한 영상</h3>
    <p>Normal은 원본과의 픽셀별 방향 각도 변화(도)다. Diffuse와 specular는 RGB 채널을 합친 단일 변화 영상이다. 선택 상태 − 원본의 signed RGB 차이를 중간 회색=0으로 표시한다. Roughness는 단일 값이므로 회색조로 증가·감소를 나타낸다. 변화 영상에는 Gamma를 적용하지 않는다.</p>
    {heatmaps}
<p class="note">RGB 변화 영상의 각 채널은 0.5 + Δ/(2M)로 표시했다. 채널이 증가하면 해당 색이 더 밝아지고, 감소하면 더 어두워진다. Specular의 Δ는 0.04 − 원본 F0이며 모든 조건에서 같다. F0는 refinement 중 고정되어 그 단계의 변화는 0이다. 표시용 PNG 차감은 하지 않았다.</p>
    <h4>중앙 조명 (0,0,4)의 렌더링</h4>
    <div class="f0-scroll"><div class="f0-gallery five">{''.join(render_cells)}</div></div>
    <p class="note">모든 영상은 같은 중앙 조명이다. 각 조건명은 최적화에 사용한 광원의 XY 이동 반경과 개수를 뜻한다. 저장된 8-bit PNG는 0–1로 잘려 있어 작은 차이나 밝은 영역의 차이가 잘 보이지 않을 수 있다. 미사용 조명 영상은 저장하지 않았으므로 그 조명의 공간적 변화를 이 그림으로 설명할 수 없다.</p>
    <h3>렌더링 차이가 줄어드는 과정</h3>
    <p>왼쪽은 학습에 쓴 조명, 오른쪽은 모든 조건에 공통인 미사용 조명 8개다. 평균 제곱 RGB 차이를 log 축에 그렸다. 점은 각 조건의 학습 차이가 최소인 상태다.</p>
    <img class="f0-plot" src="{prefix}/rendering.png" alt="학습·미사용 조명에서의 원본 대비 렌더링 차이"><a href="{prefix}/rendering.svg">SVG</a>
    <h3>그 과정에서 맵은 얼마나 바뀌었나</h3>
    <p>Normal은 원본 방향과의 평균 각도(도), diffuse와 roughness는 원본 물리 맵과의 평균 절대 차이다. 서로 다른 양이므로 각기 다른 축에 표시했다.</p>
    <img class="f0-plot" src="{prefix}/maps.png" alt="원본 대비 normal 각도와 diffuse·roughness 변화"><a href="{prefix}/maps.svg">SVG</a>
    <h3>선택 상태와 최종 상태</h3>
    <div class="f0-scroll"><table><thead><tr><th>조건</th><th>선택 step</th><th>학습 · 초기</th><th>학습 · 선택</th><th>미사용 · 초기</th><th>미사용 · 선택</th><th>미사용 · 최종</th></tr></thead><tbody>{''.join(table_rows)}</tbody></table></div>
    <p class="note">초기는 F0를 고정한 직후다. 모든 값은 unclipped linear RGB 차이를 제곱해 픽셀·채널·조명 전체에 평균한 값이다. 선택은 학습 조명 기준이며 미사용 조명에서 가장 가까운 상태를 고른 것이 아니다.</p>
    <details><summary>최종 step {final_step}의 맵과 중앙 렌더링</summary>{''.join(final_rows)}</details>
    <details><summary>실험 조건과 해석 범위</summary>
    <p>카메라 (0,0,4), 광원 z=4. 중앙 조건은 광원 한 개다. XY 반경 0.25와 1.50 조건은 중앙과 해당 반경의 상하좌우 네 광원, 총 다섯 개다. 미사용 조명은 반경 0.75·1.25의 대각선 네 방향씩 총 8개다. 좌표는 무차원이다.</p>
    <p>광원 세기 q={q:.6g}. 원본 중앙 렌더링의 평균 RGB를 실제 I_N에 맞춰 한 번 정한 뒤 모든 조건에서 고정했다. I_N의 최대 채널이 0.95 이하인 영역만 적합에 사용했고, refinement 목표에는 실제 영상을 넣지 않았다.</p>
    <p>Adam lr={conditions['center']['fixed']['lr']:g}, {final_step} updates, FP32, AMP·TF32 off. Prior와 perturbation은 없다. 중앙 조건과 이동 조건은 광원 수가 1 대 5여서 범위와 제약 수가 함께 달라진다. 반경 0.25와 1.50 조건은 광원 수·방향이 같지만 최적화 난이도와 미수렴 영향을 분리한 비교는 아니다.</p>
    <p>샘플마다 q가 다르고 RGB MSE는 q²에 비례하므로 샘플 간 절대값을 재질 난이도 순위로 읽지 않는다. 현재 결과는 한 번의 실행과 지정 조명에 한정된다. 원본과 가까워졌다는 사실만으로 실제 재질 정확도나 보편적인 최적 조명 범위를 판단할 수 없다.</p></details>
    <details><summary>Raw gradient 기록</summary><p>파라미터 좌표에서의 gradient RMS다. Normal 정규화와 스케일에 의존하므로 맵 간 물리적 중요도 순위로 읽지 않는다. F0는 optimizer에서 제외했다.</p><img class="f0-plot" src="{prefix}/optimizer.png" alt="Raw 좌표의 gradient 추이"><a href="{prefix}/optimizer.svg">SVG</a></details>
    </section>'''

def index(records, base):
    rows = []
    for r in records:
        vals = [r['conditions'][k]['fixed']['metrics']['best_common_heldout_mse'] for k in REGIMES]
        rows.append(f'<tr><th><a href="{base}/{r["sample"]}/report.html">{r["sample"]}</a></th>'+''.join(f'<td>{v:.4g}</td>' for v in vals)+'</tr>')
    observations = ''.join(f'<p><a href="{base}/{r["sample"]}/report.html">{r["sample"]}</a> — {OBSERVATIONS[r["sample"]].replace("Wide", "광원 XY 반경 1.50 조건").replace("Small", "광원 XY 반경 0.25 조건")}</p>' for r in records if r.get('artifact', '').replace('\\', '/').endswith(f'rendering_loss_analysis_20261006/{r["sample"]}'))
    return f'<section id="rendering-loss-analysis"><h2>F0=0.04 · 조명별 변화 비교</h2><p>F0를 고정하고 normal·diffuse·roughness를 조정했다. 표는 공통 미사용 조명 8개에서 측정한 원본 대비 평균 제곱 RGB 차이다. 각 조건의 학습 차이가 최소인 상태를 비교한다.</p><table><tr><th>Sample</th><th>중앙 · 1광원</th><th>XY 반경 0.25 · 5광원</th><th>XY 반경 1.50 · 5광원</th></tr>{"".join(rows)}</table><h3>샘플에서 보이는 변화</h3>{observations}<p>관찰은 맵과 중앙 조명 렌더링에 한정된다. 표의 미사용 조명 순위와 실제 재질 정확도는 구분한다. 세기 q가 샘플마다 달라 샘플 간 절대값을 난이도 순위로 읽지 않는다.</p></section>'

def main():
    import os
    import shutil
    summary = json.loads((ROOT/'summary.json').read_text(encoding='utf-8'))
    records = summary['samples']
    backup = ROOT / 'presentation_before_integration'
    backup.mkdir(exist_ok=True)
    numeric_paths = list(ROOT.glob('*/metrics.json')) + list(ROOT.glob('*/*/*/condition.json')) + [ROOT / 'summary.json', ROOT / 'plan.json']
    numeric_before = {str(p): (p.stat().st_size, p.stat().st_mtime_ns) for p in numeric_paths}
    for record in records:
        sample = record['sample']
        refresh = CAPTURE / sample / 'refresh_20261006'
        for path, label in [(ROOT / sample / 'report.html', 'analysis'), (refresh / 'report.html', 'refresh'), (refresh.parent / 'report.html', 'root')]:
            destination = backup / f'{sample}_{label}.html'
            if not destination.exists():
                shutil.copyfile(path, destination)
    for path, label in [(ROOT / 'summary.html', 'summary'), (CAPTURE / 'index.html', 'capture_index'), (ROOT / 'ANALYSIS.md', 'analysis_before'), (ROOT / 'ANALYSIS.html', 'analysis_html_before')]:
        destination = backup / f'{label}{path.suffix}'
        if not destination.exists():
            shutil.copyfile(path, destination)
    for record in records:
        plot_comparison(record)
        page = '<!doctype html><meta charset="utf-8"><title>Fixed F0 comparison</title>'+section(record, '..')
        (ROOT/record['sample']/'report.html').write_text(page, encoding='utf-8')
        refresh = CAPTURE/record['sample']/'refresh_20261006'
        base = os.path.relpath(ROOT, refresh).replace('\\','/')
        for path in (refresh/'report.html', refresh.parent/'report.html'):
            path.write_text(insert_analysis_section(path.read_text(encoding='utf-8'), section(record, base)), encoding='utf-8')
    (ROOT/'summary.html').write_text('<!doctype html><html lang="ko"><meta charset="utf-8"><title>F0 고정 · 조명별 결과</title><style>body{font:17px/1.7 Arial;max-width:1150px;margin:40px auto;padding:20px;color:#222;background:#fafafa}td,th{padding:12px;text-align:left}table{border-collapse:collapse}tr{border-bottom:1px solid #ccc}a{color:#0064a0}</style><p><a href="ANALYSIS.html">전체 해석</a> · <a href="council_review/verdict.html">Council 검토</a> · <a href="council_review/qualitative.html">정성 비교 모음</a></p>'+index(records,'.')+'</html>',encoding='utf-8')
    path = CAPTURE/'index.html'
    path.write_text(insert_analysis_section(path.read_text(encoding='utf-8'),index(records,os.path.relpath(ROOT,CAPTURE).replace('\\','/'))),encoding='utf-8')
    assert all((p.stat().st_size, p.stat().st_mtime_ns) == numeric_before[str(p)] for p in numeric_paths)
    (ROOT / 'presentation_revision.json').write_text(json.dumps({'fixed_only': True, 'samples': len(records), 'numeric_records_unchanged': len(numeric_paths), 'new_experiments': False, 'backup': str(backup), 'source': 'existing reviewed PNG and trajectories', 'qualitative_scope': 'maps and centered renders only'}, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Rebuilt fixed-F0 reports and integrated sections; original metrics untouched.')

if __name__ == '__main__':
    main()
