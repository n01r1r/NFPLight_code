"""Saved cue-constrained comparison images; no inference or optimization."""
import json
from pathlib import Path
from PIL import Image
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib.utils import ImageReader
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
import fitz

ROOT=Path('artifacts/cue_constrained_refinement_20261007_diffuse_only')
OUT=Path('output/pdf/cue_constrained_refinement_20261007_diffuse_only.pdf')
pdfmetrics.registerFont(TTFont('KR','C:/Windows/Fonts/batang.ttc',subfontIndex=0))
pdfmetrics.registerFont(TTFont('EN','C:/Windows/Fonts/georgia.ttf'))
W,H=landscape(A4)
c=canvas.Canvas(str(OUT),pagesize=(W,H))
c.setTitle('078 / 478 - Cue-constrained refinement comparison')
records=json.loads((ROOT/'constraint_comparison.json').read_text(encoding='utf-8'))
page=0

def text(x,y,s,size=11,font='KR'):
    c.setFillColorRGB(.12,.14,.17);c.setFont(font,size);c.drawString(x,y,s)

def begin(title,subtitle):
    global page
    page+=1
    text(30,H-32,title,19)
    text(30,H-53,subtitle,10)

def end():
    text(30,18,'FP32 | F0=0.04 | q 고정 | 측정 I_N MSE + 0.1 x 40방향 원본 응답 보존',9)
    text(W-65,18,f'{page} / 4',9,'EN')
    c.showPage()

def image(path,x,y,w,h,box=None):
    with Image.open(path) as im:
        im=im.convert('RGB')
        if box: im=im.crop(box)
        c.drawImage(ImageReader(im),x,y,width=w,height=h)

for rec in records:
    sample=rec['sample']; short=sample[-3:]; folder=ROOT/sample; target=folder/'theta_joint'
    condition=json.loads((target/'condition.json').read_text(encoding='utf-8'))
    final=folder/condition['frames'][-1]['path']
    restriction='normal 공간 상수' if short=='078' else 'diffuse RGB 공간 상수 / normal·roughness 자유'
    stop='안정화 기준 충족' if rec['termination']['status']=='stability_criteria_met' else '상한 종료 / 안정화 기준 미충족'
    begin(f'{short} | 재질 맵 비교',f'{restriction} / 공유 값도 최적화 / {rec["termination"]["step"]:,} step / {stop}')
    size=132; xs=[190+i*151 for i in range(4)]
    for x,name in zip(xs,['Normal','Diffuse','Roughness','F0']): text(x,H-76,name,11,'EN')
    for row,(label,path) in enumerate([('원본 pretrained pred',folder/'original.webp'),('제약 적용 초기값',target/'step_00000.webp'),('최종 결과',final)]):
        y=H-220-row*150
        text(30,y+size/2,label,11)
        for i,x in enumerate(xs): image(path,x,y,size,size,(i*256,0,(i+1)*256,256))
    end()
    begin(f'{short} | 중앙 렌더링 및 변화',f'{restriction} / 동일한 q와 중앙 조명 / 렌더링 표시는 gamma 1/2.2')
    labels=['원본 pred','제약 적용 초기값','최종 결과','기존 무제약 참고','실측 I_N']
    keys=['original','initial','updated','unconstrained_reference']
    size=140; xs=[30+i*157 for i in range(5)]
    for i,(x,label) in enumerate(zip(xs,labels)):
        text(x,H-88,label,10)
        image(target/(f'center_{keys[i]}.webp' if i<4 else 'measured_near.webp'),x,H-240,size,size)
        if i<4: text(x,H-261,f'MSE {rec["metrics"][keys[i]]["measured_mse"]:.4g}',10,'EN')
    text(30,H-292,'최종 재질 맵 변화 (원본 pred 기준)',13)
    for i,(x,label) in enumerate(zip(xs[:3],['Normal 각도 변화','Diffuse signed 차이','Roughness signed 차이'])):
        text(x,H-315,label,10)
        image(final,x,H-466,size,size,(i*256,256,(i+1)*256,512))
    scales=condition['display_scales']
    text(510,H-336,f'Normal scale: {scales["normal"]:.4g} deg',10,'EN')
    text(510,H-358,f'Diffuse scale: +/-{scales["diffuse"]:.4g}',10,'EN')
    text(510,H-380,f'Roughness scale: +/-{scales["roughness"]:.4g}',10,'EN')
    text(510,H-404,'Signed 차이: 회색 0 / 밝음 + / 어두움 -',9)
    text(30,83,'지정한 공간 상수 제약을 검사했다. 기존 무제약 참고와의 오차는 위 수치로 비교한다.',10)
    text(30,64,'원본 pred는 저장된 pretrained 출력이다. 물리적 정답 및 geometry 보정은 검증하지 않았다.',10)
    if short=='078': text(30,45,'078 무제약 참고 결과는 초기 목적함수가 다른 구간을 포함하므로 동일 실행 비교가 아니다.',9)
    end()
c.save()
doc=fitz.open(OUT)
assert len(doc)==4
previews=Path('tmp/pdfs/cue_constrained'); previews.mkdir(parents=True,exist_ok=True)
for i,p in enumerate(doc):
    assert short or p.get_text()
    p.get_pixmap(matrix=fitz.Matrix(1.25,1.25)).save(previews/f'page_{i+1}.png')
print(OUT.resolve())
