"""Top-view projection of the recorded training and unused evaluation lights."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt


def sampling_diagram(output, samples=None):
    output = Path(output)
    if samples is None:
        summary = json.loads((output / 'summary.json').read_text(encoding='utf-8'))
        samples = summary['active_samples'] if 'active_samples' in summary else [item['sample'] for item in summary['samples']]
    coordinates = []
    for sample in samples:
        record = json.loads((output / sample / 'theta_joint/condition.json').read_text(encoding='utf-8'))
        coordinates.append((np.array(record['train_xyz']), np.array(record['evaluation_xyz'])))
    train, test = coordinates[0]
    assert train.shape in ((41, 3), (40, 3)) and test.shape == (40, 3)
    has_center = bool(np.any(np.linalg.norm(train[:, :2], axis=1) < 1e-8))
    assert np.isfinite(train).all() and np.isfinite(test).all()
    for a, b in coordinates[1:]:
        np.testing.assert_array_equal(train, a)
        np.testing.assert_array_equal(test, b)
    np.testing.assert_allclose(np.linalg.norm(train, axis=1), 4, rtol=1e-6)
    np.testing.assert_allclose(np.linalg.norm(test, axis=1), 4, rtol=1e-6)
    points = np.concatenate((train[:, :2], test[:, :2]))
    distances = np.linalg.norm(points[:, None] - points[None, :], axis=2)
    np.fill_diagonal(distances, np.inf)
    minimum = float(distances.min())
    assert minimum > 0
    with plt.rc_context({'font.family': 'serif', 'font.serif': ['Georgia', 'Times New Roman', 'DejaVu Serif'], 'svg.fonttype': 'none'}):
        fig = plt.figure(figsize=(10.2, 7.6), facecolor='white')
        ax = fig.add_axes([.07, .09, .65, .84])
        ax.set_aspect('equal')
        outer = 4 * np.sin(np.deg2rad(45))
        limit = outer * 1.19
        ax.set_xlim(-limit, limit); ax.set_ylim(-limit, limit)
        ax.axis('off')
        angles = np.linspace(0, 2*np.pi, 361)
        for theta in (5, 10, 20, 30, 45):
            radius = 4 * np.sin(np.deg2rad(theta))
            ax.plot(radius*np.cos(angles), radius*np.sin(angles), color='#d5d9df', lw=.8, zorder=1)
        for phi in range(0, 360, 45):
            angle = np.deg2rad(phi)
            ax.plot([0, outer*np.cos(angle)], [0, outer*np.sin(angle)], color='#e4e7eb', lw=.7, zorder=1)
            ax.text(outer*1.105*np.cos(angle), outer*1.105*np.sin(angle), f'{phi}°', ha='center', va='center', fontsize=11)
        ax.scatter(train[:, 0], train[:, 1], s=17, color='#2166ac', edgecolor='white', linewidth=.5, zorder=3)
        ax.scatter(test[:, 0], test[:, 1], s=17, facecolor='white', edgecolor='#c65d13', linewidth=1.1, zorder=4)
        # The marker footprint is smaller than the closest pair in the actual projection.
        pixels_per_unit = fig.get_figwidth()*fig.dpi*.65/(2*limit)
        marker_diameter_px = (np.sqrt(17)+1.1)*fig.dpi/72
        assert minimum*pixels_per_unit > marker_diameter_px
        info = fig.add_axes([.76, .12, .23, .79]); info.axis('off')
        info.scatter([.04], [.94], s=25, color='#2166ac', transform=info.transAxes)
        info.text(.13, .94, f'Train · {len(train)}' if has_center else 'Preservation · 40', va='center', fontsize=12, transform=info.transAxes)
        info.scatter([.04], [.865], s=25, facecolor='white', edgecolor='#c65d13', linewidth=1.2, transform=info.transAxes)
        info.text(.13, .865, 'Test · 40', va='center', fontsize=12, transform=info.transAxes)
        if not has_center:
            ax.scatter([0],[0],s=25,color='#30343b',marker='D',zorder=5)
            info.scatter([.04],[.795],s=25,color='#30343b',marker='D',transform=info.transAxes)
            info.text(.13,.795,'Measured center',va='center',fontsize=11,transform=info.transAxes)
        info.text(0, .75 if has_center else .70, 'Top view (+Z)\nR = 4\nRadial distance = R sin θ\nφ: +X to +Y', fontsize=11, linespacing=1.7, va='top', transform=info.transAxes)
        info.text(0, .50, 'Ring θ       XY radius', fontsize=11, transform=info.transAxes)
        for i, theta in enumerate((0, 5, 10, 20, 30, 45)):
            info.text(0, .445-i*.052, f'{theta:>2}°              {4*np.sin(np.deg2rad(theta)):.3f}', fontsize=11, transform=info.transAxes)
        info.text(0, .055, 'Train φ: 0° + 45°k\nTest φ: 22.5° + 45°k\n'+('Center: train only' if has_center else 'Center: measured only'), fontsize=10.5, linespacing=1.6, transform=info.transAxes)
        fig.savefig(output / 'spherical_sampling_top_view.svg')
        fig.savefig(output / 'spherical_sampling_top_view.png', dpi=150)
        plt.close(fig)
    (output / 'spherical_sampling_diagram_checks.json').write_text(json.dumps({'train_count':len(train),'measured_center_count':0 if has_center else 1, 'test_count':40, 'source':'recorded condition.json train_xyz/evaluation_xyz', 'projection':'XY, view from +Z; radius=4 sin(theta)', 'minimum_projected_dot_distance':minimum, 'marker_overlap_check':True, 'all_active_samples_same_coordinates':True, 'test_used_for_optimization_or_stopping':False}, indent=2)+'\n', encoding='utf-8')
    return f'<section id="spherical-sampling"><h2>Spherical lighting · top view</h2><figure style="margin:0;max-width:1020px"><img src="spherical_sampling_top_view.svg" alt="Top view: {len(train)} blue training lights, 40 orange outlined test lights; concentric rings at polar angles 5, 10, 20, 30 and 45 degrees" width="1020" height="760" style="display:block;width:100%;height:auto"><figcaption>Preservation/train: {len(train)} · Measured center: {0 if has_center else 1} · Test: 40 · XY projection · test는 최적화·종료 판정에 미사용</figcaption></figure></section>'


if __name__ == '__main__':
    sampling_diagram(Path('artifacts/spherical_refinement_20261007'))
