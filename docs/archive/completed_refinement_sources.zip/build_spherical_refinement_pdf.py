"""Static PDF export: run --plots-only with matplotlib, then default with reportlab."""
import argparse
import json
from pathlib import Path

ROOT = Path('artifacts/spherical_refinement_20261007')
SCRATCH = Path('tmp/pdfs/spherical_refinement')
OUTPUT = Path('output/pdf/spherical_refinement_20261007.pdf')


def records():
    result = []
    summary=json.loads((ROOT/'summary.json').read_text(encoding='utf-8'))
    active=summary['plan']['active_samples']
    assert {r['sample'] for r in summary['samples']}==set(active)
    for name in active:
        path=ROOT/name/'metrics.json'
        sample = json.loads(path.read_text(encoding='utf-8'))
        sample['conditions'] = [json.loads((path.parent/c['condition_path']).read_text(encoding='utf-8')) for c in sample['conditions']]
        result.append(sample)
    assert len(result) == 3 and sum(len(r['conditions']) for r in result) == 3
    return result


def plots(data):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    SCRATCH.mkdir(parents=True, exist_ok=True)
    palette=matplotlib.colormaps['viridis']([i/127 for i in range(128)])[:,:3].tolist()
    (SCRATCH/'viridis_rgb.json').write_text(json.dumps(palette),encoding='utf-8')
    plt.rcParams.update({'font.size':10, 'axes.labelsize':10, 'axes.titlesize':11, 'legend.fontsize':9})
    colors = ['#0072B2','#D55E00','#009E73','#CC79A7','#E69F00','#444444']
    styles = ['-','--','-.',':',(0,(5,1)),(0,(3,1,1,1))]
    for record in data:
        name = record['sample']
        fig, axes = plt.subplots(2,2,figsize=(7.2,7.4))
        for index,c in enumerate(record['conditions']):
            tr = c['trajectory'];steps = [t['step'] for t in tr]
            label = 'Joint 41' if c['theta_deg']=='joint' else f"theta {c['theta_deg']} deg"
            args = dict(color=colors[index],linestyle=styles[index],linewidth=1.2,label=label)
            axes[0,0].semilogy(steps,[max(t['train_mse'],1e-30) for t in tr],**args)
            if c['theta_deg'] != 0:
                axes[0,1].semilogy(steps,[max(t['common_heldout_mse'],1e-30) for t in tr],**args)
            axes[1,0].plot(steps,[t['map_mae_physical']['normal_angular_mean_deg'] for t in tr],**args)
            # d/r both use physical [0,1] units; mark their line styles explicitly.
            axes[1,1].plot(steps,[t['map_mae_physical']['diffuse'] for t in tr],color=colors[index],linewidth=1.1)
            axes[1,1].plot(steps,[t['map_mae_physical']['roughness'] for t in tr],color=colors[index],linewidth=1.1,linestyle='--')
        for ax,title,ylabel in zip(axes.flat,('Training directions','Unused azimuth directions','Normal change from original','Diffuse / roughness change'),('Mean squared RGB difference','Mean squared RGB difference','Mean angle (degrees)','Mean absolute physical difference')):
            ax.set_title(title);ax.set_xlabel('Update');ax.set_ylabel(ylabel);ax.grid(alpha=.2)
        handles,labels=axes[0,0].get_legend_handles_labels()
        fig.legend(handles,labels,loc='upper center',bbox_to_anchor=(.5,.995),ncol=3,frameon=False)
        axes[1,1].set_title('Diffuse solid / roughness dashed',fontsize=10)
        fig.tight_layout(rect=(0,0,1,.92),pad=1.2)
        fig.savefig(SCRATCH/f'{name}_response.png',dpi=200);plt.close(fig)
        fig,axes = plt.subplots(2,3,figsize=(7.2,6.4),layout='constrained')
        for index,c in enumerate(record['conditions']):
            tr=c['trajectory'];steps=[t['step'] for t in tr]
            for column,key in enumerate(('n','d','r')):
                for row,field in enumerate(('gradient_rms_raw','update_mean_abs_raw')):
                    entries=tr if row==0 else tr[1:]
                    values=[t[field][key] if t[field][key]>0 else float('nan') for t in entries]
                    axes[row,column].semilogy([t['step'] for t in entries],values,color=colors[index],linestyle=styles[index],linewidth=1.05)
        for column,key in enumerate(('Normal n','Diffuse d','Roughness r')):
            for row in range(2):
                axes[row,column].set_title(key);axes[row,column].set_xlabel('Update');axes[row,column].grid(alpha=.2)
        axes[0,0].set_ylabel('Raw gradient RMS');axes[1,0].set_ylabel('Mean absolute raw update')
        fig.savefig(SCRATCH/f'{name}_optimizer.png',dpi=200);plt.close(fig)


def build_pdf(data):
    from io import BytesIO
    from PIL import Image
    from reportlab.pdfgen import canvas
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.colors import HexColor, Color, white
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import Paragraph, Table, TableStyle
    from reportlab.lib.styles import ParagraphStyle
    from xml.sax.saxutils import escape

    OUTPUT.parent.mkdir(parents=True,exist_ok=True)
    pdfmetrics.registerFont(TTFont('KR','C:/Windows/Fonts/malgun.ttf'))
    pdfmetrics.registerFont(TTFont('KR-Bold','C:/Windows/Fonts/malgunbd.ttf'))
    W,H=A4;M=38;BODY=W-2*M;page=0;total=2+sum(len(r['conditions'])+2 for r in data)
    pdf=canvas.Canvas(str(OUTPUT),pagesize=A4,pageCompression=1)
    pdf.setTitle('구면 조명 F0=0.04 refinement - 전체 결과');pdf.setAuthor('NFPLight research report')
    ink=HexColor('#1e293b');muted=HexColor('#475569');accent=HexColor('#126b86')
    style=ParagraphStyle('body',fontName='KR',fontSize=10.5,leading=16,textColor=ink)

    def text(x,y,s,size=10,font='KR',color=ink):
        assert M-2<=x<=W-M+2 and 30<=y<=H-28,(x,y,s)
        pdf.setFont(font,size);pdf.setFillColor(color);pdf.drawString(x,y,s)

    def paragraph(s,y,width=BODY,size=10.5):
        local=ParagraphStyle('local',parent=style,fontSize=size,leading=size*1.5)
        p=Paragraph(escape(s),local);_,height=p.wrap(width,H)
        assert y-height>=45,(s,y,height)
        p.drawOn(pdf,M,y-height);return y-height-10

    def start(title,subtitle='',bookmark=None):
        nonlocal page
        if page:pdf.showPage()
        page+=1
        text(M,H-35,'NFPLight  |  Spherical lighting / Fixed F0',9,color=muted)
        text(M,H-66,title,18,'KR-Bold')
        if subtitle:text(M,H-88,subtitle,10,color=muted)
        pdf.setStrokeColor(HexColor('#cbd5e1'));pdf.line(M,42,W-M,42)
        text(M,27+8,'2026-10-07  |  종료 상태 기준 / original pred 대비 차이',8,color=muted)
        pdf.setFont('KR',8);pdf.drawRightString(W-M,35,f'{page} / {total}')
        if bookmark:
            pdf.bookmarkPage(bookmark);pdf.addOutlineEntry(title,bookmark,level=0)

    def table(rows,top,widths,font_size=9,spans=()):
        tbl=Table(rows,colWidths=widths,rowHeights=23)
        commands=[('FONTNAME',(0,0),(-1,-1),'KR'),('FONTSIZE',(0,0),(-1,-1),font_size),('TEXTCOLOR',(0,0),(-1,-1),ink),('BACKGROUND',(0,0),(-1,0),HexColor('#e8f0f3')),('FONTNAME',(0,0),(-1,0),'KR-Bold'),('VALIGN',(0,0),(-1,-1),'MIDDLE'),('LINEBELOW',(0,0),(-1,0),.6,accent),('LINEBELOW',(0,1),(-1,-1),.3,HexColor('#d6dde3')),('LEFTPADDING',(0,0),(-1,-1),6),('RIGHTPADDING',(0,0),(-1,-1),4)]
        commands += [('SPAN',(0,a),(0,b)) for a,b in spans]
        tbl.setStyle(TableStyle(commands));_,height=tbl.wrap(BODY,H)
        assert top-height>=45
        tbl.drawOn(pdf,M,top-height);return top-height-16

    start('구면 조명 · F0=0.04 refinement','3개 sample / 공동 41광원 / FP32 결과',bookmark='summary')
    y=paragraph('원래 pred의 다중 조명 렌더링을 목표로 F0를 고정하고 n/d/r을 조정했다. 표와 지도는 종료 상태이며, 최저 학습 loss 상태를 대신 선택하지 않았다.',H-111)
    rows=[['Sample','구성','step','종료 판정','학습 RGB MSE','미사용 φ MSE']];spans=[]
    for record in data:
        first=len(rows)
        for index,c in enumerate(record['conditions']):
            m=c['metrics'];status='기준 충족' if c['termination']['status']=='stability_criteria_met' else '수렴 미확인'
            rows.append([record['sample'] if index==0 else '', '공동 41' if c['theta_deg']=='joint' else f"θ={c['theta_deg']}°",str(c['termination']['step']),status,f"{m['last_train_mse']:.3g}",'없음' if c['theta_deg']==0 else f"{m['last_common_heldout_mse']:.3g}"])
        if len(rows)-first>1:spans.append((first,len(rows)-1))
    y=table(rows,y,[113,63,38,79,113,BODY-406],8.5,spans)
    y=paragraph('260818_174845_478, 260818_175005_078, 260930_152732_008만 refinement 대상이다. 사용자의 대상 판정에 따라 보고서 범위를 재구성했다. 수치 실험을 다시 실행하거나 결과 값을 바꾸지 않았다.',y)
    y=paragraph('세 sample 모두 공동 41광원 구성으로 각각 400회, 1,300회, 1,000회에서 합의한 안정화 기준을 충족했다. 조건별 종료 맵과 원래 pred 대비 변화, 모든 step의 dynamics와 gradient를 수록했다.',y)
    paragraph('원래 pred는 GT가 아니다. 렌더링 차이 감소는 재질 정확도 향상을 뜻하지 않는다. 샘플별 q가 다르므로 절대 loss로 샘플 간 성능을 비교하지 않는다.',y)

    start('실험 규약과 PDF 읽는 방법','수치 조건 유지 / 슬라이더 대신 정적 지도와 전체 step 곡선',bookmark='method')
    y=H-115
    sections=[('광원과 좌표','R=4인 구면에서 θ=0°, 5°, 10°, 20°, 30°, 45°를 사용했다. θ는 +Z축 기준이며 φ는 +X에서 +Y 방향이다. θ>0°에서 φ=0°, 45°, …, 315°의 8개 위치, θ=0°는 중앙 1개 위치로 총 41개다. 표면은 z=0의 [-1,1]² 영역이고 카메라는 (0,0,4)다. 픽셀마다 입사·시선·half-vector 방향은 다르다.'),
              ('목표와 최적화','목표 영상은 원래 pred를 동일한 조명에서 렌더링한 unclipped RGB다. 41개 위치의 RGB·픽셀 평균 제곱 차이를 사용한다. 8개씩 gradient를 누적하고 전체 41개 평균으로 정규화한 뒤 Adam을 한 번 갱신한다. 균일 solid-angle 적분이나 GGX importance sampling은 아니다.'),
              ('고정값과 평가','F0=0.04, Adam lr=0.01, seed=0, FP32이며 AMP·TF32를 사용하지 않았다. q는 원래 중심 렌더링과 I_N의 pixel mean RGB에 맞춰 한 번 산정하고 고정했다. I_N은 refinement loss에 포함하지 않았다. 평가 φ는 22.5° offset이며 gradient와 종료 판정에서 제외했다. θ=0°에는 독립 평가 방향이 없다.'),
              ('종료 기준','최소 300회, 최대 3,000회 실행하고 100회마다 판정했다. 최근 100 updates의 loss 변동폭/평균 ≤0.001, 구간 시작·끝의 평균 normal 각도 ≤0.001°, d/r 평균 절대 차이 각각 ≤0.00001을 모두 만족해야 한다. Loss가 평탄해져도 맵이 계속 변하면 수렴 미확인이다.'),
              ('지도와 변화량','각 조건 페이지는 원래 n/d/r/s, 종료 n/d/r/s, 원래 pred 대비 변화 영상의 세 행이다. Normal 변화는 atan2 기반 각도(도)다. d/s는 단일 signed RGB, r은 signed grayscale이며 중간 회색이 0이다. Δs는 F0 고정에 따른 변화이고 최적화 중 변하지 않는다. 지도 d/s만 gamma 2.2로 표시하며 변화 영상에는 gamma를 적용하지 않았다.'),
              ('범례·곡선·검증','조건별 범위는 저장한 FP32 시점의 최대값으로 정하고 시간 동안 고정했다. 조건·샘플 간 색 강도를 직접 비교하지 않는다. PDF 지도는 원래·종료 lossless WebP에서 가져왔다. Dynamics 곡선은 모든 step의 수치 기록을 사용한다. 샘플별 곡선의 색은 동일한 θ를 나타내며 raw gradient는 파라미터화에 의존한다.')]
    for title,body in sections:
        text(M,y,title,11.5,'KR-Bold',accent);y-=14;y=paragraph(body,y,size=10)-8
    paragraph('자료: artifacts/spherical_refinement_20261007의 condition.json, metrics.json, plan.json. 입력은 정합 게이트에 따른 평균 또는 near_00/far_00 선택과 both 광도 보정을 유지한 새 FP32 추론이다. 저자 원본 net_g_real.pth를 사용했다.',y,size=9.5)

    def map_row(image,title,labels,y):
        text(M,y,title,11.5,'KR-Bold');y-=20
        gap=8;tile=(BODY-3*gap)/4
        for i,label in enumerate(labels):
            x=M+i*(tile+gap);text(x,y,label,9.5,color=muted)
            pdf.drawImage(ImageReader(image.crop((i*256,0,(i+1)*256,256))),x,y-12-tile,width=tile,height=tile)
        return y-12-tile-25

    for record in data:
        sample=record['sample'];folder=ROOT/sample
        for index,c in enumerate(record['conditions']):
            label='공동 41광원' if c['theta_deg']=='joint' else f"θ={c['theta_deg']}° / φ {c['train_light_count']}방향"
            status='안정화 기준 충족' if c['termination']['status']=='stability_criteria_met' else '수렴 미확인'
            start(sample,f"{label}  |  종료 step {c['termination']['step']}  |  {status}",bookmark=sample if index==0 else None)
            text(M,H-108,f"q={record['lamp_intensity']['q']:.6g} 고정  |  F0=0.04  |  n/d/r 최적화",9.5,color=muted)
            with Image.open(folder/'original.webp') as im: original=im.copy()
            with Image.open(folder/c['frames'][-1]['path']) as im: terminal=im.copy()
            y=map_row(original.crop((0,0,1024,256)),'원래 pred',['Normal n','Diffuse d','Roughness r','Specular s'],H-140)
            y=map_row(terminal.crop((0,0,1024,256)),'종료 맵',['Normal n','Diffuse d','Roughness r','F0=0.04'],y)
            y=map_row(terminal.crop((0,256,1024,512)),'원래 pred 대비 변화',['Normal 각도 변화','Δdiffuse · RGB','Δroughness · Gray','Δspecular · RGB'],y)
            scales=c['display_scales'];gap=8;tile=(BODY-3*gap)/4
            stops=json.loads((SCRATCH/'viridis_rgb.json').read_text(encoding='utf-8'))
            for i,color in enumerate(stops):
                pdf.setFillColor(Color(*color));pdf.rect(M+i*tile/len(stops),y+7,tile/len(stops)+.05,7,fill=1,stroke=0)
            text(M,y-5,'0°',9);pdf.setFont('KR',9);pdf.drawRightString(M+tile,y-5,f"{scales['normal']:.3g}°")
            for i,key in enumerate(('diffuse','roughness','specular'),1):
                text(M+i*(tile+gap),y+5,f"±{scales[key]:.4g}",9)
            text(M,y-25,'변화 RGB/Gray: 0.5 + Δ/(2M). 회색=0; 범위 ±M은 위에 표시.',9)
            m=c['metrics'];change=m['last_map_mae_physical']
            values=[f"{m['initial_train_mse']:.3g}",f"{m['last_train_mse']:.3g}",'없음' if c['theta_deg']==0 else f"{m['last_common_heldout_mse']:.3g}",f"{change['normal_angular_mean_deg']:.3g}°",f"{change['diffuse']:.3g}",f"{change['roughness']:.3g}"]
            table([['학습 초기','학습 종료','미사용 φ','평균 Δn','평균 |Δd|','평균 |Δr|'],values],y-38,[BODY/6]*6,8.5)
        start(sample+' · dynamics','모든 step의 수치 기록 / 원래 pred 대비 변화')
        pdf.drawImage(str(SCRATCH/f'{sample}_response.png'),M,172,width=BODY,height=BODY*7.4/7.2)
        y=140
        y=paragraph('학습·평가 차이는 unclipped RGB MSE다. Normal은 평균 각도(도), d/r은 물리값의 평균 절대 차이다. θ별 조건은 서로 다른 조명 목표를 사용하므로 θ 간 loss 순위를 재질 정확도로 해석하지 않는다.',y,size=10)
        observations={
            '260818_174845_478':'지도 관찰: diffuse 변화에 대각선 직조 대비가 남고 roughness는 넓은 영역에서 감소 방향으로 변한다.',
            '260818_175005_078':'지도 관찰: 붉은 격자·대각선 직조 형태가 유지되며 normal 변화는 상단·경계에서 더 뚜렷하다.',
            '260923_141241_844':'θ=45° 지도 관찰: normal 변화는 외곽·직조에 나타나며 roughness 변화에는 중앙과 주변의 대비가 나타난다.',
            '260923_161825_503':'θ=45° 지도 관찰: normal·roughness 변화가 글자 무늬를 따라 집중된다. 실제 재질 정확도에 대한 판정은 아니다.',
            '260930_152732_008':'지도 관찰: 줄무늬·직조가 유지되고 diffuse·roughness 변화에도 구조가 나타난다. 평균 normal 변화는 0.163°다.'}
        paragraph(observations[sample],y,size=10)
        start(sample+' · gradient / update','위: raw gradient RMS / 아래: 실제 projected Adam 평균 절대 업데이트')
        legend='공동 41광원' if record['mode']=='joint' else '곡선 색: 0° 파랑 / 5° 주황 / 10° 초록 / 20° 자주 / 30° 노랑 / 45° 회색'
        text(M,H-110,legend,9.3,color=muted)
        pdf.drawImage(str(SCRATCH/f'{sample}_optimizer.png'),M,240,width=BODY,height=BODY*6.4/7.2)
        rows=[['그룹','공동 gradient / ring 최대','첫 공동 update / ring 최대']]
        for key,v in record['initial_gradient_check'].items():
            if key!='fallback_required':rows.append([key,f"{v['joint_gradient_to_max_ring']:.3f}",f"{v['joint_update_to_max_ring']:.3f}"])
        y=table(rows,214,[BODY*.18,BODY*.41,BODY*.41],9)
        paragraph('표는 같은 초기 맵에서의 비교이며 θ별 종료 결과와 비교한 값이 아니다. Raw gradient는 파라미터화·q에 의존한다. Step 0에는 아직 업데이트가 없어 하단에서 제외했다. Log 축의 실제 0은 표시하지 않는다. F0 gradient·업데이트는 전 step에서 0이다.',y,size=10)
    assert page==total,(page,total)
    pdf.save()
    print(f'PDF_CREATED pages={page} bytes={OUTPUT.stat().st_size} path={OUTPUT.resolve()}')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--plots-only',action='store_true');args=parser.parse_args()
    data=records()
    if args.plots_only:plots(data)
    else:build_pdf(data)
