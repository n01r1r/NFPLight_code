"""Run the fixed-camera rendering-loss analysis for the five reviewed samples."""

from __future__ import annotations

import argparse
import json
import os
import platform
import shutil
import sys
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from capture_processing.prediction_refinement import estimate_lamp_intensity
from capture_processing.rendering_loss_analysis import (
    CAMERA_XYZ,
    END_MARKER,
    F0_PHYSICAL,
    START_MARKER,
    analyze_condition,
    build_analysis_index,
    build_analysis_section,
    build_common_heldout_lights,
    build_light_regimes,
    build_scan_lights,
    insert_analysis_section,
    physical_maps,
    validate_analysis_links,
)
from model.author_real_capture_adapter import AuthorRealCaptureAdapter
from run_fabric_capture import CAPTURE_GROUPS
from run_prediction_refinement import reconstruct_selected_pair
from utils.render_util import svBRDF


SAMPLES = tuple(CAPTURE_GROUPS)
REFRESH_ROOT = Path("artifacts/fabric_capture_20261002_aligned_paper_equations")
CHECKPOINT = Path("checkpoints/net_g_real.pth")
DEFAULT_OUTPUT = Path("artifacts/rendering_loss_analysis_20261006")


def _json(path: Path, value: object) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding="utf-8")


def _load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def _file_stat(path: Path) -> dict[str, int]:
    value = path.stat()
    return {"size_bytes": int(value.st_size), "mtime_ns": int(value.st_mtime_ns)}


def _make_renderer(device: torch.device):
    renderer = svBRDF()
    surface = renderer.surface(256, range=1, dtype=torch.float32, device=device)
    camera = torch.tensor([CAMERA_XYZ], dtype=torch.float32, device=device)

    def render(material: torch.Tensor, lights: torch.Tensor, intensity: float) -> torch.Tensor:
        if material.dtype != torch.float32 or lights.dtype != torch.float32:
            raise TypeError("analysis renderer requires FP32 inputs")
        light, view, distance, _ = renderer.torch_generate(camera, lights, surface=surface)
        renderer.lampIntensity = float(intensity)
        return renderer._render(material, light, view, distance)

    return render


def _uint8(array: np.ndarray) -> np.ndarray:
    return np.rint(np.clip(array, 0.0, 1.0) * 255.0).astype(np.uint8)


def _save_image(path: Path, array: np.ndarray) -> None:
    if array.shape[0] == 1:
        array = np.repeat(array, 3, axis=0)
    Image.fromarray(_uint8(np.transpose(array[:3], (1, 2, 0))), mode="RGB").save(path)


def _save_maps(folder: Path, stage: str, material: torch.Tensor) -> None:
    maps = physical_maps(material)
    for name, value in maps.items():
        array = value.detach().cpu().float().numpy()[0]
        if name == "normal":
            array = (array + 1.0) * 0.5
        _save_image(folder / f"map_{stage}_{name}.png", array)
        if name in {"diffuse", "specular"}:
            _save_image(folder / f"map_{stage}_{name}_gamma22.png", np.power(np.clip(array, 0.0, 1.0), 1.0 / 2.2))


def _save_render(path: Path, rendered: torch.Tensor) -> None:
    array = rendered.detach().cpu().float().numpy()[0]
    _save_image(path, array)
    _save_image(path.with_name(path.stem + "_gamma22.png"), np.power(np.clip(array, 0.0, 1.0), 1.0 / 2.2))


def _plot_curve(path: Path, trajectory: list[dict]) -> bool:
    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except Exception:
        Image.new("RGB", (900, 600), "#202020").save(path)
        return False
    steps = [item["step"] for item in trajectory]
    figure, axes = plt.subplots(2, 2, figsize=(11, 7), constrained_layout=True)
    axes[0, 0].plot(steps, [item["train_mse"] for item in trajectory], label="train MSE")
    axes[0, 0].plot(steps, [item["common_heldout_mse"] for item in trajectory], label="common held-out MSE")
    axes[0, 0].set_yscale("symlog", linthresh=1e-12)
    axes[0, 0].set_title("rendering loss")
    axes[0, 0].legend()
    for name in ("n", "d", "r", "s"):
        axes[0, 1].plot(steps, [item["gradient_rms_raw"][name] for item in trajectory], label=name)
    axes[0, 1].set_yscale("symlog", linthresh=1e-12)
    axes[0, 1].set_title("raw-map gradient RMS")
    axes[0, 1].legend()
    for name in ("normal", "diffuse", "roughness", "specular"):
        axes[1, 0].plot(steps, [item["map_mae_physical"][name] for item in trajectory], label=name)
    angle_axis = axes[1, 0].twinx()
    angle_axis.plot(steps, [item["map_mae_physical"]["normal_angular_mean_deg"] for item in trajectory], color="black", linestyle="--", label="normal angle [deg]")
    axes[1, 0].set_title("physical map MAE vs original; angle on right axis")
    axes[1, 0].set_ylabel("physical map MAE")
    angle_axis.set_ylabel("normal angle [deg]")
    axes[1, 0].legend(fontsize=8)
    for name in ("n", "d", "r", "s"):
        axes[1, 1].plot(steps, [item["update_mean_abs_raw"][name] for item in trajectory], label=name)
    axes[1, 1].set_yscale("symlog", linthresh=1e-12)
    axes[1, 1].set_title("raw-map update mean absolute")
    axes[1, 1].legend()
    for axis in axes.flat:
        axis.set_xlabel("step")
        axis.grid(alpha=0.2)
    figure.savefig(path, dpi=120)
    plt.close(figure)
    return True


def _scan_metrics(
    render,
    prediction: torch.Tensor,
    condition: dict,
    scan_lights: dict[str, torch.Tensor],
    q: float,
) -> dict[str, dict[str, float]]:
    result = {}
    with torch.no_grad():
        for radius, lights in scan_lights.items():
            teacher = render(prediction, lights, q)
            values = {}
            for stage in ("initial", "best", "last"):
                values[stage] = float(torch.nn.functional.mse_loss(render(condition[stage], lights, q), teacher))
            result[radius] = values
    return result


def _serial_condition(result: dict, scan: dict) -> dict:
    return {
        "regime": result["regime"],
        "mode": result["mode"],
        "train_light_count": result["train_light_count"],
        "lamp_intensity": result["lamp_intensity"],
        "steps": result["steps"],
        "lr": result["lr"],
        "seed": result["seed"],
        "best_step": result["best_step"],
        "metrics": result["metrics"],
        "scan_mse": scan,
        "trajectory": result["trajectory"],
        "contract": {
            "loss": "mean unclipped rendering MSE across B,L,C,H,W",
            "mse_aggregation": "arithmetic mean across all batch, light, channel, and pixel terms; center has one light",
            "optimized_raw_groups": ["n", "d", "r", "s"] if result["mode"] == "free" else ["n", "d", "r"],
            "normal": "raw n passed to renderer normalization; zero normals rejected",
            "diffuse": "raw d projected to [-1,1]",
            "roughness": "raw r projected to [-.9,1], renderer effective floor .05",
            "specular": "raw s projected to [-1,1]; fixed mode s=-.92 (physical F0=.04)",
            "fixed_specular_gradient_rms": result["metrics"]["fixed_specular_gradient_rms"],
        },
    }


def _run_condition(
    output: Path,
    sample: str,
    regime: str,
    mode: str,
    result: dict,
    render,
    prediction: torch.Tensor,
    scan_lights: dict[str, torch.Tensor],
    q: float,
) -> dict:
    folder = output / sample / regime / mode
    folder.mkdir(parents=True, exist_ok=False)
    scan = _scan_metrics(render, prediction, result, scan_lights, q)
    condition_record = _serial_condition(result, scan)
    _save_maps(folder, 'original', prediction)
    for stage, material in (("step0", result["initial"]), ("best", result["best"]), ("last", result["last"])):
        _save_maps(folder, stage, material)
        with torch.no_grad():
            stage_render = render(material, build_light_regimes(material.device)[regime][:1], q)
        _save_render(folder / f"render_{stage}.png", stage_render[:, 0])
    with torch.no_grad():
        teacher_render = render(prediction, build_light_regimes(prediction.device)[regime][:1], q)
    _save_render(folder / "render_teacher.png", teacher_render[:, 0])
    curve = _plot_curve(folder / "loss_curve.png", result["trajectory"])
    condition_record["curve_png"] = bool(curve)
    _json(folder / "condition.json", condition_record)
    return condition_record


def _write_sample_report(output: Path, sample: str, record: dict) -> None:
    from revise_fixed_f0_report import plot_comparison
    plot_comparison(record, output)
    section = build_analysis_section(sample, record, "..")
    page = (
        "<!doctype html><html lang=\"en\"><meta charset=\"utf-8\"><title>Rendering loss analysis</title>"
        "<style>body{background:#111;color:#ddd;font:14px Arial;margin:10px}main{max-width:1800px;margin:auto}"
        ".technical{background:#181818;padding:8px;border:1px solid #555}.case-row{display:flex;gap:12px;overflow-x:auto;padding:5px}"
        ".case-label{min-width:210px}.case-tiles{display:flex;gap:8px}.case-tile{margin:0;min-width:150px}.case-tile img{width:150px;height:150px;object-fit:contain;background:#222}.case-tile figcaption{font-size:11px}</style>"
        f"<main><h1>Rendering loss analysis · {sample}</h1>{START_MARKER}{section}{END_MARKER}</main></html>"
    )
    (output / sample / "report.html").write_text(page, encoding="utf-8")


def _integrate_reports(output: Path, records: list[dict]) -> dict:
    backup_dir = output / "backups"
    backup_dir.mkdir(parents=True, exist_ok=True)
    checks = []
    for record in records:
        sample = record["sample"]
        refresh_dir = REFRESH_ROOT / sample / "refresh_20261006"
        artifact_base = os.path.relpath(output, refresh_dir).replace("\\", "/")
        section = build_analysis_section(sample, record, artifact_base)
        for page, label in ((refresh_dir / "report.html", "refresh"), (refresh_dir.parent / "report.html", "root")):
            backup = backup_dir / f"{sample}_{label}_report.html"
            shutil.copyfile(page, backup)
            text = page.read_text(encoding="utf-8")
            updated = insert_analysis_section(text, section)
            page.write_text(updated, encoding="utf-8")
            block = updated[updated.index(START_MARKER): updated.index(END_MARKER) + len(END_MARKER)]
            checks.extend(f"{page}: {error}" for error in validate_analysis_links(block, refresh_dir))
    index = REFRESH_ROOT / "index.html"
    shutil.copyfile(index, backup_dir / "index.html")
    index_text = index.read_text(encoding="utf-8")
    index_section = build_analysis_index(records, os.path.relpath(output, REFRESH_ROOT).replace("\\", "/"))
    updated_index = insert_analysis_section(index_text, index_section)
    index.write_text(updated_index, encoding="utf-8")
    return {"missing_links": checks, "backups": str(backup_dir.resolve()), "sha256_executed": False}


def _plan(args: argparse.Namespace, samples: list[str]) -> dict:
    return {
        "format": "nfplight.rendering-loss-analysis-plan.v1",
        "samples": samples,
        "checkpoint": str(CHECKPOINT),
        "precision": "FP32",
        "amp": False,
        "tf32": False,
        "seed": int(args.seed),
        "steps": int(args.steps),
        "lr": float(args.lr),
        "camera_xyz": list(CAMERA_XYZ),
        "light_z": 4.0,
        "regimes": {
            "center": [[0.0, 0.0, 4.0]],
            "small": [[0.0, 0.0, 4.0], [0.25, 0.0, 4.0], [-0.25, 0.0, 4.0], [0.0, 0.25, 4.0], [0.0, -0.25, 4.0]],
            "wide": [[0.0, 0.0, 4.0], [1.5, 0.0, 4.0], [-1.5, 0.0, 4.0], [0.0, 1.5, 4.0], [0.0, -1.5, 4.0]],
        },
        "modes": {
            "fixed": "optimize raw n/d/r; s physical F0=.04 raw=-.92 frozen",
        },
        "loss": "mean unclipped rendering MSE to detached original raw prediction teacher; no prior, smoothing, perturbation, or real image objective",
        "common_heldout": "eight diagonal z=4 lights at radii .75 and 1.25",
        "scan": "center plus cardinal and diagonal lights at radii 0,.25,.75,1.5",
        "geometry": "dimensionless surface [-1,1], fixed camera (0,0,4), light z=4, renderer svBRDF",
        "q": "fit once from original prediction unit center-near render to I_N scalar mean RGB on valid unsaturated support; frozen for all modes/regimes",
    }


def run(args: argparse.Namespace) -> Path:
    samples = list(SAMPLES if args.all_groups else [args.sample])
    output = Path(args.out_dir)
    if output.exists():
        raise FileExistsError(f"refusing to overwrite artifact directory: {output}")
    output.mkdir(parents=True)
    _json(output / "plan.json", _plan(args, samples))
    if Path(args.checkpoint).resolve() != CHECKPOINT.resolve():
        raise ValueError("only checkpoints/net_g_real.pth is allowed")
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable")
    if device.type == "cuda":
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    checkpoint_stat_before = _file_stat(CHECKPOINT)
    model = AuthorRealCaptureAdapter(CHECKPOINT, device=str(device))
    print(f"ANALYSIS_START samples={','.join(samples)} device={device} steps={args.steps}", flush=True)
    records = []
    for sample in samples:
        print(f"ANALYSIS_SAMPLE_START sample={sample}", flush=True)
        refresh = REFRESH_ROOT / sample / "refresh_20261006"
        near, far, provenance = reconstruct_selected_pair(sample=sample, refresh=refresh)
        source_before = {
            side: [item["file_stat"] for item in provenance["source_frames"][side]]
            for side in ("near", "far")
        }
        pair = torch.cat((near, far), dim=1).to(device=device, dtype=torch.float32)
        with torch.no_grad():
            prediction, _ = model.infer(pair)
        render = _make_renderer(device)
        regimes = build_light_regimes(device)
        common = build_common_heldout_lights(device)
        scan_lights = build_scan_lights(device)
        with torch.no_grad():
            unit_near = render(prediction, regimes["center"], 1.0)[:, 0]
        observed = near.to(device=device, dtype=torch.float32)
        valid = observed.amax(dim=1) <= 0.95
        lamp = estimate_lamp_intensity(unit_near, observed, valid)
        conditions = {}
        for regime, lights in regimes.items():
            conditions[regime] = {}
            for mode in ("fixed",):
                result = analyze_condition(
                    prediction,
                    render,
                    lights,
                    common,
                    float(lamp["q"]),
                    mode=mode,
                    regime=regime,
                    steps=args.steps,
                    lr=args.lr,
                    seed=args.seed,
                )
                conditions[regime][mode] = _run_condition(
                    output,
                    sample,
                    regime,
                    mode,
                    result,
                    render,
                    prediction,
                    scan_lights,
                    float(lamp["q"]),
                )
                print(f"ANALYSIS_CONDITION_COMPLETE sample={sample} regime={regime} mode={mode}", flush=True)
        source_after = {
            side: [_file_stat(Path(item["path"])) for item in provenance["source_frames"][side]]
            for side in ("near", "far")
        }
        record = {
            "format": "nfplight.rendering-loss-analysis.v1",
            "sample": sample,
            "selection": provenance["selected_frames"],
            "averaged": provenance["averaged"],
            "provenance": provenance,
            "prediction": {
                "shape": list(prediction.shape),
                "dtype": str(prediction.dtype).replace("torch.", ""),
                "min": float(prediction.amin()),
                "max": float(prediction.amax()),
                "mean": float(prediction.mean()),
            },
            "lamp_intensity": lamp,
            "conditions": conditions,
            "preservation_check": {
                "source_frames_unchanged": all(source_after[side] == source_before[side] for side in ("near", "far")),
                "checkpoint_unchanged": _file_stat(CHECKPOINT) == checkpoint_stat_before,
                "sha256_executed": False,
            },
            "environment": {
                "python": sys.version,
                "platform": platform.platform(),
                "torch": torch.__version__,
                "device": str(device),
            },
            "storage": {"numeric_arrays_saved": False, "sha256_executed": False},
            "artifact": str((output / sample).resolve()),
        }
        _json(output / sample / "metrics.json", record)
        _write_sample_report(output, sample, record)
        records.append(record)
        print(f"ANALYSIS_SAMPLE_COMPLETE sample={sample}", flush=True)
    integration = _integrate_reports(output, records)
    summary = {
        "format": "nfplight.rendering-loss-analysis-all.v1",
        "plan": _load_json(output / "plan.json"),
        "samples": records,
        "integration": integration,
        "sha256_executed": False,
    }
    _json(output / "summary.json", summary)
    index_section = build_analysis_index(records, ".")
    (output / "summary.html").write_text(
        "<!doctype html><html lang=\"en\"><meta charset=\"utf-8\"><title>Rendering loss analysis</title>"
        "<style>body{background:#111;color:#ddd;font:14px Arial;margin:10px}main{max-width:1600px;margin:auto}"
        ".technical{background:#181818;padding:8px;border:1px solid #555}table{border-collapse:collapse;width:100%}"
        "th,td{border:1px solid #555;padding:5px;text-align:left}</style><main>" + index_section + "</main></html>",
        encoding="utf-8",
    )
    print(f"ANALYSIS_COMPLETE output={output}", flush=True)
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--sample", choices=SAMPLES, default=SAMPLES[-1])
    parser.add_argument("--all-groups", action="store_true")
    parser.add_argument("--device", default="cuda")
    parser.add_argument("--steps", type=int, default=300)
    parser.add_argument("--lr", type=float, default=0.01)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--checkpoint", default=str(CHECKPOINT))
    parser.add_argument("--out-dir", default=str(DEFAULT_OUTPUT))
    run(parser.parse_args())


if __name__ == "__main__":
    main()
