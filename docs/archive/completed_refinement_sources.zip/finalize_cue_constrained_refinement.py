"""Audit constrained artifacts and add original/projected/final comparisons."""
import json
import os
from pathlib import Path
import numpy as np
import torch
import run_spherical_refinement as r
from run_cue_constrained_refinement import OUTPUT, PREVIOUS, SOURCE, SAMPLES


def add_constant_comparison():
    """Compare saved 478 variants without inference or numerical changes."""
    from PIL import Image
    from capture_processing.rendering_loss_analysis import validate_analysis_links

    sample = '260818_174845_478'
    variants = [(OUTPUT, 'Diffuse constant / normal·roughness 자유', ['d']),
                (PREVIOUS, 'Diffuse·roughness constant / normal 자유', ['d', 'r'])]
    entries = []
    reference = None
    for root, label, constants in variants:
        target = root/sample/'theta_joint'
        condition = json.loads((target/'condition.json').read_text(encoding='utf-8'))
        record = next(row for row in json.loads((root/'constraint_comparison.json').read_text(encoding='utf-8')) if row['sample'] == sample)
        metadata = json.loads((root/sample/'metrics.json').read_text(encoding='utf-8'))
        assert record['spatial_constants'] == constants
        with np.load(target/'render_materials.npz') as maps, np.load(target/'centered_render_values.npz') as renders:
            identity = (maps['original'].copy(), renders['near'].copy(), condition['train_xyz'], metadata['lamp_intensity']['q'])
            assert maps['updated'].dtype == np.float32 and np.isfinite(maps['updated']).all()
            if reference is not None:
                for current, prior in zip(identity, reference):
                    np.testing.assert_array_equal(current, prior)
            reference = identity
        image_path = OUTPUT/sample/'theta_joint'/('comparison_'+'_'.join(constants)+'.webp')
        with Image.open(root/sample/condition['frames'][-1]['path']) as image:
            image.crop((0, 0, image.width, image.height//2)).save(image_path, lossless=True)
        entries.append((root, label, record, image_path))

    figure_path = OUTPUT/sample/'theta_joint'/'constant_comparison_aligned.png'
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    with plt.rc_context({'font.family': 'Arial', 'font.size': 12}):
        fig, axes = plt.subplots(3, 6, figsize=(15, 8.8))
        fig.subplots_adjust(left=.155, right=.985, top=.88, bottom=.10, wspace=.06, hspace=.12)
        sources = [(OUTPUT, 'Original pretrained', 'original', None)] + [
            (root, label, 'updated', image_path) for root, label, record, image_path in entries]
        headers = ['Normal', 'Diffuse', 'Roughness', 'F0', 'Center render', 'Measured I_N']
        labels = ['Original pretrained',
                  f'Diffuse constant\nNormal / roughness free\n{entries[0][2]["termination"]["step"]:,} steps',
                  f'Diffuse + roughness\nconstant; normal free\n{entries[1][2]["termination"]["step"]:,} steps']
        for row, (root, _, stage, image_path) in enumerate(sources):
            target = root/sample/'theta_joint'
            source = root/sample/'original.webp' if stage == 'original' else image_path
            with Image.open(source) as image:
                assert image.width == 1024 and image.height in (256, 512)
                panels = [image.crop((col*256, 0, (col+1)*256, 256)).copy() for col in range(4)]
            for path in (target/f'center_{stage}.webp', target/'measured_near.webp'):
                with Image.open(path) as image:
                    assert image.size == (256, 256)
                    panels.append(image.copy())
            for col, panel in enumerate(panels):
                axes[row,col].imshow(panel, interpolation='nearest')
                axes[row,col].set_axis_off()
                if row == 0: axes[row,col].set_title(headers[col], fontsize=13, pad=12)
            pos = axes[row,0].get_position()
            fig.text(.018, (pos.y0+pos.y1)/2, labels[row], ha='left', va='center', fontsize=12, linespacing=1.5)
        fig.text(.018, .97, '478 | Constant constraints', fontsize=19, va='top')
        fig.text(.018, .925, 'Same sample, original prediction, target, light intensity and 40 preservation directions', fontsize=11, va='top')
        fig.text(.018, .045, 'Shared display: normal RGB = (unit n + 1)/2; diffuse/F0 = linear value^(1/2.2); roughness = [0,1].\nRender and measured: clip [0,1], gamma 1/2.2. Each panel: 256 x 256 pixels; no per-panel normalization.', fontsize=10, va='center')
        fig.canvas.draw()
        bounds = np.array([[ax.get_position().bounds for ax in row] for row in axes])
        np.testing.assert_allclose(bounds[:,:,2:], np.broadcast_to(bounds[0,0,2:], (3,6,2)), atol=1e-12)
        np.testing.assert_allclose(bounds[:,:,0], np.broadcast_to(bounds[0,:,0], (3,6)), atol=1e-12)
        np.testing.assert_allclose(bounds[:,:,1], np.broadcast_to(bounds[:,0,1,None], (3,6)), atol=1e-12)
        fig.savefig(figure_path, dpi=300)
        fig.savefig(figure_path.with_suffix('.pdf'))
        plt.close(fig)
    r._json(figure_path.with_suffix('.checks.json'), {
        'rows': labels, 'columns': headers, 'equal_panel_size': True,
        'columns_aligned': True, 'rows_aligned': True, 'panel_pixels': [256,256],
        'common_absolute_display_transform': True, 'per_panel_normalization': False,
        'source_identity_checked': True, 'axes_bounds': bounds.tolist(),
    })

    start, end = '<!-- 478-constant-comparison:start -->', '<!-- 478-constant-comparison:end -->'
    pages = [OUTPUT/'summary.html', OUTPUT/sample/'report.html']
    for page in pages:
        def link(path):
            return os.path.relpath(path, page.parent).replace(chr(92), '/')
        section = start+'<section id="478-constant-comparison"><h2>478 · constant 조건 비교</h2><figure style="margin:0"><img src="'+link(figure_path)+'" alt="동일한 여섯 열에 정렬한 원본, diffuse constant, diffuse와 roughness constant 비교" width="4500" height="2640" style="display:block;width:100%;height:auto"><figcaption>모든 행의 열 순서·패널 크기·좌표·표시 변환이 같다. 맵과 렌더링의 개별 자동 정규화는 사용하지 않는다. 공간 상수의 공유 값도 최적화한다.</figcaption></figure><p><a href="'+link(figure_path.with_suffix('.pdf'))+'">정렬된 비교 그림 PDF</a></p><table><tr><th>조건</th><th>Step</th><th>측정 MSE</th><th>보존 MSE</th><th>Total</th></tr>'
        original = entries[0][2]['metrics']['original']
        section += f'<tr><td>원본 pretrained</td><td>—</td><td>{original["measured_mse"]:.7g}</td><td>{original["preservation_mse"]:.7g}</td><td>{original["total_loss"]:.7g}</td></tr>'
        for root, label, record, image_path in entries:
            metric = record['metrics']['updated']
            section += f'<tr><td>{label}</td><td>{record["termination"]["step"]}</td><td>{metric["measured_mse"]:.7g}</td><td>{metric["preservation_mse"]:.7g}</td><td>{metric["total_loss"]:.7g}</td></tr>'
        section += '</table><p>동일 원본 pred·실측 I_N·q·40방향, FP32, F0=.04, I_N MSE + 0.1 × 40방향 보존. 기존 저장 결과를 표시한다.</p>'
        section += '</section>'+end
        text = page.read_text(encoding='utf-8')
        if start in text:
            before, remainder = text.split(start, 1)
            _, after = remainder.split(end, 1)
            text = before+section+after
        else:
            text = text.replace('<h1>', section+'<h1>', 1)
        assert text.count(start) == 1
        assert not validate_analysis_links(text, page.parent)
        page.write_text(text, encoding='utf-8')
        mirrored = PREVIOUS/page.relative_to(OUTPUT)
        base = os.path.relpath(page.parent, mirrored.parent).replace(chr(92), '/')+'/'
        mirrored.write_text(text.replace('<meta charset="utf-8">', f'<meta charset="utf-8"><base href="{base}">', 1), encoding='utf-8')

def main():
    device = torch.device('cuda')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    render = r._make_renderer(device)
    rows = []
    comparisons = []
    for sample, constants in SAMPLES.items():
        target = OUTPUT/sample/'theta_joint'
        c = json.loads((target/'condition.json').read_text(encoding='utf-8'))
        m = json.loads((OUTPUT/sample/'metrics.json').read_text(encoding='utf-8'))
        q = m['lamp_intensity']['q']
        with np.load(target/'render_materials.npz') as a:
            maps = {k: torch.from_numpy(a[k].copy()).to(device) for k in ('original','initial','updated')}
        with np.load(SOURCE/sample/'theta_joint/render_materials.npz') as a:
            np.testing.assert_array_equal(maps['original'].cpu().numpy(), a['original'])
        with np.load(target/'centered_render_values.npz') as a:
            near = torch.from_numpy(a['near'].copy()).to(device)
        manifest = json.loads(Path('artifacts/measured_refinement_20261007_unified/source_manifest.json').read_text(encoding='utf-8'))
        reference = Path(manifest['samples'][sample]['source'])
        ref_metadata = json.loads((reference/sample/'metrics.json').read_text(encoding='utf-8'))
        assert q == ref_metadata['lamp_intensity']['q']
        with np.load(reference/sample/'theta_joint/render_materials.npz') as a:
            np.testing.assert_array_equal(a['original'], maps['original'].cpu().numpy())
            maps['unconstrained_reference'] = torch.from_numpy(a['updated'].copy()).to(device)
        train = torch.tensor(c['train_xyz'], dtype=torch.float32, device=device)
        stats = {}
        with torch.no_grad():
            teacher = render(maps['original'], train, q)
            for key, material in maps.items():
                assert torch.isfinite(material).all() and material.dtype == torch.float32
                center = render(material, r.ring(0,device=device), q)[:,0]
                measured = float((center-near).square().mean())
                preservation = float((render(material,train,q)-teacher).square().mean())
                stats[key] = dict(measured_mse=measured, preservation_mse=preservation, total_loss=measured+.1*preservation)
                r.tile(center[0].clamp(0,1).pow(1/2.2)).save(target/f'center_{key}.webp',lossless=True)
        for key in ('initial','updated'):
            material = maps[key]
            for name, sl in [('n',slice(0,3)),('d',slice(3,6)),('r',slice(6,7))]:
                if name in constants:
                    value = material[:,sl]
                    assert torch.equal(value, value[:,:,:1,:1].expand_as(value))
            assert torch.equal(material[:,7:],torch.full_like(material[:,7:],-.92))
        for key, entry in [('initial', c['trajectory'][0]), ('updated', c['trajectory'][-1])]:
            for metric in ('measured_mse','preservation_mse','total_loss'):
                np.testing.assert_allclose(stats[key][metric],entry[metric],rtol=2e-5,atol=1e-8)
        if sample.endswith('_478') and constants == ('d',):
            for sl in (slice(0,3), slice(6,7)):
                assert torch.equal(maps['initial'][:,sl], maps['original'][:,sl])
                assert not torch.equal(maps['updated'][:,sl], maps['initial'][:,sl])
                value = maps['updated'][:,sl]
                assert not torch.equal(value, value[:,:,:1,:1].expand_as(value))
        comparison = dict(sample=sample, spatial_constants=constants, metrics=stats, termination=c['termination'], exact_constraints=True, original_prediction_identity=True, unconstrained_reference_source=str(reference), reference_comparison='re-evaluated with identical near target, q, FP32 renderer and 40 directions; historical 078 used a different early objective before continuation')
        comparisons.append(comparison)
        r._json(target/'constraint_checks.json',comparison)
        rows.append(f'<h2>{sample}</h2><p>Constants: {", ".join(constants)}; step {c["termination"]["step"]}; {c["termination"]["status"]}</p><table><tr><th>Stage</th><th>Measured MSE</th><th>Preservation MSE</th><th>Total</th></tr>'+''.join(f'<tr><td>{key}</td><td>{v["measured_mse"]:.7g}</td><td>{v["preservation_mse"]:.7g}</td><td>{v["total_loss"]:.7g}</td></tr>' for key,v in stats.items())+'</table><div style="display:flex;gap:12px">'+''.join(f'<figure><figcaption>{key}</figcaption><img width="256" src="{sample}/theta_joint/center_{key}.webp"></figure>' for key in stats)+'</div>')
    prefix='<section><h1>Cue-constrained refinement</h1><p>078: spatially constant normal. 478: spatially constant diffuse RGB; pixelwise free normal and roughness. Shared values optimized. Original pretrained prediction -> constraint projection -> optimization. FP32; fixed F0=.04 and q; I_N MSE + .1 mean40 preservation; fresh Adam .01, max10000.</p><p>Virtual light preservation is not additional measured validation. Constant constraints do not correct geometry or calibration mismatch.</p>'+''.join(rows)+'</section>'
    for page in OUTPUT.rglob('*.html'):
        text=page.read_text(encoding='utf-8').replace('mean41','mean40').replace('min 300 / max 3000','min 300 / max 10000')
        text=text.replace('optimized n/d/r','constrained n/d/r; shared constants optimized')
        text=text.replace('../../output/pdf/measured_spherical_refinement_20261007_lambda01.pdf','../../output/pdf/measured_refinement_20261007_unified.pdf')
        text=text.replace('../../output/pdf/measured_refinement_20261007_unified.pdf', os.path.relpath('output/pdf/measured_refinement_20261007_unified.pdf',page.parent).replace(chr(92),'/'))
        text=text.replace('>PDF</a>', '>이전 무제약 비교 PDF</a>')
        if page.name=='summary.html': text=text.replace('<h1>',prefix+'<h1>',1)
        page.write_text(text,encoding='utf-8')
    summary = json.loads((OUTPUT/'summary.json').read_text(encoding='utf-8'))
    summary['plan'] = json.loads((OUTPUT/'plan.json').read_text(encoding='utf-8'))
    r._json(OUTPUT/'summary.json', summary)
    r._json(OUTPUT/'constraint_comparison.json',comparisons)
    add_constant_comparison()
    from capture_processing.rendering_loss_analysis import validate_analysis_links
    for page in OUTPUT.rglob('*.html'):
        assert not validate_analysis_links(page.read_text(encoding='utf-8'), page.parent)
    checks=json.loads((OUTPUT/'checks.json').read_text(encoding='utf-8'))
    checks.update(html_links_valid=True, exact_spatial_constraints=True, original_prediction_identity=True, loss_recomputation_passed=True)
    r._json(OUTPUT/'checks.json', checks)
    print(json.dumps(comparisons,indent=2))

if __name__=='__main__': main()
