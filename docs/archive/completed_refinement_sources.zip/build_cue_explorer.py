"""Package saved cue experiments into an offline HTML explorer; no optimization."""
from __future__ import annotations

import argparse
import base64
import json
import mimetypes
from pathlib import Path
import sys
import zlib

import numpy as np
import torch

from capture_processing.color_cue import _pool, build_color_cue_context, evaluate_color_cue
from capture_processing.rendering_loss_analysis import physical_maps


ROOT = Path(__file__).resolve().parent
PILOT = ROOT / "artifacts/scale_cue_20261007"
CURRENT = ROOT / "artifacts/scale_cue_10k_20261007"
CURRENT_NAMES = ("baseline", "fullres", "lowpass", "detail", "mixed", "scalespace")
HARD = ROOT / "artifacts/cue_constrained_refinement_20261007"
SAMPLES = ("260818_175005_078", "260818_174845_478")
HISTORICAL = {
    SAMPLES[0]: ROOT / "artifacts/measured_spherical_refinement_20261007_continue10k_40lights",
    SAMPLES[1]: ROOT / "artifacts/measured_spherical_refinement_20261007_fresh478_40lights",
}
LABELS = {"original": "원본 pretrained", "fixed_initial": "공통 초기 · F0=.04", "hard_initial": "공간 상수 초기",
          "hard_final": "공간 상수 종료", "historical": "기존 무제약 fit",
          "baseline": "Baseline · 무제약 · 1k", "fullres": "Fullres · N1/r1 · 1k",
          "lowpass": "Lowpass · N9/r9 · 1k", "detail": "Detail · N9/r9 + H9 · 1k",
          "mixed": "Mixed · N9/r1 + H9 · 1k"}
LABELS.update({f"{name}_10k": LABELS[name].replace(" · 1k", " · 10k 정책")
               for name in CURRENT_NAMES if name != "scalespace"})
LABELS["scalespace_10k"] = "Scale-space · N5/9/17, r1/5/9 + H9 · 10k 정책"


class Package:
    def __init__(self):
        self.tensors = {}
        self.identical = {}
        self.sources = {}

    def track(self, path):
        stat = path.stat()
        value = {"size_bytes": stat.st_size, "mtime_ns": stat.st_mtime_ns}
        previous = self.sources.setdefault(str(path), value)
        if previous != value:
            raise RuntimeError(f"source changed while packaging: {path}")

    def read_json(self, path):
        self.track(path)
        return json.loads(path.read_text(encoding="utf-8"))

    def read_npz(self, path):
        self.track(path)
        with np.load(path) as values:
            return {key: torch.from_numpy(values[key].copy()) for key in values.files}

    def tensor(self, sample, value):
        if value.ndim != 4 or value.shape[0] != 1 or value.dtype != torch.float32:
            raise ValueError("packaged tensor must be FP32 [1,C,H,W]")
        if not torch.isfinite(value).all():
            raise ValueError("packaged tensor contains nonfinite values")
        array = np.asarray(value[0].detach().cpu().permute(1, 2, 0).contiguous().numpy(), dtype="<f4")
        raw = array.tobytes(order="C")
        key = (sample, array.shape, raw)
        if key not in self.identical:
            ident = f"{sample[-3:]}_tensor_{len(self.tensors):03d}"
            self.identical[key] = ident
            self.tensors[ident] = {"data": base64.b64encode(zlib.compress(raw)).decode("ascii"),
                                   "shape": list(array.shape), "dtype": "float32-le", "compression": "deflate"}
        return self.identical[key]

    def frames(self, sample_folder, condition):
        result = []
        for frame in condition.get("frames", []):
            path = sample_folder / frame["path"]
            self.track(path)
            mime = mimetypes.guess_type(path.name)[0] or "image/webp"
            result.append({"step": frame["step"], "kind": "recorded_montage", "source": str(path),
                           "image": f"data:{mime};base64," + base64.b64encode(path.read_bytes()).decode("ascii")})
        return result

    def verify_sources(self):
        for path, expected in self.sources.items():
            current = Path(path).stat()
            if expected != {"size_bytes": current.st_size, "mtime_ns": current.st_mtime_ns}:
                raise RuntimeError(f"source changed while packaging: {path}")


def compact_trajectory(rows):
    result = []
    fields = ("step", "phase", "measured_mse", "preservation_mse", "total_loss", "cue_loss",
              "normal_detail_loss", "normal_cue_raw", "roughness_cue_raw", "weighted_cue_loss")
    for row in rows:
        record = {key: row[key] for key in fields if key in row}
        if "common_heldout_mse" in row:
            record["heldout_mse"] = row["common_heldout_mse"]
        if "weighted_normal_detail_loss" in row:
            record["weighted_detail_loss"] = row["weighted_normal_detail_loss"]
        for block, prefix in (("gradient_rms_raw", "gradient"), ("update_mean_abs_raw", "update")):
            for channel in ("n", "d", "r"):
                if channel in row.get(block, {}):
                    record[f"{prefix}_{channel}"] = row[block][channel]
        changes = row.get("map_mae_physical", {})
        for source, target in (("normal_angular_mean_deg", "normal_angular_mean_deg"),
                               ("diffuse", "diffuse_change_mae"), ("roughness", "roughness_change_mae")):
            if source in changes:
                record[target] = changes[source]
        if "stability_window" in row:
            window = row["stability_window"]
            record["stability_relative_loss_span"] = window["relative_loss_span"]
            for key, value in window.get("net_map_change", {}).items():
                record[f"stability_change_{key}"] = value
        for channel in ("normal", "roughness"):
            for kernel, band in row.get(f"{channel}_cue_bands", {}).items():
                for key in ("raw", "normalized", "active"):
                    record[f"train_{channel}_cue_k{kernel}_{key}"] = band[key]
        result.append(record)
    return result


def common_metrics(material, rendered, near, reference, contexts, recorded=None):
    maps = physical_maps(material)
    hp0 = reference["normal"] - _pool(reference["normal"], 9)
    hp = maps["normal"] - _pool(maps["normal"], 9)
    e0, energy = float(hp0.square().mean()), float(hp.square().mean())
    metrics = dict(measured_mse=float((rendered - near).square().mean()),
                   hp_rms_ratio=(energy / e0) ** .5 if e0 >= 1e-8 else None,
                   hp_relative_error=float((hp - hp0).square().mean() / e0) ** .5 if e0 >= 1e-8 else None,
                   hp_cosine=float((hp * hp0).mean()) / (energy * e0) ** .5 if min(e0, energy) >= 1e-8 else None,
                   roughness_std=float(maps["roughness"].std(unbiased=False)),
                   roughness_hp_rms=float((maps["roughness"] - _pool(maps["roughness"], 9)).square().mean().sqrt()),
                   normal_component_std_rms=float(maps["normal"].var(dim=(-2, -1), unbiased=False).mean().sqrt()))
    for kernel, context in contexts.items():
        terms = evaluate_color_cue(maps["normal"], maps["roughness"], context)
        if kernel in (1, 9):
            metrics[f"cue_k{kernel}"] = float(terms["cue_loss"])
        for name in (("normal",) if kernel == 17 else ("normal", "roughness")):
            raw, initial = terms[f"{name}_cue_raw"], getattr(context, f"{name}_scale")
            metrics[f"{name}_cue_k{kernel}_raw"] = float(raw)
            metrics[f"{name}_cue_k{kernel}_initial"] = float(initial)
            metrics[f"{name}_cue_k{kernel}_ratio"] = float(raw / initial) if getattr(context, f"{name}_active") else None
    metrics["preservation_mse"] = recorded.get("preservation_mse") if recorded else 0.0
    metrics["heldout_mse"] = recorded.get("common_heldout_mse") if recorded else 0.0
    return metrics


def evaluation_contexts(reference, near, local_kernel=31):
    # The k17 context is used for N only; r remains at its shared k9 evaluation scale.
    return {kernel: build_color_cue_context(reference["normal"], reference["roughness"], near,
            lowpass_kernel=kernel, roughness_lowpass_kernel=9 if kernel == 17 else kernel,
            local_kernel=local_kernel) for kernel in (1, 5, 9, 17)}


def complete_metrics(metrics):
    required = ("roughness_cue_k1_raw", "roughness_hp_rms", "normal_cue_k5_raw",
                "normal_cue_k17_raw", "roughness_cue_k5_raw")
    return all(key in metrics for key in required)


def add_variant(package, sample, variants, ident, material, rendered, near, reference, contexts,
                *, condition=None, row=None, settings=None, provenance=None, frames=None, cached_metrics=None):
    metrics = dict(cached_metrics) if cached_metrics is not None else common_metrics(material, rendered, near, reference, contexts, row)
    np.testing.assert_allclose(metrics["measured_mse"], float((rendered-near).square().mean()), rtol=2e-5, atol=1e-8)
    if row and "measured_mse" in row:
        np.testing.assert_allclose(metrics["measured_mse"], row["measured_mse"], rtol=2e-5, atol=1e-8)
    maps = physical_maps(material)
    variants.append({"id": ident, "label": LABELS[ident],
                     "group": "current" if ident.endswith("_10k") else "hard" if ident.startswith("hard_") else "original" if ident in ("original", "fixed_initial") else "historical" if ident == "historical" else "pilot",
                     "step": row.get("step", 0) if row else 0,
                     "termination": condition.get("termination") if condition else None,
                     "settings": settings or {}, "metrics": metrics,
                     "trajectory": compact_trajectory(condition["trajectory"]) if condition else None,
                     "arrays": {**{name: package.tensor(sample, value) for name, value in maps.items()},
                                "render": package.tensor(sample, rendered)},
                     "provenance": provenance or {}, **({"frames": frames} if frames else {})})
    print(f"packaged {sample[-3:]} {ident}", flush=True)


def package_data(*, allow_incomplete=False):
    torch.set_num_threads(1)
    package = Package()
    for source in ("build_cue_explorer.py", "capture_processing/color_cue.py",
                   "capture_processing/rendering_loss_analysis.py", "run_rendering_loss_analysis.py",
                   "utils/render_util.py", "docs/cue_multiscale_design.md"):
        package.track(ROOT/source)
    pilot_names = ("baseline", "fullres", "lowpass", "detail", "mixed")
    missing = [f"{name}/{sample}" for name in pilot_names for sample in SAMPLES
               if not (PILOT/name/sample/"materials.npz").is_file() or not (PILOT/name/sample/"result.json").is_file()]
    missing += [f"current/{name}/{sample}" for name in CURRENT_NAMES for sample in SAMPLES
                if any(not (CURRENT/name/sample/file).is_file() for file in ("materials.npz", "result.json", "snapshots.npz"))]
    if missing and not allow_incomplete:
        raise FileNotFoundError("all six current outcomes required before final build: " + ", ".join(missing))
    existing_metrics = package.read_json(PILOT/"metrics.json")
    cached = {(row["sample"], row["variant"]): row["metrics"] for row in existing_metrics["records"]
              if complete_metrics(row["metrics"])}
    current_cached = {}
    if (CURRENT/"metrics.json").is_file():
        current_cached = {(row["sample"], row["variant"]): row["metrics"]
                          for row in package.read_json(CURRENT/"metrics.json")["records"]
                          if complete_metrics(row["metrics"])}
    samples = []
    renderer = None
    for sample in SAMPLES:
        data = package.read_npz(PILOT/"baseline"/sample/"materials.npz")
        baseline_result = package.read_json(PILOT/"baseline"/sample/"result.json")
        original, near, far = data["original"], data["near"], data["far"]
        reference = physical_maps(original)
        contexts = evaluation_contexts(reference, near)
        q = baseline_result["q"]
        variants = []
        common_settings = {"precision": "FP32", "q": q, "camera_xyz": [0, 0, 4],
                           "measured_light_xyz": [0, 0, 4], "preservation_weight": 0.1}
        add_variant(package, sample, variants, "original", original, data["render_original"], near, reference, contexts,
                    settings={**common_settings, "F0": "original pretrained spatial prediction"},
                    provenance={"source": str(PILOT/"baseline"/sample/"materials.npz"), "map": "original"},
                    cached_metrics=cached.get((sample, "original")))
        fixed_initial = data["initial"]
        if renderer is None:
            from run_spherical_refinement import _make_renderer
            renderer = _make_renderer(torch.device("cpu"))
        with torch.no_grad():
            fixed_initial_render = renderer(fixed_initial, torch.tensor([[0, 0, 4]], dtype=torch.float32), q)[:, 0]
        initial_row = baseline_result["trajectory"][0]
        if initial_row["step"] != 0:
            raise ValueError("fresh baseline initial trajectory must start at zero")
        fixed_initial_condition = {"trajectory": [initial_row],
                                   "termination": {"step": 0, "status": "fixed_f0_initial_state"}}
        add_variant(package, sample, variants, "fixed_initial", fixed_initial, fixed_initial_render, near, reference, contexts,
                    condition=fixed_initial_condition, row=initial_row,
                    settings={**common_settings, "F0": 0.04, "spatial_constants": [],
                              "comparison": "common starting state of all six fresh current conditions; no updates"},
                    provenance={"source": str(PILOT/"baseline"/sample/"materials.npz"), "map": "initial",
                                "render": "CPU reevaluation with the experiment's fixed-camera shader; no inference or optimization"})
        hard_folder = HARD/sample
        hard = package.read_npz(hard_folder/"theta_joint/render_materials.npz")
        hard_render = package.read_npz(hard_folder/"theta_joint/centered_render_values.npz")
        condition = package.read_json(hard_folder/"theta_joint/condition.json")
        metadata = package.read_json(hard_folder/"metrics.json")
        for key, expected in (("original", original),):
            np.testing.assert_array_equal(hard[key].numpy(), expected.numpy())
        for key, expected in (("near", near), ("far", far)):
            np.testing.assert_array_equal(hard_render[key].numpy(), expected.numpy())
        if metadata["lamp_intensity"]["q"] != q:
            raise ValueError("hard and pilot q differ")
        with torch.no_grad():
            initial_render = renderer(hard["initial"], torch.tensor([[0, 0, 4]], dtype=torch.float32), q)[:, 0]
        initial_condition = {"trajectory": [condition["trajectory"][0]], "termination": {"step": 0, "status": "projected_initial_state"}}
        hard_settings = {**common_settings, "F0": 0.04, "spatial_constants": condition["objective"]["spatial_constants"],
                         "comparison": "different feasible space and stopping history from fresh 1k and current max10k experiments"}
        add_variant(package, sample, variants, "hard_initial", hard["initial"], initial_render, near, reference, contexts,
                    condition=initial_condition, row=condition["trajectory"][0], settings=hard_settings,
                    provenance={"source": str(hard_folder), "render": "FP32 CPU shader reevaluation of saved initial map; no inference or optimization"})
        add_variant(package, sample, variants, "hard_final", hard["updated"], hard_render["updated"], near, reference, contexts,
                    condition=condition, row=condition["trajectory"][-1], settings=hard_settings,
                    provenance={"source": str(hard_folder)}, frames=package.frames(hard_folder, condition))
        historical_folder = HISTORICAL[sample]/sample
        historical = package.read_npz(historical_folder/"theta_joint/render_materials.npz")
        historical_render = package.read_npz(historical_folder/"theta_joint/centered_render_values.npz")
        historical_condition = package.read_json(historical_folder/"theta_joint/condition.json")
        historical_metadata = package.read_json(historical_folder/"metrics.json")
        np.testing.assert_array_equal(historical["original"].numpy(), original.numpy())
        np.testing.assert_array_equal(historical_render["near"].numpy(), near.numpy())
        np.testing.assert_array_equal(historical_render["far"].numpy(), far.numpy())
        if historical_metadata["lamp_intensity"]["q"] != q:
            raise ValueError("historical and pilot q differ")
        add_variant(package, sample, variants, "historical", historical["updated"], historical_render["updated"], near, reference, contexts,
                    condition=historical_condition, row=historical_condition["trajectory"][-1],
                    settings={**common_settings, "F0": 0.04, "comparison": "historical stopping/optimizer history differs; 078 resumed at absolute step3000 after earlier 41-light phase"},
                    provenance={"source": str(historical_folder)}, frames=package.frames(historical_folder, historical_condition))
        run_groups = [(PILOT, name, name, cached) for name in pilot_names]
        run_groups += [(CURRENT, name, f"{name}_10k", current_cached) for name in CURRENT_NAMES]
        for run_root, name, ident, metric_cache in run_groups:
            folder = run_root/name/sample
            if not (folder/"result.json").is_file() or not (folder/"materials.npz").is_file():
                continue
            values = package.read_npz(folder/"materials.npz")
            record = package.read_json(folder/"result.json")
            plan = package.read_json(run_root/name/"plan.json")
            for key, expected in (("original", original), ("near", near), ("far", far)):
                np.testing.assert_array_equal(values[key].numpy(), expected.numpy())
            np.testing.assert_array_equal(values["initial"].numpy(), fixed_initial.numpy())
            if record["q"] != q:
                raise ValueError("pilot variants q differ")
            snapshot_metadata = None
            archived_code = None
            if ident.endswith("_10k"):
                snapshot_path = folder/"snapshots.npz"
                package.track(snapshot_path)
                with np.load(snapshot_path) as snapshots:
                    steps = sorted(int(key.removeprefix("step_")) for key in snapshots.files)
                if set(steps) != {frame["step"] for frame in record.get("frames", [])}:
                    raise ValueError("recorded snapshots and montage frame steps differ")
                snapshot_metadata = {"source": str(snapshot_path), "steps": steps,
                                     "kind": "saved FP32 numeric maps; HTML timeline uses recorded montages"}
                code_folder = run_root/name/"source_snapshot"
                code_files = [path for path in code_folder.rglob("*") if path.is_file()] if code_folder.is_dir() else []
                for path in code_files:
                    package.track(path)
                archived_code = {"available": bool(code_files), "path": str(code_folder),
                                 "files": [str(path) for path in code_files],
                                 "note": "presence recorded; missing dispatch-time snapshot is unknown, not reconstructed"}
            add_variant(package, sample, variants, ident, values["updated"], values["render_final"], near, reference, contexts,
                        condition=record, row=record["trajectory"][-1], cached_metrics=metric_cache.get((sample, name)),
                        settings={**common_settings, "F0": 0.04, "learning_rate": plan["lr"], "seed": plan["seed"],
                                  "step_budget": plan["steps"], "cue_config": None if name == "baseline" else plan["cue_config"],
                                  "objective": record["objective"],
                                  "comparison": "fresh max10k with existing stability stop" if ident.endswith("_10k") else "same fresh 1k budget"},
                        provenance={"source": str(folder), "capture": record.get("provenance", {}),
                                    "snapshots": snapshot_metadata, "archived_code": archived_code},
                        frames=package.frames(folder, record))
        samples.append({"id": sample, "label": sample[-3:],
                        "near": package.tensor(sample, near), "far": package.tensor(sample, far), "variants": variants})
    logs = []
    for stage in ("cue_tdd", "cue_mixed_tdd", "cue_scalespace_tdd"):
        for path in sorted((ROOT/"tmp"/stage).glob("*.txt")):
            package.track(path)
            logs.append({"id": stage+"/"+path.stem, "stage": stage, "path": str(path),
                         "text": path.read_text(encoding="utf-8", errors="replace")})
    synthetic = package.read_json(PILOT/"sol_synthetic_evidence.json")
    validation_path = ROOT/"tmp/cue_10k_validation/validation.json"
    validation = package.read_json(validation_path) if validation_path.is_file() else None
    package.verify_sources()
    return {
        "schema": "nfplight.cue-explorer.v1", "tensors": package.tensors, "samples": samples,
        "methodology": {"precision": "FP32", "tensor_encoding": "zlib deflate of little-endian FP32 HWC; exact byte-equality deduplication per sample",
                        "environment": {"python": sys.version, "torch": torch.__version__, "numpy": np.__version__, "zlib": zlib.ZLIB_VERSION},
                        "base_objective": "center I_N MSE + 0.1 mean40 off-center original-response preservation",
                        "preservation_reference": "Original full material prediction, including its original spatial F0, rendered with fixed camera (0,0,4); optimized student F0 is fixed to 0.04. Preservation and heldout are response-to-teacher MSE, not measured ground truth.",
                        "renderer": "run_spherical_refinement._make_renderer imports run_rendering_loss_analysis._make_renderer (fixed camera); no moving-camera renderer is used for packaging.",
                        "metric_definitions": existing_metrics["definitions"], "evaluation_kernels_px": [1, 9], "local_kernel_px": 31,
                        "evaluation_normal_kernels_px": [1, 5, 9, 17], "evaluation_roughness_kernels_px": [1, 5, 9],
                        "common_vs_train": "metrics contain the same original-normalized evaluator for all variants; train_* trajectory fields use each objective's own fixed initial bands and activation",
                        "source_files": package.sources, "source_files_unchanged_during_packaging": True,
                        "groups": {"current": "현재 최대10k·기존 안정화 종료; cap 도달 조건을 수렴했다고 주장하지 않으며 각 termination을 확인한다.",
                                   "pilot": "보존된 고정1k 탐색", "hard": "공간 상수 제약 초기/종료", "historical": "이전 무제약 fit"},
                        "current_variants": list(CURRENT_NAMES), "current_step_cap": 10000,
                        "stability": {"minimum_updates": 300, "window_updates": 100, "relative_loss_span_max": 0.001,
                                      "normal_window_mean_angle_deg_max": 0.001, "diffuse_roughness_window_mae_max": 1e-5},
                        "missing_variants": missing, "complete": not missing, "sha256_executed": False,
                        "trajectory": "recorded states only; historical078 starts at absolute3000; image snapshots are saved montages, not numeric intermediate maps"},
        "synthetic": synthetic, "validation": validation,
        "tdd": {"scope": "recorded RED/GREEN logs; RED records expected failing tests before a fix", "logs": logs},
        "limitations": ["실제 fabric의 정답 맵이 없어 geometry 복원 성공을 주장하지 않는다.",
                        "원본 normal 고주파는 보존 기준이며 정답이 아니다. cue 감소는 직접 최적화한 지표의 감소다.",
                        "회색 무늬는 색도 cue에 보이지 않으며 실제 색과 geometry가 함께 변하면 잘못 억제할 수 있다.",
                        "가상 heldout 광원은 원본 모델 응답 보존이고 실측 독립 검증이 아니다.",
                        "공간 상수·기존 fit은 초기화 제약과 종료 이력이 다르므로 고정1k 탐색 및 현재 최대10k·안정화 종료 실험과 동일 정책의 공정한 직접 대조군이 아니다.",
                        "보존된 고정1k 탐색에서 저주파+detail의478 roughness는 저주파 cue 감소와 동시에 전체 해상도 cue 증가를 보였다. 이 관측을 새 최대10k 결과로 해석하지 않으며, 실제 정답 복원 근거로 쓰지 않는다.",
                        "픽셀 kernel은 선택 제약 스케일이며 실제 실의 물리 크기를 뜻하지 않는다."]}


def compress_html_trajectories(data):
    """Copy the container structure; preserve plain analysis data and numeric values."""
    samples = []
    for sample in data["samples"]:
        variants = []
        for variant in sample["variants"]:
            encoded = dict(variant)
            if "trajectory" in encoded:
                raw = json.dumps(encoded.pop("trajectory"), ensure_ascii=False,
                                 allow_nan=False, separators=(",", ":")).encode("utf-8")
                encoded["trajectory_deflate"] = base64.b64encode(zlib.compress(raw)).decode("ascii")
            variants.append(encoded)
        samples.append({**sample, "variants": variants})
    methodology = {**data["methodology"],
                   "trajectory_encoding": "HTML-only: trajectory_deflate is base64 of zlib-deflated UTF-8 JSON; native browser decompression restores trajectory exactly, including null."}
    return {**data, "samples": samples, "methodology": methodology}


def self_check():
    package = Package()
    values = torch.arange(24, dtype=torch.float32).reshape(1, 3, 2, 4)
    ident = package.tensor("sample", values)
    assert package.tensor("sample", values.clone()) == ident
    encoded = package.tensors[ident]
    decoded = np.frombuffer(zlib.decompress(base64.b64decode(encoded["data"])), dtype="<f4").reshape(encoded["shape"])
    np.testing.assert_array_equal(decoded, values[0].permute(1, 2, 0).numpy())
    assert encoded["compression"] == "deflate" and encoded["dtype"] == "float32-le"
    assert "</script>" not in json.dumps({"value": "</script>"}).replace("</", "<\\/")
    torch.set_num_threads(1)
    material = torch.zeros(1, 10, 32, 32, dtype=torch.float32)
    x = torch.arange(32, dtype=torch.float32).view(1, 1, 1, 32).expand(1, 1, 32, 32)
    broad = torch.sin(2 * torch.pi * x / 32)
    material[:, 0:1] = 0.1 * broad
    material[:, 2:3] = 1.0
    material[:, 6:7] = 0.2 * broad
    material[:, 7:] = -0.92
    near = torch.cat((0.5 + 0.2 * broad, 0.5 - 0.2 * broad, torch.full_like(broad, 0.5)), dim=1)
    reference = physical_maps(material)
    metrics = common_metrics(material, torch.zeros_like(near), near, reference, evaluation_contexts(reference, near, 7))
    assert complete_metrics(metrics)
    for component, kernels in (("normal", (1, 5, 9, 17)), ("roughness", (1, 5, 9))):
        for kernel in kernels:
            assert metrics[f"{component}_cue_k{kernel}_raw"] >= 0
            ratio = metrics[f"{component}_cue_k{kernel}_ratio"]
            assert ratio is None or abs(ratio-1.0) < 1e-5
    assert metrics["hp_relative_error"] == 0
    trajectories = [None, [{"step": 0, "measured_mse": 1.23e-7, "active": True,
                            "note": "초기", "nullable": None}, {"step": 10000, "normal_detail_loss": 0.0}]]
    plain = {"samples": [{"id": "test", "variants": [{"trajectory": rows} for rows in trajectories]}],
             "methodology": {"precision": "FP32"}, "tensors": {"unchanged": encoded}}
    compressed = compress_html_trajectories(plain)
    for source, packed in zip(plain["samples"][0]["variants"], compressed["samples"][0]["variants"]):
        restored = json.loads(zlib.decompress(base64.b64decode(packed["trajectory_deflate"])).decode("utf-8"))
        assert restored == source["trajectory"]
        assert "trajectory" not in packed and "trajectory" in source
    assert compressed["tensors"] is plain["tensors"]
    assert "trajectory_encoding" not in plain["methodology"]
    print("codec/dedup/embedding/common-band evaluator/trajectory exact-roundtrip self-check passed")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--template", type=Path, default=ROOT/"cue_explorer_template.html")
    parser.add_argument("--out", type=Path, default=ROOT/"artifacts/cue_explorer_20261007/report.html")
    parser.add_argument("--allow-incomplete", action="store_true")
    parser.add_argument("--self-check", action="store_true")
    args = parser.parse_args()
    if args.self_check:
        self_check()
        return
    template = args.template.read_text(encoding="utf-8")
    if template.count("__CUE_DATA_JSON__") != 1:
        raise ValueError("template requires exactly one __CUE_DATA_JSON__ placeholder")
    data = package_data(allow_incomplete=args.allow_incomplete)
    template = args.template.read_text(encoding="utf-8")
    if template.count("__CUE_DATA_JSON__") != 1:
        raise ValueError("template requires exactly one __CUE_DATA_JSON__ placeholder")
    html_data = compress_html_trajectories(data)
    for plain_sample, encoded_sample in zip(data["samples"], html_data["samples"]):
        for plain_variant, encoded_variant in zip(plain_sample["variants"], encoded_sample["variants"]):
            restored = json.loads(zlib.decompress(base64.b64decode(encoded_variant["trajectory_deflate"])).decode("utf-8"))
            if restored != plain_variant["trajectory"]:
                raise ValueError("HTML trajectory roundtrip differs from saved records")
    for encoded in data["tensors"].values():
        raw = zlib.decompress(base64.b64decode(encoded["data"]))
        if len(raw) != int(np.prod(encoded["shape"]))*4 or not np.isfinite(np.frombuffer(raw, dtype="<f4")).all():
            raise ValueError("HTML tensor codec roundtrip invalid")
    payload = json.dumps(html_data, ensure_ascii=False, allow_nan=False,
                         separators=(",", ":")).replace("</", "<\\/")
    html = template.replace("__CUE_DATA_JSON__", payload).replace("__DIFFERENCE_JS__", (ROOT/"capture_processing/difference_visualization.js").read_text(encoding="utf-8"))
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(html, encoding="utf-8")
    final_metrics = {"schema": data["schema"], "samples": [
        {"id": sample["id"], "label": sample["label"], "variants": [
            {key: variant[key] for key in ("id", "label", "group", "step", "termination", "settings", "metrics")}
            for variant in sample["variants"]]} for sample in data["samples"]]}
    metrics_path = args.out.parent/"final_metrics.json"
    metrics_path.write_text(json.dumps(final_metrics, ensure_ascii=False, allow_nan=False,
                                       separators=(",", ":")), encoding="utf-8")
    checks = {"complete": data["methodology"]["complete"], "samples": len(data["samples"]),
              "states_per_sample": [len(sample["variants"]) for sample in data["samples"]],
              "tensors": len(data["tensors"]), "tensor_codec_all_finite": True,
              "trajectory_exact_roundtrip": True, "source_files_unchanged_during_packaging": True,
              "validation_included": data["validation"] is not None,
              "validation_checks": data["validation"].get("checks") if data["validation"] else None,
              "sha256_executed": False, "standalone_html_pending": False,
              "html_bytes": args.out.stat().st_size, "final_metrics": str(metrics_path)}
    (args.out.parent/"data_checks.json").write_text(json.dumps(checks, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"output": str(args.out), "bytes": args.out.stat().st_size,
                      "samples": len(data["samples"]), "tensors": len(data["tensors"]),
                      "variants": [len(s["variants"]) for s in data["samples"]],
                      "complete": data["methodology"]["complete"]}), flush=True)


if __name__ == "__main__":
    main()
