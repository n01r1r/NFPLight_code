"""Three-sample report from saved FP32 results; no numerical optimization."""
import json
import re
import shutil
from pathlib import Path
from zipfile import ZipFile
import xml.etree.ElementTree as ET
from PIL import Image
import run_spherical_refinement as r

ROOT = Path('artifacts/measured_refinement_20261007_unified')
PDF = Path('output/pdf/measured_refinement_20261007_unified.pdf')
TEMPLATE = Path('C:/Users/hdy/.codex/plugins/cache/openai-curated-remote/openai-templates/0.1.1/skills/artifact-template-design-report/assets/reference.docx')
SOURCES = {
    '260818_174845_478': Path('artifacts/measured_spherical_refinement_20261007_fresh478_40lights'),
    '260818_175005_078': Path('artifacts/measured_spherical_refinement_20261007_continue10k_40lights'),
    '260930_152732_008': Path('artifacts/measured_spherical_refinement_20261007_continue10k_40lights'),
}


def load(path):
    return json.loads(path.read_text(encoding='utf-8'))


def stats(value):
    return f"min {value['min']:.5g} · max {value['max']:.5g} · mean {value['mean']:.5g}"


def main():
    ROOT.mkdir(exist_ok=True)
    # Import the retained template's geometry and heading sizes for HTML/PDF.
    template_bytes = TEMPLATE.read_bytes()
    shutil.copyfile(TEMPLATE, ROOT/'reference.docx')
    with ZipFile(TEMPLATE) as package:
        ns = {'w': 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
        document = ET.fromstring(package.read('word/document.xml'))
        section = document.find('.//w:sectPr', ns)
        tag = '{'+ns['w']+'}'
        size = section.find('w:pgSz', ns)
        margins = section.find('w:pgMar', ns)
        width, height = [int(size.get(tag+k))/20 for k in ('w', 'h')]
        margin = int(margins.get(tag+'left'))/20
    (ROOT/'artifact.md').write_text(
        '# Design Report adaptation\n\nRetained reference imported unchanged as reference.docx. '
        f'Page: {width:g} × {height:g} pt; margin {margin:g} pt. '
        'Title 40 pt; heading 24 pt. User deviations: serif fonts, minimal Korean captions, '
        'scientific figures replace template photography, HTML MathJax, HTML/PDF outputs. '
        'Native DOCX renderer unavailable (LibreOffice not on PATH); PDF rendered and reviewed directly. '
        'No SHA-256 executed.\n', encoding='utf-8')
    records = []
    before = {str(p): r._file_stat(p) for source in SOURCES.values() for p in source.rglob('*') if p.is_file()}
    for sample, source in SOURCES.items():
        record = load(source/sample/'metrics.json')
        c = load(source/sample/'theta_joint/condition.json')
        assert c['train_light_count'] == 40
        assert len(c['evaluation_xyz']) == 40
        assert c['termination']['step'] <= 10000
        assert c['metrics']['fixed_specular_gradient_rms'] == 0
        record['conditions'] = [c]
        target = ROOT/sample/'theta_joint'
        target.mkdir(parents=True, exist_ok=True)
        # Only display assets and auditable metadata; checkpoints stay at source.
        shutil.copyfile(source/sample/'original.webp', ROOT/sample/'original.webp')
        for f in (source/sample/'theta_joint').iterdir():
            if f.suffix in ('.webp', '.svg', '.png', '.json'):
                shutil.copyfile(f, target/f.name)
        r._json(ROOT/sample/'metrics.json', record)
        records.append(record)
    from build_spherical_sampling_diagram import sampling_diagram
    sampling_diagram(ROOT, list(SOURCES))
    comparison = r.summary_map_comparison(ROOT, records)
    comparison = comparison.replace('<h2>Original · updated · difference</h2>', '')
    for sample in SOURCES:
        comparison = comparison.replace(f'<a href="{sample}/report.html">{sample}</a>', sample)
    rows = []
    for record in records:
        c = record['conditions'][0]
        last = c['trajectory'][-1]
        status = '안정화 기준 충족' if c['termination']['status'] == 'stability_criteria_met' else '상한 도달 · 기준 미충족'
        rows.append(f"<tr><td><a href='#{record['sample']}'>{record['sample']}</a></td><td>{c['termination']['step']:,}</td><td>{status}</td><td>{last['measured_mse']:.5g}</td><td>{last['preservation_mse']:.5g}</td></tr>")
        comparison = comparison.replace(f'<h2>{record["sample"]}</h2>', f'<h2 id="{record["sample"]}">{record["sample"]}</h2>')
    method = r'''<section class="method"><h2>Rendering loss</h2>
    <div>\[\mathcal L=\underbrace{\mathrm{MSE}(R(P;\ell_c,q),I_N)}_{\text{중앙 관측}}+0.1\underbrace{\frac1{40}\sum_{\ell\in\Omega}\mathrm{MSE}(R(P;\ell,q),R(P_0;\ell,q))}_{\text{원래 pred의 조명 응답 보존}}\]</div>
    <p>F₀=0.04 고정 · n/d/r 최적화 · q 고정 · linear RGB MSE · Adam 0.01 · FP32</p>
    <p>Ω: θ=5°, 10°, 20°, 30°, 45° × φ=0°부터 45° 간격의 8개 위치. 매 step 40개 보존 loss와 중앙 관측 loss를 계산한 뒤 한 번 업데이트한다.</p>
    <p>Test: 같은 θ, φ에 22.5° 추가한 40개 위치. 최적화와 종료 판정에 사용하지 않는다. 원래 pred의 렌더링은 보존 기준이며, 해당 위치의 실측값은 없다.</p>
    <p>최대 10,000 step. 최근 100 updates: loss span/mean ≤0.001, 평균 normal 각도 변화 ≤0.001°, d/r 평균 절대 변화 ≤10⁻⁵.</p></section>'''
    dynamics = ''
    for record in records:
        sample = record['sample']
        frames = record['conditions'][0]['frames']
        dynamics += f'<details><summary>{sample} · 변화 과정</summary><div class="step-view" data-sample="{sample}" data-frames=\'{json.dumps(frames)}\'><p>n / d / r / s · 아래 행: angular Δn / signed Δd / Δr / Δs</p><img class="plot step-image" src="{sample}/{frames[-1]["path"]}" alt="Step maps and differences"><input class="step-slider" type="range" min="0" max="{len(frames)-1}" value="{len(frames)-1}" style="width:85%"><output>step {frames[-1]["step"]}</output></div><img class="plot" src="{sample}/theta_joint/curve.svg" alt="Loss components and map changes"><img class="plot" src="{sample}/theta_joint/optimizer.svg" alt="Gradient and update scale"></details>'
    dynamics += '''<script>document.querySelectorAll('.step-view').forEach(view=>{const frames=JSON.parse(view.dataset.frames);view.querySelector('input').oninput=function(){const f=frames[this.value];view.querySelector('img').src=view.dataset.sample+'/'+f.path;view.querySelector('output').value='step '+f.step;};});</script>'''
    style = '''<style>body{font:16px/1.65 Georgia,"Times New Roman",Batang,serif;color:#202020;max-width:1320px;margin:64px auto;padding:0 36px}h1{font-size:40px;line-height:1.15;margin:28px 0 12px}h2{font-size:24px;font-weight:normal;margin-top:40px}h3{font-size:18px;font-weight:normal}a{color:inherit;text-decoration-color:#bbb}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums}th,td{text-align:left;padding:12px 8px;border-bottom:1px solid #ddd}th{font-weight:normal;color:#595959}header>p{color:#595959}header{border-bottom:1px solid #ddd;padding-bottom:28px}.hero{display:flex;gap:8px;width:100%}.hero img{width:calc((100% - 16px)/3);height:auto}.method{max-width:1050px}.plot{width:100%;height:auto}details{margin:24px 0;border-top:1px solid #ddd;padding-top:16px}summary{cursor:pointer;font-size:20px}footer{border-top:1px solid #ddd;margin-top:40px;padding:16px 0;color:#595959}@media(max-width:700px){body{padding:0 16px;margin:24px auto}table{font-size:12px}h1{font-size:32px}}@media print{details{display:none}.map-comparison{break-before:page}}</style>'''
    hero = '<div class="hero">'+''.join(f'<img src="{sample}/theta_joint/measured_near.webp" alt="{sample} measured near">' for sample in SOURCES)+'</div>'
    html = '<!doctype html><html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>F₀ 고정 · 재질 refinement</title>'+style+'''<script>window.MathJax={tex:{inlineMath:[['\\(','\\)']]},svg:{fontCache:'global'}};</script><script defer src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script></head><body>'''
    html += hero+'<header><h1>F₀ 고정 · 재질 refinement</h1><p>478 · 078 · 008</p><a href="../../'+PDF.as_posix()+'">PDF</a></header>'
    html += '<h2>최종 결과</h2><table><thead><tr><th>Sample</th><th>Step</th><th>종료 판정</th><th>관측 MSE</th><th>보존 MSE</th></tr></thead><tbody>'+''.join(rows)+'</tbody></table>'+comparison+method
    html += '<h2>조명 위치</h2><img class="plot" src="spherical_sampling_top_view.svg" alt="Top-view light positions: measured center, preservation and test"><p>+Z에서 본 위치 · 파랑=보존 · 주황=Test · 검정=중앙 관측 · 반지름=4 sin θ</p>'+dynamics
    html += '<footer>차이=updated − original · normal은 각도, d/s는 RGB, r은 회색 · F₀ 고정으로 생긴 Δs 포함</footer></body></html>'
    (ROOT/'summary.html').write_text(html, encoding='utf-8')
    r._json(ROOT/'source_manifest.json', {'samples': {sample: {'source': source.as_posix(), 'initialization': 'fresh original prediction' if sample.endswith('478') else 'existing 3000-step prefix; optimizer continuation'} for sample, source in SOURCES.items()}, 'objective': 'centered I_N MSE + 0.1 mean40 off-center preservation MSE', 'report_includes': 'terminal states; original pred; signed differences'})
    r._json(ROOT/'summary.json', {'plan': {'active_samples': list(SOURCES), 'preservation_train_count':40, 'max_steps':10000}, 'samples': [{'sample': record['sample'], 'termination': record['conditions'][0]['termination'], 'final': record['conditions'][0]['trajectory'][-1]} for record in records]})
    build_pdf(records, width, height, margin)
    assert TEMPLATE.read_bytes() == template_bytes
    assert all(r._file_stat(Path(p)) == stat for p, stat in before.items())
    for src in re.findall(r'src="([^"]+)"', html):
        if not src.startswith('https:'):
            assert (ROOT/src).is_file(), src
    r._json(ROOT/'checks.json', {'source_files_unchanged': len(before), 'template_bytewise_unchanged': True,
        'samples': list(SOURCES), 'all_preservation_light_counts': 40, 'html_assets_exist': True,
        'sha256_executed': False, 'mathjax_requires_network': True})
    print(ROOT/'summary.html', PDF)


def build_pdf(records, width, height, margin):
    from reportlab.pdfgen import canvas
    from reportlab.lib.utils import ImageReader
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    from reportlab.platypus import Paragraph, Table, TableStyle
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.colors import HexColor
    pdfmetrics.registerFont(TTFont('KR', 'C:/Windows/Fonts/batang.ttc', subfontIndex=0))
    pdfmetrics.registerFont(TTFont('Serif', 'C:/Windows/Fonts/georgia.ttf'))
    pdfmetrics.registerFont(TTFont('Bold', 'C:/Windows/Fonts/georgiab.ttf'))
    PDF.parent.mkdir(parents=True, exist_ok=True)
    pdf = canvas.Canvas(str(PDF), pagesize=(width, height), pageCompression=1)
    pdf.setTitle('F0 fixed material refinement | 478, 078, 008')
    usable = width-2*margin
    page = 0
    def text(x, y, value, size=10, font='KR'):
        assert margin-1 <= x and 42 <= y <= height-margin+2
        pdf.setFont(font, size);pdf.setFillColor(HexColor('#202020'));pdf.drawString(x, y, value)
    def paragraph(y, value, size=10):
        p = Paragraph(value, ParagraphStyle('p', fontName='KR', fontSize=size, leading=size*1.55))
        _, h = p.wrap(usable, height)
        assert y-h >= margin
        p.drawOn(pdf, margin, y-h)
        return y-h
    def image(path, x, y, w, h, box=None):
        assert x >= margin-1 and y >= margin-1 and x+w <= width-margin+1 and y+h <= height-margin+1
        with Image.open(path) as im:
            im = im.convert('RGB')
            if box: im = im.crop(box)
            pdf.drawImage(ImageReader(im), x, y, width=w, height=h)
    def begin(title, subtitle=''):
        nonlocal page
        page += 1
        text(margin, height-margin, title, 24)
        if subtitle: text(margin, height-margin-25, subtitle, 10)
    def end():
        pdf.setFont('Serif', 9);pdf.setFillColor(HexColor('#595959'))
        pdf.drawString(margin, 36, 'F0 = 0.04 | FP32')
        pdf.drawRightString(width-margin, 36, str(page))
        pdf.showPage()
    # Cover geometry and typographic hierarchy imported from Design Report.
    page += 1
    tile = (usable-12)/3
    for j, record in enumerate(records):
        image(ROOT/record['sample']/'theta_joint/measured_near.webp', margin+j*(tile+6), height-margin-tile, tile, tile)
    text(margin, height-margin-tile-65, 'F0 fixed', 40, 'Bold')
    text(margin, height-margin-tile-105, '재질 refinement', 28)
    text(margin, height-margin-tile-135, '478 · 078 · 008')
    y = height-margin-tile-175
    table_rows = [['Sample', 'Step', '관측 MSE', '보존 MSE']]
    for record in records:
        c = record['conditions'][0];t = c['trajectory'][-1]
        table_rows.append([record['sample'], str(c['termination']['step']), f"{t['measured_mse']:.5g}", f"{t['preservation_mse']:.5g}"])
    table = Table(table_rows, colWidths=[170, 60, 115, usable-345])
    table.setStyle(TableStyle([('FONTNAME', (0,0),(-1,-1),'KR'),('FONTSIZE',(0,0),(-1,-1),9),('BOTTOMPADDING',(0,0),(-1,-1),10),('TOPPADDING',(0,0),(-1,-1),10),('LINEBELOW',(0,0),(-1,-1),.3,HexColor('#cccccc'))]))
    _, h = table.wrap(usable, height);table.drawOn(pdf, margin, y-h)
    paragraph(y-h-24, '세 샘플 모두 안정화 기준 충족. F₀=0.04 고정, n/d/r 최적화, q 고정. 중앙 관측과 중심 제외 40개 조명의 보존 loss를 사용했다.')
    end()
    begin('Rendering loss')
    y = height-margin-55
    y = paragraph(y, 'L = MSE(R(P; center, q), I_N) + 0.1 × mean₄₀ MSE(R(P; light, q), R(P₀; light, q))', 11)
    y = paragraph(y-22, '관측 loss는 실제 I_N에 맞춘다. 보존 loss는 다른 조명에서 원래 prediction의 응답을 기준으로 한다. 다른 조명의 실측값은 없다. MSE는 clip 전 linear RGB의 모든 픽셀·채널에 대해 평균한다.')
    y = paragraph(y-20, 'Adam 0.01 · FP32 · seed 0 · 최대 10,000 step. 최근 100 updates의 loss span/mean ≤0.001, 평균 normal 각도 변화 ≤0.001°, d/r 평균 절대 변화 ≤10⁻⁵. Test는 최적화·종료에 미사용.')
    y = paragraph(y-20, 'θ=5°, 10°, 20°, 30°, 45°. 보존 φ=0°부터 45° 간격, Test φ=22.5°부터 45° 간격. 매 step 모든 40개 보존 loss와 중앙 관측 loss를 계산하고 Adam 업데이트를 한 번 수행한다.')
    image(ROOT/'spherical_sampling_top_view.png', margin, margin+35, usable, 280)
    text(margin, margin+14, '+Z 시점 · 파랑=보존 · 주황=Test · 검정=관측 · 반지름=4 sin θ', 9)
    end()
    for record in records:
        sample = record['sample'];c = record['conditions'][0];target = ROOT/sample/'theta_joint'
        scales = load(target/'display_scales.json');comparison = load(target/'render_comparison.json')
        begin(sample, f"step {c['termination']['step']:,} · F0=0.04 · 안정화 기준 충족")
        top = height-margin-60;cell = (usable-12)/5
        for j, label in enumerate(('Normal', 'Diffuse', 'Roughness', 'Specular', 'Rendering')):
            text(margin+j*(cell+3), top, label, 9, 'Serif')
        top -= 20
        for label, name in [('Original pred','original'),('Updated pred','updated'),('Updated − original','difference')]:
            text(margin, top, label, 10, 'Serif');top -= 12+cell
            for j in range(4):
                image(target/f'summary_{name}.webp', margin+j*(cell+3), top, cell, cell, (j*256,0,(j+1)*256,256))
            image(target/f'render_{name}.webp', margin+4*(cell+3), top, cell, cell)
            top -= 23
        top = paragraph(top, f"Δn: 0–{scales['normal']:.4g}° (보라→노랑). Δd RGB: ±{scales['diffuse']:.4g}; Δr 회색: ±{scales['roughness']:.4g}; Δs RGB: ±{scales['specular']:.4g}. Signed 차이: 회색=0, 밝음=증가, 어두움=감소.", 9)
        top = paragraph(top-10, f"Δrender ±{comparison['difference_scale']:.5g} · {stats(comparison['difference_statistics']['updated_minus_original'])}", 9)
        top = paragraph(top-10, f"중앙 렌더링: θ=0°, light (0,0,4), q={comparison['q']:.6g}. 표시: clip [0,1], γ=2.2. 차이: clip 전 linear RGB; 통계: 전체 픽셀·RGB 채널.", 9)
        end()
        begin(sample, 'Re-rendering − I_N')
        top = height-margin-60
        size = 155;gap = 35
        for j, (name, label) in enumerate([('near','Near · I_N'),('far','Far · I_F')]):
            text(margin+j*(size+gap), top, label, 11, 'Serif')
            image(target/f'measured_{name}.webp', margin+j*(size+gap), top-size-14, size, size)
        top -= size+65
        text(margin, top, f"Signed linear RGB · 공통 범위 ±{comparison['near_difference_scale']:.5g} · 회색=0", 10)
        top -= 35
        for j, name in enumerate(('original','updated')):
            text(margin+j*(size+gap), top, name.title()+' rendering − I_N', 10, 'Serif')
            image(target/f'render_{name}_minus_near.webp', margin+j*(size+gap), top-size-14, size, size)
            value = comparison['difference_statistics'][name+'_minus_near']
            for k, key in enumerate(('min','max','mean')):
                text(margin+j*(size+gap), top-size-36-k*16, f'{key} {value[key]:.6g}', 10, 'Serif')
        paragraph(margin+80, '차이: clip 전 rendering − linear I_N. min/max/mean: 전체 픽셀·RGB 채널. Near는 fitting 관측이며, Far는 거리 참고용이다.', 9)
        end()
        begin(sample, 'Loss · map dynamics · gradient / update')
        image(target/'response.png', margin, height-margin-355, usable, 290)
        image(target/'optimizer.png', margin, margin+25, usable, 290)
        end()
    pdf.save()


if __name__ == '__main__':
    main()
