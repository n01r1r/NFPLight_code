"""Controlled scale-cue pilot from saved pretrained FP32 predictions."""
import argparse
import json
import platform
import sys
import shutil
from pathlib import Path

import numpy as np
import torch

import run_spherical_refinement as r
from capture_processing.rendering_loss_analysis import physical_maps


SOURCE = Path('artifacts/cue_constrained_refinement_20261007')
SAMPLES = ('260818_175005_078', '260818_174845_478')
VARIANTS = {
    'baseline': None,
    'fullres': dict(lowpass_kernel=1, local_kernel=31, cue_budget=.1, detail_budget=0.),
    'lowpass': dict(lowpass_kernel=9, local_kernel=31, cue_budget=.1, detail_budget=0.),
    'detail': dict(lowpass_kernel=9, local_kernel=31, cue_budget=.1, detail_budget=1.),
    'mixed': dict(lowpass_kernel=9, roughness_lowpass_kernel=1,
                  local_kernel=31, cue_budget=.1, detail_budget=1.),
    'scalespace': dict(lowpass_kernel=9, local_kernel=31, cue_budget=.1, detail_budget=1.,
                       normal_cue_kernels=[5,9,17], roughness_cue_kernels=[1,5,9]),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--variant', choices=list(VARIANTS), default='baseline')
    parser.add_argument('--steps', type=int, default=1000)
    parser.add_argument('--stability', action='store_true', help='Use the existing minimum300/window100 convergence policy')
    parser.add_argument('--out', type=Path, default=Path('artifacts/scale_cue_20261007'))
    args = parser.parse_args()
    if args.steps < 1:
        parser.error('--steps must be positive')
    output = args.out / args.variant
    output.mkdir(parents=True, exist_ok=False)
    source_folder = output/'source_snapshot'
    source_folder.mkdir()
    for source_path in (Path(__file__), Path('capture_processing/color_cue.py'),
                        Path('capture_processing/rendering_loss_analysis.py')):
        shutil.copyfile(source_path, source_folder/source_path.name)
    device = torch.device('cuda')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    renderer = r._make_renderer(device)
    plan = dict(schema='nfplight.scale-cue-pilot.v1', variant=args.variant,
                samples=SAMPLES, steps=args.steps, lr=.01, seed=0, precision='FP32',
                initialization='original cached pretrained prediction; fixed F0 .04; fresh Adam',
                objective='I_N MSE + .1 mean40 original response preservation',
                source=str(SOURCE), constant_parameters=['F0', 'q'],
                cue_config=VARIANTS[args.variant],
                cue_contract='docs/cue_multiscale_design.md',
                spatial_constants=[], stop=('minimum300; window100; loss span/mean<=.001; mean normal angle<=.001deg; d/r MAE<=1e-5' if args.stability else 'fixed budget; convergence not asserted'),
                claim='exploratory cue consistency and original-detail retention; no ground truth',
                environment=dict(python=sys.version, torch=torch.__version__,
                                 device=torch.cuda.get_device_name(0), platform=platform.platform()))
    r._json(output/'plan.json', plan)
    for sample in SAMPLES:
        target = output/sample
        target.mkdir()
        prior = SOURCE/sample
        metadata = json.loads((prior/'metrics.json').read_text(encoding='utf-8'))
        condition = json.loads((prior/'theta_joint/condition.json').read_text(encoding='utf-8'))
        with np.load(prior/'theta_joint/render_materials.npz') as data:
            original = torch.from_numpy(data['original'].copy()).to(device)
        with np.load(prior/'theta_joint/centered_render_values.npz') as data:
            near = torch.from_numpy(data['near'].copy()).to(device)
            far = torch.from_numpy(data['far'].copy()).to(device)
        q = metadata['lamp_intensity']['q']
        train = torch.tensor(condition['train_xyz'], device=device, dtype=torch.float32)
        test = torch.tensor(condition['evaluation_xyz'], device=device, dtype=torch.float32)
        assert len(train) == 40 and torch.all(train[:, :2].norm(dim=1) > 0)
        saved_states = {}

        def snapshot(step, material, final):
            if args.stability and (step in (0,100,300) or step%1000==0 or final):
                saved_states[step] = material.cpu().clone()
            if step % 250 == 0 or final:
                r._json(target/'progress.json', dict(step=step, final=final))
                print(args.variant, sample, step, flush=True)

        result = r.analyze_condition(
            original, renderer, train, test, q, mode='fixed', regime=args.variant,
            steps=args.steps, lr=.01, seed=0, stability=args.stability,
            snapshot_callback=snapshot, light_chunk_size=8, measured_target=near,
            measured_light=r.ring(0, device=device), preservation_weight=.1,
            cue_config=VARIANTS[args.variant])
        updated = result['last']
        assert torch.equal(updated[:,7:], torch.full_like(updated[:,7:], -.92))
        with torch.no_grad():
            initial_render = renderer(original, r.ring(0, device=device), q)[:,0]
            final_render = renderer(updated, r.ring(0, device=device), q)[:,0]
        np.savez_compressed(target/'materials.npz', original=original.cpu().numpy(),
                            initial=result['initial'].cpu().numpy(), updated=updated.cpu().numpy(),
                            near=near.cpu().numpy(), far=far.cpu().numpy(),
                            render_original=initial_render.cpu().numpy(), render_final=final_render.cpu().numpy())
        record = {k:result[k] for k in ('objective','termination','trajectory','metrics')}
        record.update(sample=sample, q=q, provenance=metadata['provenance'],
                      train_xyz=train.cpu().tolist(), test_xyz=test.cpu().tolist(),
                      input_files={str(prior/'theta_joint'/name): r._file_stat(prior/'theta_joint'/name)
                                   for name in ('render_materials.npz','centered_render_values.npz')})
        if saved_states:
            display_scales = r.display_scales(original.cpu(), list(saved_states.values()))
            record['frames'] = []
            record['display_scales'] = display_scales
            for step, material in sorted(saved_states.items()):
                frame_path = f'step_{step:05d}.webp'
                r.save_frame(target/frame_path, original.cpu(), material, display_scales, lossless=True)
                record['frames'].append(dict(step=step,path=frame_path))
            np.savez_compressed(target/'snapshots.npz', **{f'step_{step}':material.numpy() for step,material in saved_states.items()})
        r._json(target/'result.json', record)
        maps = physical_maps(updated)
        for name, value in maps.items():
            image = (value[0]+1)/2 if name == 'normal' else value[0]
            if name in ('diffuse', 'specular'): image = image.clamp(0,1).pow(1/2.2)
            r.tile(image).save(target/f'{name}.png')
        r.tile(final_render[0].clamp(0,1).pow(1/2.2)).save(target/'render.png')
        print('DONE', args.variant, sample, result['trajectory'][-1]['total_loss'], flush=True)


if __name__ == '__main__':
    main()
