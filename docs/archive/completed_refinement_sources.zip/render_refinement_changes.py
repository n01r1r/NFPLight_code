"""Replay recorded fixed-F0 states to visualize numerical map differences."""
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import torch

from capture_processing.rendering_loss_analysis import (
    analyze_condition, physical_maps, build_light_regimes, build_common_heldout_lights,
)
from model.author_real_capture_adapter import AuthorRealCaptureAdapter
from run_prediction_refinement import reconstruct_selected_pair
from run_rendering_loss_analysis import CHECKPOINT, REFRESH_ROOT, _make_renderer

ROOT = Path('artifacts/rendering_loss_analysis_20261006')
OUT = ROOT / 'change_images_rgb'
LIGHT_LABELS = {'center': 'Center: 1 light', 'small': 'XY radius 0.25: 5 lights', 'wide': 'XY radius 1.50: 5 lights'}


def change_fields(original, current):
    """Physical signed channel differences and geodesic normal change, no PNG inputs."""
    before = physical_maps(original)
    after = physical_maps(current)
    n0, n1 = before['normal'], after['normal']
    cross = torch.linalg.vector_norm(torch.cross(n0, n1, dim=1), dim=1)
    dot = (n0 * n1).sum(dim=1)
    return {
        'normal_angle_deg': torch.rad2deg(torch.atan2(cross, dot)),
        'diffuse': after['diffuse'] - before['diffuse'],
        'roughness': after['roughness'] - before['roughness'],
        'specular': after['specular'] - before['specular'],
    }


def _save_figure(fig, folder, name):
    fig.savefig(folder / f'{name}.png', dpi=180)
    fig.savefig(folder / f'{name}.svg')
    plt.close(fig)


def signed_rgb(delta, limit):
    """Combine signed RGB differences; neutral gray is zero, no gamma transform."""
    values = np.asarray(delta, dtype=np.float32)
    if values.ndim != 3 or values.shape[0] not in (1, 3) or limit <= 0:
        raise ValueError('expected [1|3,H,W] difference and positive scale')
    if not np.isfinite(values).all() or np.abs(values).max() > limit + 1e-6:
        raise ValueError('difference exceeds shared scale or is non-finite')
    rgb = .5 + values / (2 * limit)
    if rgb.shape[0] == 1:
        rgb = np.repeat(rgb, 3, axis=0)
    return np.moveaxis(np.clip(rgb, 0, 1), 0, -1)


def plot_fields(sample, fields, records, scales):
    folder = OUT / sample
    folder.mkdir(exist_ok=True)
    plt.rcParams.update({'font.size': 11, 'axes.titlesize': 12})
    for regime in LIGHT_LABELS:
        fig, axes = plt.subplots(1, 4, figsize=(14, 4.2), constrained_layout=True)
        angular = axes[0].imshow(fields[regime]['normal_angle_deg'][0], cmap='viridis', vmin=0, vmax=scales['normal_angle_deg'], interpolation='nearest')
        axes[0].set_title('Normal angular variation')
        for ax, component in zip(axes[1:], ('diffuse', 'roughness', 'specular')):
            ax.imshow(signed_rgb(fields[regime][component][0], scales[component]), interpolation='nearest')
            ax.set_title(f'{component}: signed RGB change')
        for ax in axes:
            ax.set_xticks([]); ax.set_yticks([])
        fig.colorbar(angular, ax=axes[0], orientation='horizontal', fraction=.06, pad=.04, label='Angle to original normal (degrees)')
        fig.suptitle(f'{LIGHT_LABELS[regime]} | selected update {records[regime]["fixed"]["best_step"]}', fontsize=14)
        _save_figure(fig, folder, f'{regime}_changes')

def run():
    if OUT.exists():
        raise FileExistsError(f'refusing to replace numerical replay artifacts: {OUT}')
    OUT.mkdir()
    summary = json.loads((ROOT / 'summary.json').read_text(encoding='utf-8'))
    plan = summary['plan']
    numeric_paths = [ROOT / 'summary.json', ROOT / 'plan.json'] + list(ROOT.glob('*/metrics.json')) + list(ROOT.glob('*/*/*/condition.json'))
    before_stats = {str(p): (p.stat().st_size, p.stat().st_mtime_ns) for p in numeric_paths + [CHECKPOINT]}
    (OUT / 'plan.json').write_text(json.dumps({
        'purpose': 'numerical difference visualization of previously recorded fixed-F0 selected states',
        'reference': 'original FP32 author prediction',
        'normal': 'atan2(norm(cross(unit normals)), dot(unit normals)) in degrees',
        'diffuse_roughness_specular': 'signed physical selected-original; one RGB image per map; display=0.5+delta/(2*shared_abs_max), no gamma; scalar roughness replicated to RGB',
        'F0': '0.04 fixed; original-to-fixed change shown once; optimization update must be zero',
        'replay': plan, 'new_experiment_conditions': False, 'numeric_maps_saved': False,
        'color_scale': 'normal angle shared across all samples; signed RGB scale shared across three lighting conditions within each sample; full extrema, no clipping',
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    device = torch.device('cuda')
    torch.backends.cuda.matmul.allow_tf32 = False
    torch.backends.cudnn.allow_tf32 = False
    model = AuthorRealCaptureAdapter(CHECKPOINT, device='cuda')
    all_fields, checks = {}, []
    for record in summary['samples']:
        sample = record['sample']
        near, far, provenance = reconstruct_selected_pair(sample=sample, refresh=REFRESH_ROOT / sample / 'refresh_20261006')
        frames = [Path(item['path']) for side in ('near', 'far') for item in provenance['source_frames'][side]]
        for path in frames:
            before_stats[str(path)] = (path.stat().st_size, path.stat().st_mtime_ns)
        with torch.no_grad():
            prediction, _ = model.infer(torch.cat((near, far), dim=1).to(device=device, dtype=torch.float32))
        sample_fields = {}
        for regime, lights in build_light_regimes(device).items():
            reference = record['conditions'][regime]['fixed']
            result = analyze_condition(prediction, _make_renderer(device), lights, build_common_heldout_lights(device), reference['lamp_intensity'], mode='fixed', regime=regime, steps=reference['steps'], lr=reference['lr'], seed=reference['seed'])
            if result['best_step'] != reference['best_step']:
                raise RuntimeError(f'{sample}/{regime}: selected iteration differs from recorded run')
            # Validate the complete replay, not just a visually convenient state.
            for old, new in zip(reference['trajectory'], result['trajectory']):
                for metric in ('train_mse', 'common_heldout_mse'):
                    if not np.isclose(old[metric], new[metric], rtol=1e-5, atol=1e-12):
                        raise RuntimeError(f'{sample}/{regime}/{old["step"]}: {metric} replay mismatch')
            delta = change_fields(prediction, result['best'])
            expected = reference['metrics']['best_map_mae_physical']
            means = {k: float(delta[k].abs().mean()) for k in ('diffuse', 'roughness', 'specular')}
            means['normal_angular_mean_deg'] = float(delta['normal_angle_deg'].mean())
            for k, value in means.items():
                if not np.isclose(value, expected[k], rtol=1e-5, atol=1e-7):
                    raise RuntimeError(f'{sample}/{regime}: physical change metric mismatch: {k}')
            assert torch.equal(result['initial'][:, 7:], result['best'][:, 7:])
            sample_fields[regime] = {k: v.detach().cpu().numpy() for k, v in delta.items()}
            checks.append({'sample': sample, 'regime': regime, 'selected_update': result['best_step'], 'trajectory_matches': True, 'change_means_match': True, 'means': means, 'F0_optimization_change': 0.0})
            print(f'REPLAY_OK {sample} {regime} selected={result["best_step"]}', flush=True)
        all_fields[sample] = sample_fields
    scales = {component: max(float(np.abs(fields[regime][component]).max()) for fields in all_fields.values() for regime in LIGHT_LABELS) for component in ('normal_angle_deg', 'diffuse', 'roughness', 'specular')}
    scales = {k: max(value, 1e-12) for k, value in scales.items()}
    sample_scales = {}
    for record in summary['samples']:
        fields = all_fields[record['sample']]
        local = {component: max(1e-12, max(float(np.abs(fields[regime][component]).max()) for regime in LIGHT_LABELS)) for component in ('diffuse', 'roughness', 'specular')}
        local['normal_angle_deg'] = scales['normal_angle_deg']
        sample_scales[record['sample']] = local
        plot_fields(record['sample'], fields, record['conditions'], local)
    assert all((Path(path).stat().st_size, Path(path).stat().st_mtime_ns) == value for path, value in before_stats.items())
    (OUT / 'checks.json').write_text(json.dumps({'conditions': checks, 'shared_scale_extrema': scales, 'sample_display_scales': sample_scales, 'original_numeric_files_unchanged': len(numeric_paths), 'source_frames_and_checkpoint_unchanged': True, 'numeric_arrays_saved': False, 'PNG_subtraction': False}, ensure_ascii=False, indent=2), encoding='utf-8')
    print('CHANGE_FIELDS_COMPLETE', flush=True)


if __name__ == '__main__':
    run()
