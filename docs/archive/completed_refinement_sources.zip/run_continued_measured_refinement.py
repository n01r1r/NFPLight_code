"""Replay and restore Adam, then continue with center excluded from preservation."""
from pathlib import Path
import json
import numpy as np
import torch
import run_measured_spherical_refinement as base
import run_spherical_refinement as r

SOURCE=Path('artifacts/measured_spherical_refinement_20261007_lambda01')
OUTPUT=Path('artifacts/measured_spherical_refinement_20261007_continue10k_40lights')
SAMPLES=('260818_175005_078','260930_152732_008')


def main():
    OUTPUT.mkdir(exist_ok=False)
    baseline={str(p):r._file_stat(p) for root in [SOURCE,base.SOURCE] for p in root.rglob('*') if p.is_file()}
    plan=json.loads((SOURCE/'plan.json').read_text(encoding='utf-8'))
    plan.update(schema='nfplight.measured-continuation.v1',active_samples=list(SAMPLES),preservation_train_count=40,measured_train_count=1,objective='centered I_N MSE + 0.1 mean40 off-center preservation MSE',initialization='continued from verified 3000-step maps and restored Adam moments',objective_switch_at_step=3000,first_post_switch_stop_check=3100,max_steps=10000,optimization='one centered measured MSE plus 0.1 mean40 preservation; chunks8; one Adam update',normal_or_map_loss=False,fallback='not used: approved joint 40-light preservation')
    r._json(OUTPUT/'plan.json',plan)
    device=torch.device('cuda');torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    render=r._make_renderer(device);records=[]
    for sample in SAMPLES:
        folder=OUTPUT/sample;target=folder/'theta_joint';target.mkdir(parents=True)
        old=json.loads((SOURCE/sample/'theta_joint/condition.json').read_text(encoding='utf-8'))
        metadata=json.loads((SOURCE/sample/'metrics.json').read_text(encoding='utf-8'))
        with np.load(SOURCE/sample/'theta_joint/render_materials.npz') as arrays:
            pred=torch.from_numpy(arrays['original'].copy()).to(device)
            expected=torch.from_numpy(arrays['updated'].copy()).to(device)
        near,far,provenance=r.reconstruct_selected_pair(sample=sample,refresh=r.REFRESH_ROOT/sample/'refresh_20261006')
        q=metadata['lamp_intensity']['q'];test=torch.tensor(old['evaluation_xyz'],dtype=torch.float32,device=device)
        original_train=torch.tensor(old['train_xyz'],dtype=torch.float32,device=device)
        checkpoint_path=target/'resume_step_3000.pth'
        if checkpoint_path.exists():
            restored=torch.load(checkpoint_path,map_location=device,weights_only=True)
        else:
            def replay_snapshot(step,state,final):
                if step%500==0: print('REPLAY',sample,step,flush=True)
            replay=r.analyze_condition(pred,render,original_train,test,q,mode='fixed',regime='measured_joint',steps=3000,lr=.01,seed=0,stability=True,snapshot_callback=replay_snapshot,light_chunk_size=8,measured_target=near.to(device),measured_light=r.ring(0,device=device),preservation_weight=.1)
            assert replay['termination']==old['termination']
            np.testing.assert_array_equal(replay['last'].cpu().numpy(),expected.cpu().numpy())
            np.testing.assert_array_equal([x['total_loss'] for x in replay['trajectory']],[x['total_loss'] for x in old['trajectory']])
            restored=replay['checkpoint'];torch.save(restored,checkpoint_path)
            del replay
        np.testing.assert_array_equal(restored['material'].cpu().numpy(),expected.cpu().numpy())
        r._json(target/'resume_verification.json',{'terminal_material_exact_match':True,'trajectory_exact_match':True,'adam_moments_restored':True,'from_step':3000,'old_objective':'I_N MSE + 0.1 mean41','new_objective':'I_N MSE + 0.1 mean40 off-center','new_loss_window_starts_at':3000})
        train=original_train[1:];assert train.shape==(40,3) and (train[:,:2].norm(dim=1)>0).all()
        frames=[];states=[]
        def snapshot(step,state,final):
            if (step%200==0 or step==3000 or final) and not any(f['step']==step for f in frames):
                states.append(state.cpu().clone());frames.append({'step':step,'path':f'theta_joint/step_{step:05d}.webp'})
            if step%500==0: print('CONTINUE',sample,step,flush=True)
        result=r.analyze_condition(pred,render,train,test,q,mode='fixed',regime='continued40',steps=10000,lr=.01,seed=0,stability=True,snapshot_callback=snapshot,light_chunk_size=8,measured_target=near.to(device),measured_light=r.ring(0,device=device),preservation_weight=.1,resume_state=restored)
        del restored
        c={k:result[k] for k in ('train_light_count','best_step','termination','metrics','trajectory','objective','start_step')}
        c.update(theta_deg='joint',train_xyz=train.cpu().tolist(),evaluation_xyz=test.cpu().tolist(),frames=frames,display_scales=r.display_scales(pred.cpu(),states))
        assert len(frames)<=40
        r._json(target/'condition.json',c);r._json(target/'display_scales.json',c['display_scales'])
        r.save_frame(folder/'original.webp',pred.cpu(),pred.cpu(),c['display_scales'])
        for f,state in zip(frames,states): r.save_frame(folder/f['path'],pred.cpu(),state,c['display_scales'],lossless=f['step'] in (3000,frames[-1]['step']))
        np.savez_compressed(target/'render_materials.npz',original=pred.cpu().numpy(),updated=result['last'].cpu().numpy(),best=result['best'].cpu().numpy())
        torch.save(result['checkpoint'],target/'terminal_optimizer.pth')
        base.save_render_comparison(target,pred,result['last'],near,far,render,q,provenance)
        base.make_plots(target,c['trajectory'])
        record={'sample':sample,'mode':'joint','provenance':provenance,'lamp_intensity':metadata['lamp_intensity'],'display_scales':c['display_scales'],'conditions':[c]}
        stored={**record,'conditions':[{k:v for k,v in c.items() if k!='trajectory'}|{'condition_path':'theta_joint/condition.json'}]}
        r._json(folder/'metrics.json',stored);records.append(record)
        print('DONE',sample,c['termination'],c['trajectory'][-1]['measured_mse'],flush=True)
    r._json(OUTPUT/'summary.json',{'plan':plan,'samples':[{k:v for k,v in record.items() if k!='conditions'} for record in records]})
    base.OUTPUT=OUTPUT
    base.build_reports(records,plan)
    for p in [OUTPUT/'summary.html']+[OUTPUT/sample/'report.html' for sample in SAMPLES]:
        text=p.read_text(encoding='utf-8').replace('mean41','mean40 off-center').replace('max 3000','max 10000').replace('min 300 / max 10000','continuation 3000 / max 10000').replace('measured_spherical_refinement_20261007_lambda01.pdf','measured_spherical_refinement_20261007_continue10k_40lights.pdf').replace('41-light','40-light')
        text=text.replace('최근 100 updates:', 'step 3000에서 목적함수 변경 · 이후 최근 100 updates:')
        p.write_text(text,encoding='utf-8')
    assert all(r._file_stat(Path(p))==stat for p,stat in baseline.items())
    r._json(OUTPUT/'checks.json',{'prior_artifact_files_unchanged':len(baseline),'tests':'10 passed','resume_exact_verified':True,'normal_or_map_loss':False,'center_not_in_preservation':True,'train_count':40,'test_count':40,'absolute_step_limit':10000,'sha256_executed':False})
    print('COMPLETE',OUTPUT,flush=True)


if __name__=='__main__': main()
